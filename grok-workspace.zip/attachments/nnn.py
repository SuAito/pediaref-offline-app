with open('app.py', 'w') as f:
    f.write('''
import streamlit as st
import pandas as pd
from datetime import datetime
import matplotlib.pyplot as plt
import sqlite3
import os
import re
from fpdf import FPDF
import io
import base64 # Re-enabled for robust image handling
import requests # Re-enabled for robust image handling
import streamlit.components.v1 as components # Keep for robust HTML rendering

# Database file definition
DB_FILE = 'patient_log.db'

# Function to initialize the database and table
def init_db():
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS patient_log (
                Timestamp TEXT,
                Patient TEXT,
                Age_Mo INTEGER,
                Weight_kg REAL,
                Dept TEXT,
                Action TEXT,
                Result TEXT
            )
        """
        )
        conn.commit()

# Call init_db() to ensure the database table exists
init_db()

# Function to clear the log (now interacts with DB)
def clear_log():
    with sqlite3.connect(DB_FILE) as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM patient_log")
        conn.commit()
    # Reset session state log after clearing DB
    st.session_state.log = pd.DataFrame(
        columns=['Time', 'Patient', 'Age(Mo)', 'Weight(kg)', 'Dept', 'Action', 'Result']
    )

# Function to plot the WHO growth chart
def plot_growth_chart(age, weight, growth_data, gender):
    fig, ax = plt.subplots(figsize=(10, 6))

    ages_sorted = sorted(growth_data.keys())

    # Plot percentile curves
    percentiles = ['p3', 'p15', 'p50', 'p85', 'p97']
    labels = ['3rd', '15th', '50th (Median)', '85th', '97th']

    for i, p_key in enumerate(percentiles):
        weights_for_percentile = [growth_data[a].get(p_key) for a in ages_sorted if p_key in growth_data[a]]
        # Filter out None values in case some ages don't have all percentiles
        actual_ages = [ages_sorted[j] for j, w in enumerate(weights_for_percentile) if w is not None]
        actual_weights = [w for w in weights_for_percentile if w is not None]
        if actual_ages and actual_weights:
            ax.plot(actual_ages, actual_weights, label=f'{labels[i]} percentile')

    # Mark patient's current weight and age
    ax.plot(age, weight, 'r*', markersize=12, label='Patient')

    # Add labels, title, and legend
    ax.set_xlabel('Age (Months)')
    ax.set_ylabel('Weight (kg)')
    ax.set_title(f'WHO Weight-for-Age Percentile Chart ({gender}s 0-5 years)')
    ax.legend()
    ax.grid(True)
    plt.tight_layout()
    return fig

# Function to generate PDF prescription
def generate_pdf_prescription(patient_name, drug_name, mg_dose, ml_dose):
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font('Arial', 'B', 16)
    pdf.cell(0, 10, f'Prescription for {patient_name}', 0, 1, 'C')
    pdf.ln(10)
    pdf.set_font('Arial', '', 12)
    pdf.cell(0, 10, f'Drug: {drug_name}', 0, 1)
    pdf.cell(0, 10, f'Dose: {round(mg_dose, 1)} mg', 0, 1)
    pdf.cell(0, 10, f'Volume: {round(ml_dose, 2)} ml', 0, 1)

    # Save to a temporary file
    pdf_output_path = 'prescription.pdf'
    pdf.output(pdf_output_path)
    return pdf_output_path

# Function to remove emojis from text for FPDF compatibility
def remove_emojis(text):
    emoji_pattern = re.compile(
        "["
        "😀-🙏"  # emoticons
        "🌀-🗿"  # symbols & pictographs
        "🚀-🛿"  # transport & map symbols
        "🇠-🇿"  # flags (iOS)
        "✂-➰"
        "Ⓜ-🉑"
        "‍" # Zero width joiner
        "️" # Variation selector
        "]+", flags=re.UNICODE
    )
    return emoji_pattern.sub(r"'", text)

# Function to generate PDF growth report
def generate_growth_report_pdf(patient_name, patient_gender, patient_age_months, patient_weight, chart_figure, weight_assessment_feedback):
    pdf = FPDF()
    pdf.add_page()

    # Use Arial font directly (compatible with latin-1, so emojis are removed)
    font_family = 'Arial'
    font_size = 12

    pdf.set_font('Arial', 'B', 16) # Title font
    pdf.cell(0, 10, 'Patient Growth Report', 0, 1, 'C')
    pdf.ln(10)

    pdf.set_font(font_family, 'B', font_size) # Section header font
    pdf.cell(0, 10, 'Patient Information:', 0, 1)
    pdf.set_font(font_family, '', font_size) # Content font
    pdf.cell(0, 10, f'Name: {patient_name}', 0, 1)
    pdf.cell(0, 10, f'Gender: {patient_gender}', 0, 1)
    pdf.cell(0, 10, f'Age: {round(patient_age_months, 1)} Months', 0, 1)
    pdf.cell(0, 10, f'Weight: {patient_weight} kg', 0, 1)
    pdf.ln(10)

    pdf.set_font(font_family, 'B', font_size) # Section header font
    pdf.cell(0, 10, 'Growth Assessment Chart:', 0, 1)

    # Save Matplotlib figure to a temporary file, then use its path
    temp_img_path = 'temp_growth_chart.png'
    chart_figure.savefig(temp_img_path, format='png', bbox_inches='tight')

    # Add image to PDF using the temporary file path
    pdf.image(temp_img_path, x = 10, y = pdf.get_y(), w = 190)
    pdf.ln(100) # Move down after the image, roughly image height

    # Remove the temporary image file
    os.remove(temp_img_path)

    # Remove emojis from feedback text before adding to PDF
    clean_weight_feedback = remove_emojis(weight_assessment_feedback)

    pdf.set_font(font_family, 'B', font_size) # Section header font
    pdf.cell(0, 10, 'Weight Status Notes:', 0, 1)
    pdf.set_font(font_family, '', font_size) # Content font
    pdf.multi_cell(0, 10, clean_weight_feedback)

    pdf_output_path = 'growth_report.pdf'
    pdf.output(pdf_output_path)
    return pdf_output_path

# Helper function to convert image to base64 # Re-enabled
def img_to_base64(img_path):
    with open(img_path, "rb") as img_file:
        return base64.b64encode(img_file.read()).decode('utf-8')

# Function to download image from URL and return base64 string # Re-enabled
def get_base64_image_from_url(url, filename):
    try:
        response = requests.get(url)
        response.raise_for_status() # Raise an exception for HTTP errors
        with open(filename, 'wb') as f:
            f.write(response.content)
        base64_string = img_to_base64(filename)
        os.remove(filename) # Clean up temporary file
        return f"data:image/png;base64,{base64_string}"
    except requests.exceptions.RequestException as e:
        st.error(f"Error downloading image from {url}: {e}")
        return "" # Return empty string or a placeholder base64

# --- Direct image URLs from Google Drive ---
user_icon_url_raw = 'https://drive.google.com/uc?export=download&id=1FTQ-2TdLpprrj_iReR9A6qiY5XmJXC4i'
calendar_icon_url_raw = 'https://drive.google.com/uc?export=download&id=1FTfWdiCsBRcHyU4n-1dKuVywW2mQRtZK'
scale_icon_url_raw = 'https://drive.google.com/uc?export=download&id=1FY8JSBD0j-iV80iadVGM4sSI5O31YUgm'
boy_icon_url_raw = 'https://drive.google.com/uc?export=download&id=1FQMqPiFCJeSrYFpBkkmc8pAq33yKr22W'
girl_icon_url_raw = 'https://drive.google.com/uc?export=download&id=1FM8YOsu63mNH_aXEV-VseaNvjkTEOckT'

# Convert raw URLs to base64 strings # Re-enabled
user_icon_url = get_base64_image_from_url(user_icon_url_raw, 'user_icon.png')
calendar_icon_url = get_base64_image_from_url(calendar_icon_url_raw, 'calendar_icon.png')
scale_icon_url = get_base64_image_from_url(scale_icon_url_raw, 'scale_icon.png')
boy_icon_url = get_base64_image_from_url(boy_icon_url_raw, 'boy_icon.png')
girl_icon_url = get_base64_image_from_url(girl_icon_url_raw, 'girl_icon.png')

# Function to get the smart dose (mg/kg) based on age
def get_smart_dose(drug_info, age_months):
    if drug_info.get("is_smart"):
        for rule in drug_info["rules"]:
            if age_months <= rule["max_age"]:
                return rule["mg_kg"], rule["label"]
    return drug_info["mg_kg"], "Standard Dose" # Fallback or for non-smart drugs

# 1. Page Configuration & Custom Professional CSS
st.set_page_config(page_title="Pedia-Master Pro", layout="wide", page_icon="💊")

# Sidebar CSS from rUcXxWSMcTsr
sidebar_css = """
<style>
[data-testid="stSidebar"] {
    background: radial-gradient(circle at 0% 0%, #0f172a 0%, #020617 40%, #020617 100%);
    box-shadow: 4px 0 40px rgba(15, 23, 42, 0.85);
    border-right: 1px solid rgba(148, 163, 184, 0.35);
    position: relative;
    overflow: visible;
}
[data-testid="stSidebar"] > div:first-child {
    padding: 1.8rem 1.4rem 2.2rem 1.4rem;
    font-family: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
}
[data-testid="stSidebar"]::before {
    content: "";
    position: absolute;
    inset: -40px 15% auto auto;
    z-index: -1;
    background: radial-gradient(circle at 20% 0%, rgba(59,130,246,0.55), transparent 60%);
    opacity: 0.9;
}
.sidebar-elite-header {
    display: flex;
    flex-direction: column;
    gap: 0.4rem;
    margin-bottom: 1.2rem;
}
.sidebar-badge {
    background: linear-gradient(120deg, #22c55e, #a3e635);
    color: #0f172a;
    padding: 0.35rem 0.9rem;
    border-radius: 999px;
    display: inline-flex;
    align-items: center;
    gap: 0.45rem;
    font-size: 0.75rem;
    font-weight: 800;
    letter-spacing: 0.12em;
    text-transform: uppercase;
    box-shadow: 0 8px 20px rgba(22,163,74,0.55), 0 0 0 1px rgba(255,255,255,0.45);
}
.sidebar-badge-dot {
    width: 8px;
    height: 8px;
    border-radius: 999px;
    background: radial-gradient(circle, #bbf7d0 0%, #16a34a 60%, #052e16 100%);
}
.sidebar-title {
    font-size: 1.2rem;
    font-weight: 700;
    color: #e5e7eb;
    letter-spacing: 0.03em;
}
.sidebar-subtitle {
    font-size: 0.78rem;
    color: #9ca3af;
}
.sidebar-glass-wrap {
    margin-top: 1.1rem;
    position: relative;
}
.sidebar-glass-panel::before {
    content: "";
    position: absolute;
    inset: -40%;
    background: linear-gradient(120deg, transparent, rgba(248,250,252,0.25), transparent);
    transform: translateX(-60%);
    animation: sidebarSweep 6s infinite;
    opacity: 0.7;
}
@keyframes sidebarSweep {
    0%   { transform: translateX(-80%); }
    40%  { transform: translateX(40%); }
    100% { transform: translateX(80%); }
}
.sidebar-patient-chip {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 0.75rem;
    padding: 0.55rem 0.75rem;
    border-radius: 999px;
    background: rgba(15,23,42,0.9);
    border: 1px solid rgba(148,163,184,0.8);
    color: #e5e7eb;
    font-size: 0.80rem;
    margin-bottom: 0.75rem;
}
.sidebar-patient-main {
    display: flex;
    align-items: center;
    gap: 0.5rem;
}
.sidebar-patient-avatar {
    width: 26px;
    height: 26px;
    border-radius: 999px;
    background: radial-gradient(circle at 30% 20%, #fef9c3, #38bdf8 55%, #0f172a 100%);
    box-shadow: 0 0 0 1px rgba(248,250,252,0.7);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.95rem;
}
.sidebar-patient-info {
    display: flex;
    flex-direction: column;
    line-height: 1.15;
}
.sidebar-patient-name {
    font-weight: 600;
    font-size: 0.8rem;
}
.sidebar-patient-meta {
    font-size: 0.72rem;
    color: #9ca3af;
}
.sidebar-pill-row {
    display: flex;
    gap: 0.25rem;
    font-size: 0.7rem;
}
.sidebar-pill {
    padding: 0.12rem 0.5rem;
    border-radius: 999px;
    border: 1px solid rgba(59,130,246,0.65);
    color: #bfdbfe;
}
.sidebar-section-label {
    font-size: 0.78rem;
    font-weight: 700;
    letter-spacing: 0.13em;
    text-transform: uppercase;
    color: #9ca3af;
    margin-top: 0.8rem;
    margin-bottom: 0.2rem;
}
.sidebar-divider {
    border: none;
    height: 1px;
    background: linear-gradient(to right, rgba(148,163,184,0.0),
                                         rgba(148,163,184,0.8),
                                         rgba(148,163,184,0.0));
    margin: 0.55rem 0 0.35rem 0;
}
.sidebar-timeline {
    position: relative;
    padding-left: 0.9rem;
    margin-top: 0.3rem;
}
.sidebar-timeline::before {
    content: "";
    position: absolute;
    left: 0.35rem;
    top: 0.15rem;
    bottom: 0.1rem;
    width: 1px;
    background: linear-gradient(to bottom,
                rgba(96,165,250,0.0),
                rgba(96,165,250,0.8),
                rgba(34,197,94,0.0));
}
.sidebar-timeline-dot {
    width: 7px;
    height: 7px;
    border-radius: 999px;
    background: #9ca3af;
    box-shadow: 0 0 0 3px rgba(37,99,235,0.35);
}
[data-testid="stSidebar"] .stTextInput > div > div,
[data-testid="stSidebar"] .stNumberInput > div > div,
[data-testid="stSidebar"] .stSelectbox > div > div {
    border-radius: 999px;
    border: 1px solid rgba(148,163,184,0.9);
    box-shadow: 0 0 0 1px rgba(15,23,42,0.9),
                0 0 0 1px rgba(248,250,252,0.28) inset;
    background: radial-gradient(circle at 0% 0%,
                rgba(30,64,175,0.25),
                rgba(15,23,42,0.98));
}
[data-testid="stSidebar"] input,
[data-testid="stSidebar"] textarea {
    color: #0f1729;
    font-size: 0.82rem;
}
[data-testid="stSidebar"] label {
    font-size: 0.78rem;
    font-weight: 600;
    color: #cbd5f5;
    margin-bottom: 0.1rem;
}
/* Specific style for st.radio options within the sidebar */
[data-testid="stSidebar"] [data-testid="stRadio"] label {
    color: #e0e0e0 !important;
}
[data-testid="stSidebar"] .stMarkdown {
    font-size: 0.76rem;
    color: #9ca3af;
}
[data-testid="stSidebar"][aria-expanded="true"] {
    min-width: 330px;
    max-width: 360px;
}
</style>
"""
st.markdown(sidebar_css, unsafe_allow_html=True)


header_html_content = """
    <style>
    /* استدعاء الخطوط */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@800&family=Courgette&display=swap');

    /* الحاوية الخارجية (الإطار الأبيض اللامع) */
    .rim-outer {
        background-color: white;
        padding: 10px;
        border-radius: 45px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.1);
        margin: 20px auto;
        max-width: 550px;
    }

    /* البطاقة الداخلية */
    .card-inner {
        background: linear-gradient(135deg, #f1f5f9 0%, #e2e8f0 100%);
        border-radius: 35px;
        padding: 30px;
        text-align: left;
    }

    /* الوسام العلوي (Journey Badge) - تم تطبيق التغييرات الجمالية */
    .journey-badge {
        background: linear-gradient(135deg, #3498db 0%, #2980b9 100%);
        color: white;
        padding: 8px 25px;
        border-radius: 20px;
        font-family: 'Inter', sans-serif;
        font-size: 0.85rem;
        font-weight: 800;
        display: inline-block;
        letter-spacing: 1px;

        /* إضافة لمعة زجاجية (Reflective Shine) */
        border: 1px solid rgba(255, 255, 255, 0.3);
        box-shadow:
            0 4px 15px rgba(52, 152, 219, 0.3),
            inset 0 2px 2px rgba(255, 255, 255, 0.4);

        text-shadow: 0 1px 2px rgba(0,0,0,0.2);
    }

    /* حاوية المحتوى الرئيسي */
    .content-layout {
        display: flex;
        align-items: stretch;
        gap: 8px;
        margin: 20px 0;
    }

    /* قسم الأيقونة (يسار الخط) */
    .icon-area {
        display: flex;
        align-items: center;
        justify-content: center;
        min-width: 60px;
    }

    /* الخط الرمادي الفاصل */
    .vertical-line {
        width: 2px;
        background-color: #cbd5e1;
        border-radius: 2px;
    }

    /* قسم النصوص (يمين الخط) */
    .text-area {
        display: flex;
        flex-direction: column;
        justify-content: center;
        padding-left: 0px;
    }

    /* شريط الاسم السفلي (Name Banner) - تم تطبيق التغييرات الجمالية */
    .bottom-name-banner {
        background: linear-gradient(100deg, #2b82c9 0%, #4facfe 100%);
        color: white;
        padding: 15px;
        border-radius: 30px;
        font-family: 'Inter', sans-serif;
        font-size: 1.3rem;
        font-weight: 800;
        text-align: center;
        letter-spacing: 1.5px;
        position: relative;
        overflow: hidden;
        width: 85%;
        margin-left: auto;
        margin-right: auto;
        margin-top: 20px;

        /* إضافة الإطار المضيء (Glowing Rim) */
        border: 1.5px solid rgba(255, 255, 255, 0.4);
        box-shadow:
            0 8px 25px rgba(0, 0, 0, 0.1),
            0 0 15px rgba(79, 172, 254, 0.4);
    }

    /* إضافة تأثير "مسحة الضوء" العابرة فوق الاسم */
    .bottom-name-banner::after {
        content: "";
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: linear-gradient(
            45deg,
            transparent,
            rgba(255, 255, 255, 0.1),
            transparent
        );
        transform: rotate(45deg);
        animation: shine 4s infinite;
    }

    @keyframes shine {
        0% { transform: translateX(-100%) rotate(45deg); }
        100% { transform: translateX(100%) rotate(45deg); }
    }

    /* New CSS for separator lines */
    .separator-line {
        border: none;
        height: 2px;
        background-color: #cbd5e1;
        margin: 15px 0;
    }

    /* Separator before tabs */
    .tabs-separator {
        border: none;
        height: 3px;
        background-color: #f0f0f0;
        margin: 30px 0;
        border-radius: 2px;
    }
    </style>

    <div class="rim-outer">
        <div class="card-inner">
            <div class="journey-badge">INTERNSHIP JOURNEY</div>

            <!-- Horizontal gray line after journey badge -->
            <hr class="separator-line">

            <div class="content-layout">
                <div class="icon-area">
                    <img src="https://img.icons8.com/color/96/stethoscope.png" width="65">
                </div>

                <div class="vertical-line"></div>

                <div class="text-area">
                    <div style="font-family: 'Inter', sans-serif; font-weight: 800; font-size: 2.2rem; line-height: 1.1; color: #1e293b;">
                        Pediatric<br>Reference Pro
                    </div>
                </div> <!-- Corrected closure for text-area -->
            </div> <!-- Corrected closure for content-layout -->

            <hr class="separator-line">

            <div class="bottom-name-banner">
                DR. SULAIMAN ALMAJEEDI
            </div>
        </div>
    </div>
"""
components.html(header_html_content, height=450) # Adjusted height to 450 to avoid clipping

tabs_css = """
<style>
.stTabs [data-baseweb="tab-list"] {
    gap: 6px;
    padding-bottom: 0.35rem;
    border-bottom: 1px solid rgba(148,163,184,0.35);
}
.stTabs [data-baseweb="tab"] {
    background: radial-gradient(circle at 0% 0%, #e5f0ff, #f9fafb);
    border-radius: 999px;
    padding: 0.45rem 0.9rem;
    gap: 0.35rem;
    border: 1px solid rgba(148,163,184,0.6);
    box-shadow: 0 3px 7px rgba(148,163,184,0.45),
                0 0 0 1px rgba(255,255,255,0.8);
    color: #0f172a;
    font-family: 'Inter', system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
    font-size: 0.86rem;
    font-weight: 600;
}
.stTabs [aria-selected="true"] {
    background: linear-gradient(120deg, #2563eb, #38bdf8);
    color: #f9fafb !important;
    border: 1px solid rgba(191,219,254,0.95);
    box-shadow: 0 6px 14px rgba(37,99,235,0.55),
                0 0 0 1px rgba(15,23,42,0.35);
}
.stTabs [aria-selected="true"] p {
    color: #f9fafb !important;
}
.stTabs [data-baseweb="tab-highlight"] {
    background: transparent;
}
.stTabs [data-baseweb="tab"]:hover:not([aria-selected="true"]) {
    border-color: #2563eb;
    box-shadow: 0 4px 10px rgba(148,163,184,0.9),
                0 0 0 1px rgba(191,219,254,0.9);
}
.stTabs [data-baseweb="tab"] p {
    display: flex;
    align-items: center;
    gap: 0.35rem;
    margin: 0;
}
/* Custom styles for safety check and alert backgrounds in Tab 3 */
.custom-info {
    background-color: #152f4f;
    color: white;
    padding: 0.75rem;
    border-radius: 0.5rem;
    margin-bottom: 1rem;
    font-size: 0.9rem;
}
.custom-error {
    background-color: #152f4f;
    color: white;
    padding: 0.75rem;
    border-radius: 0.5rem;
    margin-bottom: 1rem;
    font-size: 0.9rem;
}
</style>
"""
st.markdown(tabs_css, unsafe_allow_html=True)

st.markdown("<div class='tabs-separator'></div>", unsafe_allow_html=True)


# Comprehensive drug database (adapted for new keys from snippet)
drugs = {
    # --- Antibiotics ---
    "Amoxicillin (Susp)": {"is_smart": True, "rules": [
        {"max_age": 6, "mg_kg": 20, "label": "Infants < 6 Months"},
        {"max_age": 24, "mg_kg": 40, "label": "Infants 6-24 Months"},
        {"max_age": 216, "mg_kg": 25, "label": "Children > 2 Years"}
    ], "conc": 250, "vol": 5, "max": 1000},
    "Ampiclox (Ampicillin+Cloxacillin)": {"mg_kg": 50, "conc": 250, "vol": 5, "max": 2000},
    "Cefotaxime": {
        "is_smart": True,
        "rules": [
            {"max_age": 1, "mg_kg": 50, "label": "Neonate Dose (<1 month)"},
            {"max_age": 216, "mg_kg": 75, "label": "Standard Dose (Children)"} # Representative from 50-100
        ],
        "conc": 1000, "vol": 10, "max": 2000
    },
    "Amikacin": {
        "is_smart": True,
        "rules": [
            {"max_age": 1, "mg_kg": 15, "label": "Neonate Dose (<1 month)"},
            {"max_age": 216, "mg_kg": 17.5, "label": "Children Dose"} # Representative from 15-20
        ],
        "conc": 250, "vol": 2, "max": 1500
    },
    "Gentamicin (IV/IM)": {
        "is_smart": True,
        "rules": [
            {"max_age": 1, "mg_kg": 4.5, "label": "Neonate Dose (<1 month)"},
            {"max_age": 12, "mg_kg": 6.25, "label": "Infant Dose (1-12 months)"},
            {"max_age": 216, "mg_kg": 6.25, "label": "Child Dose (>12 months)"} # Representative from 5-7.5
        ],
        "conc": 40, "vol": 2, "max": 400
    },
    "Penicillin G (Benzylpenicillin)": {
        "is_smart": True,
        "rules": [
            {"max_age": 1, "mg_kg": 37500, "label": "Neonate Dose (<1 month)"},
            {"max_age": 216, "mg_kg": 75000, "label": "Children Dose"} # Representative from 50k-100k
        ],
        "conc": 1000000, "vol": 10, "max": 4000000
    },
    "Metronidazole (Flagyl)": {
        "is_smart": True,
        "rules": [
            {"max_age": 1, "mg_kg": 7.5, "label": "Neonate Dose (<1 month)"},
            {"max_age": 216, "mg_kg": 7.5, "label": "Children Dose"} # Representative from 7.5-10
        ],
        "conc": 200, "vol": 5, "max": 500
    },
    "Acyclovir": {
        "is_smart": True,
        "rules": [
            {"max_age": 1, "mg_kg": 20, "label": "Neonate Dose (<1 month)"},
            {"max_age": 216, "mg_kg": 15, "label": "Children Dose"} # Representative from 10-20
        ],
        "conc": 500, "vol": 10, "max": 1000
    },
    "Clindamycin": {
        "is_smart": True,
        "rules": [
            {"max_age": 1, "mg_kg": 10, "label": "Neonate Dose (<1 month)"},
            {"max_age": 216, "mg_kg": 35, "label": "Children Dose"} # Representative from 30-40
        ],
        "conc": 150, "vol": 5, "max": 900
    },
    "Erythromycin": {
        "is_smart": True,
        "rules": [
            {"max_age": 1, "mg_kg": 10, "label": "Neonate Dose (<1 month)"},
            {"max_age": 216, "mg_kg": 12.5, "label": "Child Dose (>1 month)"}
        ],
        "conc": 200, "vol": 5, "max": 500,
        "notes": "30-50 mg/kg/day ÷4; Neonates: 10 mg/kg q12h (motility); Children: 12.5 mg/kg q6h"
    },
    "Clarithromycin": {
        "is_smart": True,
        "rules": [
            {"max_age": 6, "mg_kg": 0, "label": "Infants < 6 Months (Not Recommended)"},
            {"max_age": 216, "mg_kg": 7.5, "label": "Children > 6 Months (15 mg/kg/day ÷2)"}
        ],
        "conc": 125, "vol": 5, "max": 500,
        "notes": "15 mg/kg/day ÷2; Neonates: not recommended; Children >6 mo: for atypical pneumonia"
    },
    "Ciprofloxacin": {
        "is_smart": True,
        "rules": [
            {"max_age": 1, "mg_kg": 0, "label": "Neonate Dose (Avoid, cartilage risk)"},
            {"max_age": 216, "mg_kg": 15, "label": "Children Dose (>1 month, not first-line)"}
        ],
        "conc": 200, "vol": 5, "max": 750,
        "notes": "30 mg/kg/day ÷2; Not first-line in children <18 yr except specific cases (e.g., Pseudomonas); Neonates: avoid due to cartilage risk"
    },
    "Co-trimoxazole (Septrin)": {
        "is_smart": True,
        "rules": [
            {"max_age": 2, "mg_kg": 0, "label": "Contraindicated < 2 Months"},
            {"max_age": 216, "mg_kg": 8, "label": "Standard Pediatric Dose"}
        ],
        "conc": 240, "vol": 5, "max": 960
    },
    "Ceftriaxone": {
        "is_smart": True,
        "rules": [
            {"max_age": 1, "mg_kg": 50, "label": "Neonate Dose (<1 month)"},
            {"max_age": 12, "mg_kg": 80, "label": "Infant Dose (1-12 months)"},
            {"max_age": 216, "mg_kg": 85, "label": "Child Dose (>12 months)"}
        ],
        "conc": 250, "vol": 5, "max": 4000,
        "notes": "Typically 50-100 mg/kg/day. Max 4g/day. For severe infections, meningitis. Given IM/IV."
    },
    "Adrenaline (Nebulizer)": {
        "is_smart": True,
        "rules": [
            {"max_age": 216, "mg_kg": 0.01, "label": "Standard Pediatric Dose (max 5mg)"}
        ],
        "conc": 1, "vol": 1, "max": 5,
        "notes": "0.5mg/kg (max 5mg) of 1:1000 adrenaline (1mg/ml) diluted to 5ml NS. Refer to MSF Pediatric protocols."
    },
    "Azithromycin (Susp)": {
        "is_smart": True,
        "rules": [
            {"max_age": 6, "mg_kg": 0, "label": "Infants < 6 Months (Consult Specialist)"},
            {"max_age": 216, "mg_kg": 10, "label": "Standard Pediatric Dose"} # Often 10mg/kg day 1, then 5mg/kg days 2-5
        ],
        "conc": 200, "vol": 5, "max": 500, # Assuming 200mg/5ml suspension
        "notes": "Often 10 mg/kg once daily for 3 days, or 10 mg/kg on day 1 then 5 mg/kg for 4 days. Max 500mg."
    },
    "Levetiracetam": {
        "is_smart": True,
        "rules": [
            {"max_age": 216, "mg_kg": 20, "label": "Standard Pediatric Maintenance Dose"} # 10-30mg/kg/dose BID
        ],
        "conc": 100, "vol": 1, "max": 1500, # Assuming 100mg/ml oral solution for calculation
        "notes": "**Status Epilepticus (SE) - Third-line (20-60 min):** If first and second-line therapies fail. Loading dose: 20-60 mg/kg IV (often 40 mg/kg) over 15-30 min. Maintenance: 10-30 mg/kg/dose BID (max 3000 mg/day). Ensure adequate IV access and monitor for side effects."
    },
    # --- Antiepileptics / Sedatives ---
    "Diazepam (IV for seizures)": {
        "mg_kg": 0.2,
        "conc": 10, "vol": 2, "max": 10,
        "notes": "**Status Epilepticus (SE) - First-line (0-5 min):** Administer 0.2-0.5 mg/kg IV slow (max 5mg <5yr, 10mg >=5yr). Repeat once after 5-10 min if SE persists. Max 2 doses. If SE continues after 10 min (total 15 min), proceed to Second-line therapy (Phenobarbital or Phenytoin). Neonates: 0.1-0.3 mg/kg/dose IV (lower due to prolonged half-life); Infants/Children: 0.2-0.5 mg/kg/dose; Max single dose <5 yr: 5 mg, ≥5 yr: 10 mg."
    },
    "Phenobarbital (Loading)": {
        "is_smart": True,
        "rules": [
            {"max_age": 1, "mg_kg": 15, "label": "Neonate Dose (<1 month)"},
            {"max_age": 216, "mg_kg": 20, "label": "Infant/Child Dose"}
        ],
        "conc": 120, "vol": 2, "max": 1000,
        "notes": "**Status Epilepticus (SE) - Second-line (5-20 min):** If first-line benzodiazepines fail after 2 doses. Loading dose: 15-20 mg/kg IV over 10-20 min. May repeat 5-10 mg/kg once if SE persists (up to max total 40 mg/kg). If SE continues after 20 min (total 35 min), consider Third-line therapy (Levetiracetam, continuous Midazolam/Propofol)."
    },
    "Phenobarbital (Maintenance)": {
        "is_smart": True,
        "rules": [
            {"max_age": 1, "mg_kg": 3, "label": "Neonate Dose (<1 month)"},
            {"max_age": 216, "mg_kg": 5, "label": "Infant/Child Dose"}
        ],
        "conc": 120, "vol": 2, "max": 300
    },
    "Phenytoin (Loading)": {
        "is_smart": True,
        "rules": [
            {"max_age": 1, "mg_kg": 15, "label": "Neonate Dose (<1 month)"},
            {"max_age": 216, "mg_kg": 20, "label": "Infant/Child Dose"}
        ],
        "conc": 50, "vol": 5, "max": 1000,
        "notes": "**Status Epilepticus (SE) - Second-line (5-20 min):** If first-line benzodiazepines fail after 2 doses. Loading dose: 15-20 mg/kg IV over 10-20 min (max infusion rate 1 mg/kg/min). Monitor ECG/BP closely due to cardiac side effects. Max total loading dose 30 mg/kg. If SE continues after 20 min (total 35 min), consider Third-line therapy (Levetiracetam, continuous Midazolam/Propofol)."
    },
    "Phenytoin (Maintenance)": {
        "is_smart": True,
        "rules": [
            {"max_age": 1, "mg_kg": 4, "label": "Neonate Dose (<1 month)"},
            {"max_age": 216, "mg_kg": 8, "label": "Infant/Child Dose"}
        ],
        "conc": 50, "vol": 5, "max": 300
    },
    "Midazolam (IV bolus)": {
        "is_smart": True,
        "rules": [
            {"max_age": 1, "mg_kg": 0.05, "label": "Neonate Dose (<1 month)"},
            {"max_age": 216, "mg_kg": 0.1, "label": "Infant/Child Dose"}
        ],
        "conc": 1, "vol": 5, "max": 10,
        "notes": "**Status Epilepticus (SE) - First-line (0-5 min):** Administer 0.1-0.2 mg/kg IV/IM/buccal (max 5mg <5yr, 10mg >=5yr). Repeat once after 5-10 min if SE persists. Max 2 doses. If SE continues after 10 min (total 15 min), proceed to Second-line therapy (Phenobarbital or Phenytoin). For Refractory SE (Third-line, 20-60 min), a continuous Midazolam infusion (0.05-0.4 mg/kg/hr) may be needed. Neonates: 0.05 mg/kg; Infants/Children: 0.1-0.2 mg/kg."
    },
    # --- Corticosteroids ---
    "Dexamethasone": {
        "mg_kg": 0.5,
        "conc": 8, "vol": 2, "max": 16,
        "notes": "Generally same across ages; Neonates may need adjustment for cerebral edema"
    },
    "Prednisolone (Syrup)": {
        "is_smart": True,
        "rules": [
            {"max_age": 1, "mg_kg": 0.5, "label": "Neonate Dose"},
            {"max_age": 216, "mg_kg": 1, "label": "Child Dose"}
        ],
        "conc": 5, "vol": 5, "max": 60,
        "notes": "Loading: 1-2 mg/kg/day (methylpred equiv); Maintenance: 0.5-1 mg/kg/day; Neonates: lower doses; Children: adjust for inflammation/asthma"
    },
    # --- Antimalarials ---
    "Quinine": {
        "mg_kg": 10,
        "conc": 300, "vol": 2, "max": 600,
        "notes": "Loading 20 mg/kg then 10 mg/kg q8h; Neonates/Infants: monitor hypoglycemia closely"
    },
    # --- Emergency / Resuscitation ---
    "Dextrose 10% (Loading for Hypoglycemia)": {
        "mg_kg": 500,
        "conc": 100, "vol": 5, "max": 250,
        "notes": "Neonates: 2-5 mL/kg bolus; Children: similar; Follow with maintenance"
    },
    "Calcium Gluconate 10%": {
        "is_smart": True,
        "rules": [
            {"max_age": 1, "mg_kg": 100, "label": "Neonate Dose (<1 month)"},
            {"max_age": 216, "mg_kg": 50, "label": "Child Dose (>1 month)"}
        ],
        "conc": 100, "vol": 1, "max": 2000,
        "notes": "Neonates: 100-200 mg/kg/dose slow IV; Children: 50-100 mg/kg/dose; Monitor ECG"
    },
    "Sodium Bicarbonate (NaHCO3)": {
        "mg_kg": 84,
        "conc": 84, "vol": 1, "max": 1000,
        "notes": "Neonates: cautious use, 1-2 mEq/kg slow; Children: same; Only if severe acidosis"
    },
    "Furosemide (Lasix)": {
        "is_smart": True,
        "rules": [
            {"max_age": 1, "mg_kg": 1, "label": "Neonate Dose (<1 month)"},
            {"max_age": 216, "mg_kg": 1, "label": "Child Dose (>1 month)"}
        ],
        "conc": 10, "vol": 2, "max": 40,
        "notes": "Neonates: 1 mg/kg/dose (may need higher); Children: 1-2 mg/kg/dose q6-12h"
    },
    # --- Blood Related ---
    "Vitamin K (Phytonadione)": {
        "is_smart": True,
        "rules": [
            {"max_age": 1, "mg_kg": 0.5, "label": "Neonate Prophylaxis"},
            {"max_age": 216, "mg_kg": 5, "label": "Therapeutic Dose"}
        ],
        "conc": 10, "vol": 1, "max": 10,
        "notes": "Neonates: 0.5-1 mg IM/IV once for prophylaxis. Therapeutic: 5-10 mg IM/IV"
    },
    "Iron (Oral) (Ferrous Sulfate)": {
        "is_smart": True,
        "rules": [
            {"max_age": 6, "mg_kg": 1, "label": "Prophylaxis < 6mo (elemental iron)"},
            {"max_age": 216, "mg_kg": 3, "label": "Treatment (elemental iron)"}
        ],
        "conc": 30, "vol": 1, "max": 100,
        "notes": "Prophylaxis: 1-2 mg/kg/day elemental iron; Treatment: 3-6 mg/kg/day elemental iron. Adjust for formulation."
    },
    "Folic Acid": {
        "is_smart": True,
        "rules": [
            {"max_age": 12, "mg_kg": 0.05, "label": "Infant Prophylaxis"},
            {"max_age": 216, "mg_kg": 0.5, "label": "Child Therapeutic"}
        ],
        "conc": 1, "vol": 1, "max": 5,
        "notes": "Prophylaxis: 0.05-0.1 mg/day; Therapeutic: 0.5-1 mg/day"
    },
    # --- Analgesics & Antipyretics ---
    "Paracetamol (Syrup)": {
        "is_smart": True,
        "rules": [
            {"max_age": 1, "mg_kg": 10, "label": "Neonate Dose"},
            {"max_age": 216, "mg_kg": 15, "label": "Standard Pediatric Dose"}
        ],
        "conc": 120, "vol": 5, "max": 1000
    },
    "Paracetamol (Infusion)": {
        "is_smart": True,
        "rules": [
            {"max_age": 1, "mg_kg": 7.5, "label": "Neonate Dose"},
            {"max_age": 216, "mg_kg": 10, "label": "Standard Pediatric Dose"}
        ],
        "conc": 1000, "vol": 100, "max": 1000
    },
    "Ibuprofen (Advil/Fenistil)": {
        "is_smart": True,
        "rules": [
            {"max_age": 6, "mg_kg": 0, "label": "Not Recommended < 6 Months"},
            {"max_age": 216, "mg_kg": 10, "label": "Standard Pediatric Dose"}
        ],
        "conc": 100, "vol": 5, "max": 400
    },
    "Diclofenac (Voltaren Supp)": {
        "is_smart": True,
        "rules": [
            {"max_age": 12, "mg_kg": 0, "label": "Avoid in Infants < 1 Year"},
            {"max_age": 216, "mg_kg": 1, "label": "Standard Dose (1-3 mg/kg/day)"}
        ],
        "conc": 12.5, "vol": 1, "max": 50
    },
    # --- Respiratory ---
    "Combivent (Nebulizer)": {
        "is_smart": True,
        "rules": [
            {"max_age": 12, "mg_kg": 0.1, "label": "Infant Nebulization"},
            {"max_age": 216, "mg_kg": 0.15, "label": "Children Nebulization"}
        ],
        "conc": 2.5, "vol": 2.5, "max": 5
    },
    "Chlorpheniramine (Allerfin)": {
        "is_smart": True,
        "rules": [
            {"max_age": 24, "mg_kg": 0, "label": "Avoid < 2 Years (Sedation Risk)"},
            {"max_age": 216, "mg_kg": 0.1, "label": "Standard Pediatric Dose"}
        ],
        "conc": 2, "vol": 5, "max": 4
    },
    # --- GIT ---
    "Domperidone (Motilium)": {
        "is_smart": True,
        "rules": [
            {"max_age": 216, "mg_kg": 0.25, "label": "Standard Dose (TDS)"}
        ],
        "conc": 5, "vol": 5, "max": 10
    },
    "Ondansetron (Zofran)": {
        "is_smart": True,
        "rules": [
            {"max_age": 6, "mg_kg": 0, "label": "Not Recommended < 6 Months"},
            {"max_age": 216, "mg_kg": 0.15, "label": "Standard Dose"}
        ],
        "conc": 2, "vol": 1, "max": 8
    },
    "Hyoscine (Buscopan Syrup)": {
        "is_smart": True,
        "rules": [
            {"max_age": 72, "mg_kg": 0.5, "label": "Children 1-6 Years"},
            {"max_age": 216, "mg_kg": 0.7, "label": "Children > 6 Years"}
        ],
        "conc": 5, "vol": 5, "max": 10
    },
    "Cefixime (Susp)": {
        "is_smart": True,
        "rules": [
            {"max_age": 6, "mg_kg": 0, "label": "Infants < 6 Months (Not Recommended)"},
            {"max_age": 216, "mg_kg": 8, "label": "Children >= 6 Months (8 mg/kg/day)"}
        ],
        "conc": 200, "vol": 5, "max": 400,
        "notes": "Typically given orally as a suspension. Dosage is 8mg/kg/day, usually given once or divided BID."
    },
    # --- NEW MEDICATIONS ---
    "Albumin 25%": {
        "mg_kg": 250,
        "conc": 250,
        "vol": 1,
        "max": 100000,
        "notes": "Dose: 0.5-1 g/kg (2-4 ml/kg of 25% albumin). Infuse over 30-60 mins, faster in emergencies. Mg/kg is used as a placeholder here, actual calculation should be mL/kg."
    },
    "Digoxin (Oral Solution)": {
        "is_smart": True,
        "rules": [
            {"max_age": 1, "mg_kg": 0.005, "label": "Neonate Maintenance Dose (5 mcg/kg/day)"},
            {"max_age": 216, "mg_kg": 0.008, "label": "Infant/Child Maintenance Dose (8 mcg/kg/day)"}
        ],
        "conc": 0.05,
        "vol": 1,
        "max": 0.25,
        "notes": "Requires careful monitoring (ECG, electrolytes, levels). Dosage depends on loading dose and renal function. Doses are per day."
    },
    "Rabeprazole": {
        "is_smart": True,
        "rules": [
            {"max_age": 144, "mg_kg": 0.6, "label": "Children 1-11 Years (10mg total daily)"},
            {"max_age": 216, "mg_kg": 0.5, "label": "Children 12+ Years (20mg total daily)"}
        ],
        "conc": 10,
        "vol": 1,
        "max": 20,
        "notes": "Administer 30 mins before food. For GERD/peptic ulcers. The mg/kg values are an approximation for the total daily dose (10mg/day for 1-11y, 20mg/day for 12+y)."
    },
    "Amlodipine (Oral Solution)": {
        "is_smart": True,
        "rules": [
            {"max_age": 72, "mg_kg": 0.05, "label": "Children 1-5 Years (Initial Dose)"},
            {"max_age": 216, "mg_kg": 0.1, "label": "Children > 6 Years (Initial Dose)"}
        ],
        "conc": 1,
        "vol": 1,
        "max": 10,
        "notes": "Start low and titrate. Used for hypertension. Can be prepared from tablets."
    },
    "Zinc Syrup (Elemental)": {
        "is_smart": True,
        "rules": [
            {"max_age": 6, "mg_kg": 0.5, "label": "Infants 0-6 Months (2.5mg total daily)"},
            {"max_age": 12, "mg_kg": 0.6, "label": "Infants 6-12 Months (5mg total daily)"},
            {"max_age": 60, "mg_kg": 0.65, "label": "Children 1-5 Years (10mg total daily)"}
        ],
        "conc": 2,
        "vol": 1,
        "max": 10,
        "notes": "For diarrhea management (WHO protocol) or zinc deficiency. Administer away from dairy/iron. Doses are total elemental zinc per day."
    },
    "Vitamin D3 (Oral Drops)": {
        "is_smart": True,
        "rules": [
            {"max_age": 12, "mg_kg": 0.001, "label": "Infants 0-12 Months (400 IU/day)"},
            {"max_age": 216, "mg_kg": 0.001, "label": "Children >1 Year (600 IU/day)"}
        ],
        "conc": 0.01,
        "vol": 1,
        "max": 0.05,
        "notes": "Prophylaxis dose. 1 mcg = 40 IU. The mg/kg values are an approximation for the fixed total daily IU dose. Actual dosing is in IU."
    },
    "Calcium Supplemental Syrup (Elemental)": {
        "mg_kg": 25,
        "conc": 20,
        "vol": 1,
        "max": 1000,
        "notes": "For calcium deficiency. Elemental calcium varies by salt. Give in divided doses."
    }
}

# Expanded infusion drugs database
infusion_drugs_db = {
    "Dopamine": {
        "type": "Continuous",
        "dose_unit": "mcg/kg/min",
        "min_dose": 2,
        "max_dose": 20,
        "initial_dose": 5,
        "conc_per_ml": 4000,
        "conc_display_unit": "mg/ml",
        "dilution_info": "Standard: 200mg in 50ml NS"
    },
    "Adrenaline (Epinephrine)": {
        "type": "Continuous",
        "dose_unit": "mcg/kg/min",
        "min_dose": 0.05,
        "max_dose": 1.0,
        "initial_dose": 0.1,
        "conc_per_ml": 20,
        "conc_display_unit": "mg/ml",
        "dilution_info": "Standard: 1mg in 50ml NS"
    },
    "Fentanyl": {
        "type": "Continuous",
        "dose_unit": "mcg/kg/hr",
        "min_dose": 1,
        "max_dose": 5,
        "initial_dose": 2,
        "conc_per_ml": 10,
        "conc_display_unit": "mcg/ml",
        "dilution_info": "Standard: 500mcg in 50ml NS"
    },
    "Midazolam": {
        "type": "Continuous",
        "dose_unit": "mg/kg/hr",
        "min_dose": 0.05,
        "max_dose": 0.4,
        "initial_dose": 0.1,
        "conc_per_ml": 1,
        "conc_display_unit": "mg/ml",
        "dilution_info": "Standard: 50mg in 50ml NS"
    },
    "Insulin": {
        "type": "Insulin Unit Infusion",
        "dose_unit": "units/kg/hr",
        "min_dose": 0.01,
        "max_dose": 0.1,
        "initial_dose": 0.05,
        "conc_per_ml": 1,
        "conc_display_unit": "units/ml",
        "dilution_info": "Standard: 50 units Regular Insulin in 50ml NS"
    },
    "KCL Correction": {
        "type": "Kcl mEq/kg Correction",
        "dose_unit": "mEq/kg",
        "min_dose": 0.1,
        "max_dose": 0.5,
        "initial_dose": 0.2,
        "conc_per_ml": 2,
        "conc_display_unit": "mEq/ml",
        "dilution_info": "Standard KCL solution (e.g., 10mEq/5ml)"
    },
    "Magnesium Sulfate": {
        "type": "Continuous",
        "dose_unit": "mg/kg/hr",
        "min_dose": 10,
        "max_dose": 50,
        "initial_dose": 20,
        "conc_per_ml": 100,
        "conc_display_unit": "mg/ml",
        "dilution_info": "Standard: 5g MgSO4 in 50ml NS"
    },
    # --- New Infusion Entries ---
    "Cefotaxime": {
        "type": "Intermittent Dose Infusion",
        "is_smart": True,
        "dose_unit": "mg/kg",
        "rules": [
            {"max_age": 1, "mg_kg": 50, "label": "Neonate Dose (<1 month)"},
            {"max_age": 216, "mg_kg": 75, "label": "Standard Dose (Children)"}
        ],
        "conc_mg_ml": 100,
        "suggested_dilution_volume_ml": 50,
        "dilution_info": "Dilute in NS/D5W. Infuse over 30-60 min."
    },
    "Paracetamol (IV)": {
        "type": "Intermittent Dose Infusion",
        "is_smart": True,
        "dose_unit": "mg/kg",
        "rules": [
            {"max_age": 1, "mg_kg": 10, "label": "Neonate Dose (10 mg/kg)"},
            {"max_age": 216, "mg_kg": 10, "label": "Infant/Child Dose (10-15 mg/kg)"}
        ],
        "conc_mg_ml": 10,
        "suggested_dilution_volume_ml": 50,
        "dilution_info": "Infuse over 15 minutes. Consider dilution to 1-2 mg/ml for smaller volumes. Max 1000mg/dose."
    },
    "Meropenem": {
        "type": "Intermittent Dose Infusion",
        "is_smart": True,
        "dose_unit": "mg/kg",
        "rules": [
            {"max_age": 1, "mg_kg": 20, "label": "Neonate Dose (<1 month)"},
            {"max_age": 216, "mg_kg": 20, "label": "Children Dose"}
        ],
        "conc_mg_ml": 50,
        "suggested_dilution_volume_ml": 50,
        "dilution_info": "Dilute in NS. Infuse over 15-30 min."
    },
    "Vancomycin": {
        "type": "Intermittent Dose Infusion",
        "is_smart": True,
        "dose_unit": "mg/kg",
        "rules": [
            {"max_age": 1, "mg_kg": 12.5, "label": "Neonate Dose (<1 month)"},
            {"max_age": 216, "mg_kg": 15, "label": "Children Dose"}
        ],
        "conc_mg_ml": 50,
        "suggested_dilution_volume_ml": 100,
        "dilution_info": "Dilute in NS/D5W (max 5mg/ml). Infuse over 60 min (longer for higher doses) to avoid Red Man Syndrome."
    },
    "Dextrose % (Continuous)": {
        "type": "Continuous Dextrose Infusion",
        "dose_unit": "mg/kg/min (GIR)",
        "min_dose": 4,
        "max_dose": 10,
        "initial_dose": 6,
        "conc_available_percent": [5, 10, 12.5, 25],
        "dilution_info": "Glucose Infusion Rate (GIR) calculation. Select available dextrose concentration."
    },
    "Calcium Gluconate 10%": {
        "type": "Intermittent Dose Infusion",
        "is_smart": True,
        "dose_unit": "mg/kg",
        "rules": [
            {"max_age": 1, "mg_kg": 100, "label": "Neonate Dose (<1 month)"},
            {"max_age": 216, "mg_kg": 50, "label": "Child Dose (>1 month)"}
        ],
        "conc_mg_ml": 100,
        "suggested_dilution_volume_ml": 50,
        "dilution_info": "Slow IV Infusion over 30-60 min. Max infusion rate 50mg/kg/hr."
    },
    "Sodium Bicarbonate (NaHCO3)": {
        "type": "Intermittent mEq/kg Infusion",
        "is_smart": True,
        "dose_unit": "mEq/kg",
        "rules": [
            {"max_age": 216, "mEq_kg": 1, "label": "Standard Dose (1 mEq/kg)"}
        ],
        "conc_mEq_ml": 1,
        "suggested_dilution_volume_ml": 50,
        "dilution_info": "Infuse slowly over 30-60 min. Use with caution in neonates; dilute 1:1 with D5W. Max 1 mEq/kg/min."
    },
    "Furosemide (Lasix)": {
        "type": "Continuous",
        "dose_unit": "mg/kg/hr",
        "min_dose": 0.05,
        "max_dose": 0.4,
        "initial_dose": 0.1,
        "conc_per_ml": 1,
        "conc_display_unit": "mg/ml",
        "dilution_info": "Standard: 20mg in 20ml NS. Titrate to effect."
    },
    "Hydrocortisone": {
        "type": "Continuous",
        "dose_unit": "mg/kg/hr",
        "min_dose": 0.1,
        "max_dose": 0.4,
        "initial_dose": 0.2,
        "conc_per_ml": 1,
        "conc_display_unit": "mg/ml",
        "dilution_info": "Standard: 100mg in 100ml NS/D5W. For stress doses in adrenal insufficiency or shock."
    },
    "Ceftriaxone": {
        "type": "Intermittent Dose Infusion",
        "is_smart": True,
        "dose_unit": "mg/kg",
        "rules": [
            {"max_age": 1, "mg_kg": 50, "label": "Neonate Dose (<1 month)"},
            {"max_age": 12, "mg_kg": 80, "label": "Infant Dose (1-12 months)"},
            {"max_age": 216, "mg_kg": 85, "label": "Child Dose (>12 months)"}
        ],
        "conc_mg_ml": 100,
        "suggested_dilution_volume_ml": 50,
        "dilution_info": "Reconstitute to 100mg/ml, then dilute further in NS/D5W. Infuse over 30-60 min. Max 4g/day."
    },
    "Levetiracetam": {
        "type": "Intermittent Dose Infusion",
        "is_smart": True,
        "dose_unit": "mg/kg",
        "rules": [
            {"max_age": 216, "mg_kg": 40, "label": "Status Epilepticus Loading Dose"} # 20-60mg/kg
        ],
        "conc_mg_ml": 100, # Assuming 100mg/ml IV preparation
        "suggested_dilution_volume_ml": 50,
        "dilution_info": "**Status Epilepticus (SE) - Third-line (20-60 min):** If first and second-line therapies fail. Dilute to 10-20 mg/ml in NS or D5W. Infuse over 15-30 min. For maintenance, 10-30 mg/kg/dose BID IV/PO. Monitor for adverse effects."
    },
    "Diazepam (SE IV Bolus)": {
        "type": "Intermittent Dose Infusion",
        "is_smart": True,
        "dose_unit": "mg/kg",
        "rules": [
            {"max_age": 1, "mg_kg": 0.15, "label": "Neonate Dose (<1 month)"},
            {"max_age": 216, "mg_kg": 0.35, "label": "Infant/Child Dose"}
        ],
        "conc_mg_ml": 2.5,
        "suggested_dilution_volume_ml": 0,
        "dilution_info": "**Status Epilepticus (SE) - First-line (0-5 min):** Administer slow IV (undiluted or diluted in NS/D5W). Max 5mg (<5yr) or 10mg (>=5yr) per dose. Repeat once after 5-10 min if SE persists. Max 2 doses. If SE continues after 10 min (total 15 min), proceed to Second-line."
    },
    "Midazolam (SE IV Bolus)": {
        "type": "Intermittent Dose Infusion",
        "is_smart": True,
        "dose_unit": "mg/kg",
        "rules": [
            {"max_age": 1, "mg_kg": 0.05, "label": "Neonate Dose (<1 month)"},
            {"max_age": 216, "mg_kg": 0.15, "label": "Infant/Child Dose"}
        ],
        "conc_mg_ml": 1,
        "suggested_dilution_volume_ml": 0,
        "dilution_info": "**Status Epilepticus (SE) - First-line (0-5 min):** Administer IV/IM/buccal (can be diluted in NS/D5W). Max 5mg (<5yr) or 10mg (>=5yr) per dose. Repeat once after 5-10 min if SE persists. Max 2 doses. If SE continues after 10 min (total 15 min), proceed to Second-line."
    },
    "Phenobarbital (SE IV Loading)": {
        "type": "Intermittent Dose Infusion",
        "is_smart": True,
        "dose_unit": "mg/kg",
        "rules": [
            {"max_age": 1, "mg_kg": 15, "label": "Neonate Dose (<1 month)"},
            {"max_age": 216, "mg_kg": 20, "label": "Infant/Child Dose"}
        ],
        "conc_mg_ml": 60,
        "suggested_dilution_volume_ml": 50,
        "dilution_info": "**Status Epilepticus (SE) - Second-line (5-20 min):** If first-line benzodiazepines fail. Loading dose: 15-20 mg/kg IV over 10-20 min. May repeat 5-10 mg/kg once if SE persists (up to max total 40 mg/kg). Dilute in NS. If SE continues after 20 min (total 35 min), consider Third-line."
    },
    "Phenytoin (SE IV Loading)": {
        "type": "Intermittent Dose Infusion",
        "is_smart": True,
        "dose_unit": "mg/kg",
        "rules": [
            {"max_age": 1, "mg_kg": 15, "label": "Neonate Dose (<1 month)"},
            {"max_age": 216, "mg_kg": 20, "label": "Infant/Child Dose"}
        ],
        "conc_mg_ml": 50,
        "suggested_dilution_volume_ml": 50,
        "dilution_info": "**Status Epilepticus (SE) - Second-line (5-20 min):** If first-line benzodiazepines fail. Loading dose: 15-20 mg/kg IV over 10-20 min (max infusion rate 1 mg/kg/min). Dilute in NS only, do NOT use D5W. Monitor ECG/BP. If SE continues after 20 min (total 35 min), consider Third-line."
    },
    # --- Transfusion Products ---
    "Packed RBCs (PRBCs transfusion)": {
        "type": "Bolus Transfusion",
        "dose_unit": "mL/kg",
        "min_dose": 10,
        "max_dose": 15,
        "initial_dose": 10,
        "max_total_ml": 300,
        "dilution_info": "To raise Hb ~2-3 g/dL; Slow infusion"
    },
    "Platelets transfusion": {
        "type": "Bolus Transfusion",
        "dose_unit": "mL/kg",
        "min_dose": 10,
        "max_dose": 15,
        "initial_dose": 10,
        "max_total_ml": 300,
        "dilution_info": "10-15 mL/kg; Neonates: smaller volumes; Raise platelets ~30-50k"
    },
    "Fresh Frozen Plasma (FFP)": {
        "type": "Bolus Transfusion",
        "dose_unit": "mL/kg",
        "min_dose": 10,
        "max_dose": 15,
        "initial_dose": 10,
        "max_total_ml": 300,
        "dilution_info": "10-15 mL/kg for coagulopathy; Neonates: 10-20 mL/kg"
    },
    "Whole Blood / Fresh Blood transfusion": {
        "type": "Bolus Transfusion",
        "dose_unit": "mL/kg",
        "min_dose": 20,
        "max_dose": 25,
        "initial_dose": 20,
        "max_total_ml": 500,
        "dilution_info": "20 mL/kg in acute blood loss; Neonates: cautious volume"
    },
    "Artesunate (Anti-Malarial)": {
        "type": "Weight Logic",
        "standard_conc": 10,
        "dilution_info": "60mg vial + 6ml Sodium Chloride 0.9%",
        "unit": "mg/kg"
    }
}

# Simplified WHO growth data (Weight-for-Age for Boys 0-5 years) - example data in kg
# Source: WHO Growth Standards (simplified for demonstration)
who_growth_data_boys = {
    0: {'p3': 2.3, 'p15': 2.7, 'p50': 3.3, 'p85': 4.0, 'p97': 4.8},
    1: {'p3': 3.2, 'p15': 3.7, 'p50': 4.5, 'p85': 5.5, 'p97': 6.5},
    2: {'p3': 4.0, 'p15': 4.6, 'p50': 5.6, 'p85': 6.8, 'p97': 7.8},
    3: {'p3': 4.6, 'p15': 5.3, 'p50': 6.4, 'p85': 7.7, 'p97': 8.8},
    4: {'p3': 5.0, 'p15': 5.8, 'p50': 6.9, "p85": 8.3, 'p97': 9.5},
    5: {'p3': 5.4, 'p15': 6.2, 'p50': 7.4, 'p85': 8.9, 'p97': 10.1},
    6: {'p3': 5.7, 'p15': 6.5, 'p50': 7.8, 'p85': 9.3, 'p97': 10.5},
    7: {'p3': 5.9, 'p15': 6.7, 'p50': 8.0, 'p85': 9.6, 'p97': 10.8},
    8: {'p3': 6.0, 'p15': 6.9, 'p50': 8.2, 'p85': 9.8, 'p97': 11.0},
    9: {'p3': 6.2, 'p15': 7.1, 'p50': 8.4, 'p85': 10.0, 'p97': 11.2},
    10: {'p3': 6.4, 'p15': 7.2, 'p50': 8.6, 'p85': 10.2, 'p97': 11.4},
    11: {'p3': 6.5, 'p15': 7.4, 'p50': 8.7, 'p85': 10.4, 'p97': 11.6},
    12: {'p3': 6.6, 'p15': 7.5, 'p50': 8.9, 'p85': 10.5, 'p97': 11.7},
    18: {'p3': 7.4, 'p15': 8.3, 'p50': 9.9, 'p85': 11.8, 'p97': 13.0},
    24: {'p3': 8.0, 'p15': 9.0, 'p50': 10.6, 'p85': 12.7, 'p97': 14.1},
    30: {'p3': 8.6, 'p15': 9.6, 'p50': 11.3, 'p85': 13.5, 'p97': 15.0},
    36: {'p3': 9.0, 'p15': 10.1, "p50": 11.9, 'p85': 14.2, 'p97': 15.8},
    48: {'p3': 9.8, 'p15': 11.0, 'p50': 12.9, 'p85': 15.4, 'p97': 17.1},
    60: {'p3': 10.4, 'p15': 11.7, 'p50': 13.7, 'p85': 16.4, 'p97': 18.2}
}

# WHO growth data for Girls 0-5 years (simplified for demonstration)
# Source: WHO Growth Standards
who_growth_data_girls = {
    0: {'p3': 2.2, 'p15': 2.5, 'p50': 3.2, 'p85': 3.8, 'p97': 4.5},
    1: {'p3': 3.0, 'p15': 3.5, 'p50': 4.2, 'p85': 5.2, 'p97': 6.0},
    2: {'p3': 3.7, 'p15': 4.3, 'p50': 5.2, 'p85': 6.3, 'p97': 7.3},
    3: {'p3': 4.2, 'p15': 4.9, 'p50': 5.8, 'p85': 7.0, 'p97': 8.0},
    4: {'p3': 4.5, "p15": 5.3, "p50": 6.3, "p85": 7.5, "p97": 8.6},
    5: {'p3': 4.8, 'p15': 5.6, 'p50': 7.7, 'p85': 8.0, 'p97': 9.0},
    6: {'p3': 5.0, 'p15': 5.8, 'p50': 6.9, 'p85': 8.2, 'p97': 9.3},
    7: {'p3': 5.1, 'p15': 6.0, 'p50': 7.1, 'p85': 8.4, 'p97': 9.5},
    8: {'p3': 5.3, 'p15': 6.1, 'p50': 7.3, 'p85': 8.6, 'p97': 9.7},
    9: {'p3': 5.4, 'p15': 6.3, 'p50': 7.5, 'p85': 8.8, 'p97': 9.9},
    10: {'p3': 5.5, 'p15': 6.4, 'p50': 7.6, 'p85': 9.0, 'p97': 10.1},
    11: {'p3': 5.6, 'p15': 6.5, 'p50': 7.8, 'p85': 9.2, 'p97': 10.3},
    12: {'p3': 5.7, 'p15': 6.7, 'p50': 7.9, 'p85': 9.3, 'p97': 10.4},
    18: {'p3': 6.4, 'p15': 7.4, 'p50': 8.8, 'p85': 10.4, 'p97': 11.5},
    24: {'p3': 7.0, 'p15': 8.0, 'p50': 9.5, 'p85': 11.2, 'p97': 12.5},
    30: {'p3': 7.5, 'p15': 8.5, 'p50': 10.1, 'p85': 11.9, 'p97': 13.3},
    36: {'p3': 7.9, 'p15': 9.0, "p50": 10.6, 'p85': 12.5, 'p97': 14.0},
    48: {'p3': 9.8, 'p15': 11.0, 'p50': 12.9, 'p85': 15.4, 'p97': 17.1},
    60: {'p3': 10.4, 'p15': 11.7, 'p50': 13.7, 'p85': 16.4, 'p97': 18.2}
}

# 3. Session State for Patient History (updated to load from SQLite)
if 'log' not in st.session_state:
    with sqlite3.connect(DB_FILE) as conn:
        st.session_state.log = pd.read_sql_query('SELECT Timestamp AS "Time", Patient, Age_Mo AS "Age(Mo)", Weight_kg AS "Weight(kg)", Dept, Action, Result FROM patient_log', conn)

# 4. Sidebar
with st.sidebar:
    st.markdown(
        """
        <div class="sidebar-elite-header">
            <div class="sidebar-badge">
                <span class="sidebar-badge-dot"></span>
                <span>Live Pediatric Case</span>
            </div>
            <div class="sidebar-title">Patient Console</div>
            <div class="sidebar-subtitle">
                Adjust age, weight, and sex to update all dosing & growth outputs.
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.markdown(
        """
        <div class="sidebar-patient-chip">
            <div class="sidebar-patient-main">
                <div class="sidebar-patient-avatar">🧒</div>
                <div class="sidebar-patient-info">
                    <div class="sidebar-patient-name">Active record</div>
                    <div class="sidebar-patient-meta">Edit fields below to personalize</div>
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # Small tags underneath - MOVED HERE
    st.markdown(
        """
        <div class="sidebar-pill-row" style="margin-top: 0.5rem; margin-bottom: 0.75rem; justify-content: flex-start;">
        </div>
        """,
        unsafe_allow_html=True,
    )

    # --- DEMOGRAPHICS ---
    st.markdown('<div class="sidebar-section-label">Demographics</div>', unsafe_allow_html=True)
    p_name = st.text_input("Patient Name", value="New Patient")
    p_gender = st.selectbox("Gender", ["Boy", "Girl"])
    p_dept = st.selectbox("Department/Case Type:", ["Internal Medicine", "Surgery", "Emergency 🚨", "Chronic Disease", "Other"])

    # Age Input Options
    age_unit = st.radio(
        "Age Unit",
        ["Days (neonate)", "Months (infant/child)", "Years (>1 year)"],
        index=1,
        horizontal=False,
        key="age_unit_radio"
    )

    p_age_months = 0.0 # Initialize p_age_months as float

    if age_unit == "Days (neonate)":
        age_value = st.number_input("Age (days)", min_value=0.0, max_value=60.0, value=10.0, step=1.0, key="age_days_input")
        p_age_months = age_value / 30.4375 # Using average days in a month
    elif age_unit == "Months (infant/child)":
        age_value = st.number_input("Age (months)", min_value=0.0, max_value=216.0, value=12.0, step=0.5, key="age_months_input") # Max age in app.py is 216
        p_age_months = age_value
    else:  # Years (>1 year)
        age_value = st.number_input("Age (years)", min_value=1.0, max_value=18.0, value=1.0, step=0.5, key="age_years_input")
        p_age_months = age_value * 12.0

    st.markdown('<hr class="sidebar-divider">', unsafe_allow_html=True)

    # --- ANTHROPOMETRICS ---
    st.markdown(
        """
        <div class="sidebar-section-label">
            Anthropometrics
        </div>
        <div class="sidebar-timeline">
            <div style="display:flex; align-items:center; gap:0.45rem;">
                <div class="sidebar-timeline-dot"></div>
                <div style="font-size:0.76rem; color:#9ca3af;">
                    Weight drives both medication dosing and WHO centile mapping.
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    p_weight = st.number_input("Weight (kg)", 0.5, 80.0, 10.0, 0.1)

    st.markdown("</div></div>", unsafe_allow_html=True) # Closing the glass panel and wrap
    st.divider() # Keep existing divider for search bars

    # Search bars (kept from previous version)
    search_drug = st.text_input("🔍 Search oral/IV med...")
    search_infusion = st.text_input("🔍 Search infusion med...")

# Filter drug list based on search (for tabs)
filtered_drugs = {k: v for k, v in drugs.items() if search_drug.lower() in k.lower()}
filtered_infusions = {k: v for k, v in infusion_drugs_db.items() if search_infusion.lower() in k.lower()}

# 5. Main Tabs
tab1, tab2, tab3, tab4 = st.tabs(["👤 Patient Information", "📈 Growth Chart", "💊 Medications & Doses", "💧 Fluids & Critical Care"])

with tab1: # Patient Information tab
    # 1. Define aesthetic styling (CSS) - put it once at the beginning of the tab
    st.markdown("""
        <style>
        .main-card {
            background-color: white;
            border-radius: 22px;
            padding: 18px 25px;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 4px 15px rgba(0,0,0,0.06);
            border: 1px solid #f1f3f8;
        }
        .card-content {
            flex-grow: 1;
        }
        .card-label {
            font-size: 0.85rem;
            color: #6c757d;
            text-transform: uppercase;
            font-weight: 600;
            margin-bottom: 5px;
            display: block;
        }
        .card-value {
            font-size: 1.5rem;
            font-weight: 700;
            color: #343a40;
        }
        .icon-box {
            width: 70px;
            height: 70px;
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            background: linear-gradient(135deg, #a8c0ff 0%, #392b45 100%); /* Blue-purple gradient */
            box-shadow: 0 4px 10px rgba(0,0,0,0.2);
        }
        .card-img {
            width: 45px;
            height: 45px;
            object-fit: contain;
            filter: brightness(0) invert(1); /* Makes the image white */
        }

        .assessment-alert {
            background-color: #fff3cd;
            border-left: 5px solid #ffc107;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 4px;
            color: #664d03;
            font-size: 0.9em;
        }
        .assessment-success {
            background-color: #d1e7dd;
            border-left: 5px solid #198754;
            padding: 10px;
            margin-bottom: 10px;
            border-radius: 4px;
            color: #0f5132;
            font-size: 0.9em;
        }
        </style>
    """, unsafe_allow_html=True)


    # 2. Data Cards (Name, Gender, Age, Weight)

    # Name card
    st.markdown(f"""
        <div class="main-card">
            <div class="card-content">
                <span class="card-label">FULL NAME</span><br>
                <span class="card-value">{p_name}</span>
            </div>
            <div class="icon-box">
                <img src="{user_icon_url}" class="card-img">
            </div>
        </div>
    """, unsafe_allow_html=True)

    # Gender card - with variable icon
    gender_img_url = boy_icon_url if p_gender == "Boy" else girl_icon_url
    gender_color = "#3498db" if p_gender == "Boy" else "#e91e63"

    st.markdown(f"""
        <div class="main-card">
            <div class="card-content">
                <span class="card-label">GENDER</span><br>
                <span class="card-value" style="color: {gender_color};">{p_gender}</span>
            </div>
            <div class="icon-box">
                <img src="{gender_img_url}" class="card-img">
            </div>
        </div>
    """, unsafe_allow_html=True)

    # Age card
    st.markdown(f"""
        <div class="main-card">
            <div class="card-content">
                <span class="card-label">AGE</span><br>
                <span class="card-value">{round(p_age_months, 1)} Months</span>
            </div>
            <div class="icon-box">
                <img src="{calendar_icon_url}" class="card-img">
            </div>
        </div>
    """, unsafe_allow_html=True)

    # Weight card
    st.markdown(f"""
        <div class="main-card">
            <div class="card-content">
                <span class="card-label">WEIGHT</span><br>
                <span class="card-value">{p_weight} kg</span>
            </div>
            <div class="icon-box">
                <img src="{scale_icon_url}" class="card-img">
            </div>
        </div>
    """, unsafe_allow_html=True)

with tab2: # Growth Chart tab
    st.subheader("Growth Chart and Assessment")
    weight_assessment_feedback = "" # Initialize feedback
    growth_fig = None # Initialize figure

    # Select appropriate growth data based on gender
    selected_growth_data = who_growth_data_boys if p_gender == "Boy" else who_growth_data_girls

    # Display the growth chart plot
    if p_age_months <= 60:
        growth_fig = plot_growth_chart(p_age_months, p_weight, selected_growth_data, p_gender)
        st.markdown("<br>", unsafe_allow_html=True)
        with st.expander("📈 View Growth Chart Details (WHO Chart)", expanded=True):
            st.pyplot(growth_fig)
    else:
        st.info("Growth chart data available for ages 0-60 months.")

    # Growth assessment text feedback
    ideal_w = (p_age_months + 9) / 2 # This is a very rough estimate and would ideally be gender-specific too
    if p_weight < ideal_w - 2:
        weight_assessment_feedback = f"Child's weight ({p_weight} kg) is lower than the ideal weight ({round(ideal_w, 1)} kg). May require nutritional review."
        st.markdown(f"""
            <div class="assessment-alert">
                <strong>⚠️ Alert:</strong> {weight_assessment_feedback}
            </div>
        """, unsafe_allow_html=True)
    elif p_weight > ideal_w + 2:
        weight_assessment_feedback = f"Child's weight ({p_weight} kg) is higher than the ideal weight ({round(ideal_w, 1)} kg). May require nutritional review."
        st.markdown(f"""
            <div class="assessment-alert">
                <strong>⚠️ Alert:</b> {weight_assessment_feedback}
            </div>
        """, unsafe_allow_html=True)
    else:
        weight_assessment_feedback = f"Child's weight ({p_weight} kg) is approximately within the normal range for their age."
        st.markdown(f"""
            <div class="assessment-success">
                <strong>✅ Weight Assessment:</b> {weight_assessment_feedback}
            </div>
        """, unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True) # Add spacing here
    # Add the print button for the growth report
    if growth_fig is not None and st.button("Print Growth Report", key="print_growth_report"):
        pdf_path = generate_growth_report_pdf(
            p_name,
            p_gender,
            p_age_months,
            p_weight,
            growth_fig,
            weight_assessment_feedback
        )
        with open(pdf_path, "rb") as pdf_file:
            st.download_button(
                label="Download Growth Report PDF",
                data=pdf_file.read(),
                file_name=f"GrowthReport_{p_name}.pdf",
                mime="application/pdf"
            )

with tab3: # Medications & Doses
    st.markdown(
        """
        <div style="display:flex; align-items:flex-start; justify-content:space-between; gap:1.2rem; margin-bottom:0.6rem;">
            <div>
                </h3>
                <p style="margin:0; color:#64748b; font-size:0.86rem;">
                    Weight-based pediatric dosing with age-smart rules and quick volume visualization.
                </p>
            </div>
            <div style="
                padding:0.4rem 0.75rem;
                border-radius:999px;
                background:linear-gradient(120deg,#22c55e,#a3e635);
                color:#052e16;
                font-size:0.75rem;
                font-weight:700;
                display:flex;
                align-items:center;
                gap:0.35rem;
                box-shadow:0 8px 15px rgba(22,163,74,0.5);
            ">
                <span><span><span>Active</span>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    col_left, col_right = st.columns([1.1, 1])

    # LEFT: drug selection
    with col_left:
        st.markdown(
            """
            <div style="
                border-radius:1.1rem;
                padding:0.8rem 0.9rem 0.9rem 0.9rem;
                background:linear-gradient(135deg,#f8fafc,#e2e8f0);
                box-shadow:0 14px 25px rgba(148,163,184,0.45);
                border:1px solid rgba(148,163,184,0.55);
            ">
            <div style="font-size:0.78rem; text-transform:uppercase; letter-spacing:0.12em; color:#64748b; margin-bottom:0.35rem; font-weight:700;">
                    Drug selection
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )
        drug_list = sorted(filtered_drugs.keys())
        if drug_list:
            selected_drug = st.selectbox("",drug_list, key="med_tab_drug")
            d = filtered_drugs[selected_drug]

            mg_per_kg, chosen_label = get_smart_dose(d, p_age_months)

            # Display safety message for smart drugs separately
            st.markdown(f"""<div class="custom-info">🛡️ <span style="color:#bfdbfe;">Safety Check:</span> Detected Category: {chosen_label} Using {mg_per_kg} mg/kg</div>""", unsafe_allow_html=True)

            potential_mg_dose = p_weight * mg_per_kg
            was_capped = False
            if potential_mg_dose > d['max']:
                st.markdown(f"""<div class="custom-error">🚨 <span style="color:#bfdbfe;">Alert:</span> Calculated dose ({round(potential_mg_dose, 1)} mg) exceeds the maximum allowed dose ({d['max']} mg). The dose has been capped at {d['max']} mg.</div>""", unsafe_allow_html=True)
                was_capped = True

            total_mg = min(potential_mg_dose, d['max'])
            ml_dose = None
            if "conc" in d and "vol" in d:
                ml_dose = (total_mg * d['vol']) / d['conc']

            st.markdown(
                """
                <div style="margin-top:0.25rem; font-size:0.8rem; color:#64748b;">
                    Smart rules will auto-adjust mg/kg by age bracket when available.
                </div>
                </div>
                """,
                unsafe_allow_html=True,
            )
        else:
            st.error("No matching medication found.")
            mg_per_kg = 0
            total_mg = 0
            ml_dose = 0

    # RIGHT: dose summary
    with col_right:
        # Title bar for the panel
        st.markdown(
            """
            <div style="
                border-radius:1.1rem;
                padding:0.75rem 0.9rem 0.55rem 0.9rem;
                background:radial-gradient(circle at 0% 0%, #dbeafe, #eff6ff);
                box-shadow:0 12px 22px rgba(129,140,248,0.45);
                border:1px solid rgba(129,140,248,0.65);
                margin-bottom:0.35rem;
            ">
                <div style="font-size:0.78rem; text-transform:uppercase; letter-spacing:0.12em;
                            color:#4b5563; margin-bottom:0.25rem; font-weight:700;">
                    Dose summary
                </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

        panels_html = f"""
            <div style="display:flex; flex-direction:column; gap:0.45rem;">

                <!-- Panel 1: mg/kg -->
                <div style="
                    border-radius:0.9rem;
                    padding:0.45rem 0.65rem;
                    background:linear-gradient(135deg,#eff6ff,#e0f2fe);
                    border:1px solid rgba(129,140,248,0.55);
                    display:flex;
                    justify-content:space-between;
                    align-items:center;
                ">
                    <div style="display:flex; flex-direction:column;">
                        <span style="font-size:0.74rem; text-transform:uppercase; letter-spacing:0.14em;
                                     color:#4b5563; font-weight:600;">
                            Dose (mg/kg)
                        </span>
                        <span style="font-size:0.86rem; color:#111827; font-weight:700;">
                            {mg_per_kg:.1f}
                        </span>
                    </div>
                </div>

                <!-- Panel 2: total mg -->
                <div style="
                    border-radius:0.9rem;
                    padding:0.45rem 0.65rem;
                    background:linear-gradient(135deg,#eef2ff,#e5e7eb);
                    border:1px solid rgba(99,102,241,0.65);
                    display:flex;
                    justify-content:space-between;
                    align-items:center;
                ">
                    <div style="display:flex; flex-direction:column;">
                        <span style="font-size:0.74rem; text-transform:uppercase; letter-spacing:0.14em;
                                     color:#4b5563; font-weight:600;">
                            Total (mg)
                        </span>
                        <span style="font-size:0.86rem; color:#111827; font-weight:700;">
                            {total_mg:.1f}
                        </span>
                    </div>
                </div>

                <!-- Panel 3: volume ml -->
                <div style="
                    border-radius:0.9rem;
                    padding:0.45rem 0.65rem;
                    background:linear-gradient(135deg,#f0fdf4,#dcfce7);
                    border:1px solid rgba(34,197,94,0.65);
                    display:flex;
                    justify-content:space-between;
                    align-items:center;
                ">
                    <div style="display:flex; flex-direction:column;">
                        <span style="font-size:0.74rem; text-transform:uppercase; letter-spacing:0.14em;
                                     color:#166534; font-weight:600;">
                            Volume (ml)
                        </span>
                        <span style="font-size:0.86rem; color:#064e3b; font-weight:700;">
                            {"—" if ml_dose is None else f"{ml_dose:.2f}"}
                        </span>
                    </div>
                </div>

            </div>
            """
        st.markdown(panels_html, unsafe_allow_html=True)

        # Clinical note below panels
        if drug_list and "notes" in d:
            st.markdown(
                f"""
                <div style="
                    margin-top:0.45rem;
                    padding:0.45rem 0.55rem;
                    border-radius:0.8rem;
                    background:rgba(15,23,42,0.94);
                    color:#e5e7eb;
                    font-size:0.78rem;
                    border:1px solid rgba(148,163,184,0.6);
                ">
                    <span style="font-weight:600; color:#bfdbfe;">Clinical note:</span>
                    <span>{d["notes"]}</span>
                </div>
                """,
                unsafe_allow_html=True,
            )


    st.markdown("--- ---")

    c1, c2 = st.columns([0.6, 0.4])
    with c1:
        st.caption("Use this panel for single-dose prescription checks; always cross-check with institutional protocols.")
    with c2:
        if drug_list and st.button("📄 Generate Prescription PDF", key="rx_pdf_advanced"):
            if ml_dose is not None:
                # Call the existing generate_pdf_prescription function
                pdf_path = generate_pdf_prescription(p_name, selected_drug, total_mg, ml_dose)
                with open(pdf_path, "rb") as pdf_file:
                    st.download_button(
                        "⬇️ Download Prescription PDF",
                        pdf_file.read(),
                        f"{p_name}_{selected_drug.replace(' ', '_')}.pdf",
                        "application/pdf"
                    )
            else:
                st.warning("Cannot generate PDF: Volume to administer is not available.")


with tab4: # Fluids & Critical Care
    st.subheader("Holliday-Segar Maintenance Fluids")
    # Holliday-Segar formula
    if p_weight <= 10:
        maintenance_rate = p_weight * 4
    elif p_weight <= 20:
        maintenance_rate = 40 + (p_weight - 10) * 2
    else:
        maintenance_rate = 60 + (p_weight - 20) * 1
    st.metric("IV Maintenance Rate", f"{maintenance_rate} ml/hr")
    st.write(f"Total daily fluids: {maintenance_rate * 24} ml/day")

    # Log button for IVF Maintenance
    if st.button("Save IVF Maintenance to Log", key="log_ivf"):
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        new_log_entry = {
            'Time': current_time,
            'Patient': p_name if p_name else 'N/A',
            'Age(Mo)': p_age_months,
            'Weight(kg)': p_weight,
            'Dept': p_dept,
            'Action': "Calculated IVF Maintenance",
            'Result': f"Rate: {maintenance_rate} ml/hr ({maintenance_rate * 24} ml/day)"
        }
        # Insert into SQLite
        with sqlite3.connect(DB_FILE) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO patient_log (Timestamp, Patient, Age_Mo, Weight_kg, Dept, Action, Result)
                    VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (current_time, new_log_entry['Patient'], new_log_entry['Age(Mo)'], new_log_entry['Weight(kg)'], new_log_entry['Dept'], new_log_entry['Action'], new_log_entry['Result']))
                conn.commit()

        # Update session state log
        st.session_state.log = pd.concat([st.session_state.log, pd.DataFrame([new_log_entry])], ignore_index=True)
        st.balloons()
        st.toast("Logged IVF maintenance rate for {p_name}.")

    st.divider()
    st.subheader("💉 Syringe Pump & Infusion Rates")
    if filtered_infusions:
        selected_infusion = st.selectbox("Select Infusion Drug:", list(filtered_infusions.keys()), key="infusion_select")
        inf_data = filtered_infusions[selected_infusion]

        infusion_rate_ml_hr = 0
        log_details = ""
        dose_val = 0

        col_input, col_output = st.columns(2)

        if inf_data['type'] == "Continuous":
            with col_input:
                dose_val = st.slider(f"Dose ({inf_data['dose_unit']})",
                                     float(inf_data['min_dose']),
                                     float(inf_data['max_dose']),
                                     float(inf_data['initial_dose']),
                                     step=(float(inf_data['max_dose']) - float(inf_data['min_dose']))/20,
                                     key=f"dose_slider_{selected_infusion}")
            with col_output:
                if "mcg/kg/min" in inf_data['dose_unit']:
                    infusion_rate_ml_hr = (dose_val * p_weight * 60) / inf_data['conc_per_ml']
                elif "mg/kg/hr" in inf_data['dose_unit']:
                    infusion_rate_ml_hr = (dose_val * p_weight) / (inf_data['conc_per_ml'] if inf_data['conc_per_ml'] != 0 else 1)
                elif "mcg/kg/hr" in inf_data['dose_unit']:
                    infusion_rate_ml_hr = (dose_val * p_weight) / (inf_data['conc_per_ml'] if inf_data['conc_per_ml'] != 0 else 1)

                st.metric(f"Pump Rate", f"{round(infusion_rate_ml_hr, 2)} ml/hr")
                st.caption(f"{inf_data['dilution_info']} (Conc: {inf_data['conc_per_ml']} {inf_data['conc_display_unit']})")
                log_details = f"Type: {inf_data['type']}, Dose: {dose_val} {inf_data['dose_unit']}, Conc: {inf_data['conc_per_ml']} {inf_data['conc_display_unit']}, Rate: {round(infusion_rate_ml_hr, 2)} ml/hr"

        elif inf_data['type'] == "Insulin Unit Infusion":
            with col_input:
                dose_val = st.slider(f"Dose ({inf_data['dose_unit']})",
                                     float(inf_data['min_dose']),
                                     float(inf_data['max_dose']),
                                     float(inf_data['initial_dose']),
                                     step=(float(inf_data['max_dose']) - float(inf_data['min_dose']))/20,
                                     key=f"dose_slider_{selected_infusion}")
            with col_output:
                infusion_rate_ml_hr = (dose_val * p_weight) / (inf_data['conc_per_ml'] if inf_data['conc_per_ml'] != 0 else 1)
                st.metric(f"Pump Rate", f"{round(infusion_rate_ml_hr, 2)} ml/hr")
                st.caption(f"{inf_data['dilution_info']} (Conc: {inf_data['conc_per_ml']} {inf_data['conc_display_unit']})")
                log_details = f"Type: {inf_data['type']}, Dose: {dose_val} {inf_data['dose_unit']}, Conc: {inf_data['conc_per_per_ml']} {inf_data['conc_display_unit']}, Rate: {round(infusion_rate_ml_hr, 2)} ml/hr"

        elif inf_data['type'] == "Kcl mEq/kg Correction":
            with col_input:
                kcl_dose_mEq_kg = st.slider(f"KCL Dose ({inf_data['dose_unit']})",
                                            float(inf_data['min_dose']),
                                            float(inf_data['max_dose']),
                                            float(inf_data['initial_dose']),
                                            step=(float(inf_data['max_dose']) - float(inf_data['min_dose']))/20,
                                            key=f"kcl_dose_slider_{selected_infusion}")
                infusion_duration_hr = st.number_input("Infusion Duration (hours)", 1, 24, 4, key=f"duration_{selected_infusion}")
            with col_output:
                total_mEq_needed = kcl_dose_mEq_kg * p_weight
                total_ml_to_infuse = total_mEq_needed / (inf_data['conc_per_ml'] if inf_data['conc_per_ml'] != 0 else 1)
                infusion_rate_ml_hr = total_ml_to_infuse / infusion_duration_hr

                st.metric(f"Pump Rate", f"{round(infusion_rate_ml_hr, 2)} ml/hr")
                st.caption(f"Total KCL: {round(total_mEq_needed, 2)} mEq | Total Vol: {round(total_ml_to_infuse, 2)} ml")
                log_details = f"Type: {inf_data['type']}, Dose: {kcl_dose_mEq_kg} {inf_data['dose_unit']}, Total mEq: {round(total_mEq_needed, 1)}, Duration: {infusion_duration_hr} hr, Rate: {round(infusion_rate_ml_hr, 2)} ml/hr"

        elif inf_data['type'] == "Bolus Transfusion":
            with col_input:
                dose_val_ml_kg = st.slider(f"Dose ({inf_data['dose_unit']})",
                                            float(inf_data['min_dose']),
                                            float(inf_data['max_dose']),
                                            float(inf_data['initial_dose']),
                                            step=1.0,
                                            key=f"dose_slider_{selected_infusion}")
            with col_output:
                total_volume_ml = dose_val_ml_kg * p_weight
                st.metric(f"Total Volume to Infuse", f"{round(total_volume_ml, 2)} mL")
                st.caption(inf_data['dilution_info'])

                if total_volume_ml > inf_data['max_total_ml']:
                    st.warning(f"⚠️ Alert: Calculated total volume ({round(total_volume_ml, 1)} mL) exceeds typical max for a single transfusion ({inf_data['max_total_ml']} mL). Review guidance.")

                log_details = f"Type: {inf_data['type']}, Dose: {dose_val_ml_kg} {inf_data['dose_unit']}, Total Vol: {round(total_volume_ml, 2)} mL"

        elif inf_data['type'] == "Weight Logic": # For Artesunate
            art_mg_kg = 0
            if p_weight < 20:
                art_mg_kg = 3.0
                st.markdown(f"""<div class="custom-info">⚖️ <span style="color:#bfdbfe;">Weight < 20kg: Using</span> **{art_mg_kg} mg/kg** (WHO Protocol)</div>""", unsafe_allow_html=True)
            else:
                art_mg_kg = 2.4
                st.markdown(f"""<div class="custom-info">⚖️ <span style="color:#bfdbfe;">Weight ≥ 20kg: Using</span> **{art_mg_kg} mg/kg** (WHO Protocol)</div>""", unsafe_allow_html=True)

            # Calculations
            total_mg_needed = p_weight * art_mg_kg
            total_ml_needed = total_mg_needed / inf_data["standard_conc"]

            # Display results
            st.divider()
            c1, c2, c3 = st.columns(3)
            c1.metric("Calculated Dose", f"{round(total_mg_needed, 1)} mg")
            c2.metric("Volume to Inject", f"{round(total_ml_needed, 2)} ml")
            c3.metric("Concentration", f"{inf_data['standard_conc']} mg/ml")

            st.caption(f"ℹ️ **Preparation:** {inf_data['dilution_info']}")
            log_details = f"Type: {inf_data['type']}, Dose: {art_mg_kg} mg/kg, Total mg: {round(total_mg_needed, 1)}, Total ml: {round(total_ml_needed, 2)}"


        # --- New Intermittent Infusion Types ---
        elif inf_data['type'] == "Intermittent Dose Infusion":
            chosen_dose_per_kg = 0
            chosen_label = ""
            if inf_data.get("is_smart"):
                for rule in inf_data["rules"]:
                    if p_age_months <= rule["max_age"]:
                        chosen_dose_per_kg = rule["mg_kg"]
                        chosen_label = rule["label"]
                        break
            else:
                chosen_dose_per_kg = inf_data['mg_kg']
                chosen_label = "Standard Dose"

            total_mg_needed = chosen_dose_per_kg * p_weight

            st.markdown(f"""<div class="custom-info">🛡️ <span style="color:#bfdbfe;">Safety Check: Detected Category:</span> **{chosen_label}**. <span style="color:#bfdbfe;">Using</span> {chosen_dose_per_kg} {inf_data.get('dose_unit', 'mg/kg')}</div>""", unsafe_allow_html=True)

            with col_input:
                infusion_duration_min = st.number_input("Infusion Duration (minutes)", 15, 180, 60, key=f"duration_{selected_infusion}")

                min_dilution_vol = 10
                if inf_data.get('suggested_dilution_volume_ml') == 0:
                    min_dilution_vol = 0 # Allow 0ml if suggested is 0 (e.g., undiluted)

                dilution_volume_ml = st.number_input(
                    f"Dilution Volume (ml) (Suggested: {inf_data['suggested_dilution_volume_ml']}ml)",
                    min_value=min_dilution_vol,
                    max_value=500,
                    value=inf_data['suggested_dilution_volume_ml'],
                    key=f"dilution_{selected_infusion}"
                )

            with col_output:
                total_ml_to_infuse = total_mg_needed / (inf_data['conc_mg_ml'] if inf_data['conc_mg_ml'] != 0 else 1)
                infusion_rate_ml_hr = (dilution_volume_ml / infusion_duration_min) * 60 if infusion_duration_min != 0 else 0

                st.metric("Total Dose", f"{round(total_mg_needed, 1)} mg")
                st.metric("Total Volume (Diluted)", f"{dilution_volume_ml} ml")
                st.metric("Pump Rate", f"{round(infusion_rate_ml_hr, 2)} ml/hr")
                st.caption(f"Infuse over {infusion_duration_min} min. {inf_data['dilution_info']}")

            log_details = f"Type: Intermittent Dose Infusion, Dose: {chosen_dose_per_kg} {inf_data['dose_unit']}, Total mg: {round(total_mg_needed, 1)}, Dilution Vol: {dilution_volume_ml} ml, Duration: {infusion_duration_min} min, Rate: {round(infusion_rate_ml_hr, 2)} ml/hr"

        elif inf_data['type'] == "Intermittent mEq/kg Infusion":
            chosen_dose_per_kg = 0
            chosen_label = ""
            if inf_data.get("is_smart"):
                for rule in inf_data["rules"]:
                    if p_age_months <= rule["max_age"]:
                        chosen_dose_per_kg = rule["mEq_kg"]
                        chosen_label = rule["label"]
                        break
            else:
                chosen_dose_per_kg = inf_data['mEq_kg']
                chosen_label = "Standard Dose"

            total_mEq_needed = chosen_dose_per_kg * p_weight

            st.markdown(f"""<div class="custom-info">🛡️ <span style="color:#bfdbfe;">Safety Check: Detected Category:</span> **{chosen_label}**. <span style="color:#bfdbfe;">Using</span> {chosen_dose_per_kg} mEq/kg</div>""", unsafe_allow_html=True)

            with col_input:
                infusion_duration_min = st.number_input("Infusion Duration (minutes)", 15, 180, 60, key=f"duration_{selected_infusion}")

                min_dilution_vol = 10
                if inf_data.get('suggested_dilution_volume_ml') == 0:
                    min_dilution_vol = 0

                dilution_volume_ml = st.number_input(
                    f"Dilution Volume (ml) (Suggested: {inf_data['suggested_dilution_volume_ml']}ml)",
                    min_value=min_dilution_vol,
                    max_value=500,
                    value=inf_data['suggested_dilution_volume_ml'],
                    key=f"dilution_{selected_infusion}"
                )

            with col_output:
                volume_drug_ml = total_mEq_needed / (inf_data['conc_mEq_ml'] if inf_data['conc_mEq_ml'] != 0 else 1)
                total_volume_to_infuse = volume_drug_ml + (dilution_volume_ml - volume_drug_ml if dilution_volume_ml > volume_drug_ml else 0)
                infusion_rate_ml_hr = (total_volume_to_infuse / infusion_duration_min) * 60 if infusion_duration_min != 0 else 0

                st.metric("Total Dose", f"{round(total_mEq_needed, 1)} mEq")
                st.metric("Total Volume (Diluted)", f"{round(total_volume_to_infuse, 2)} ml")
                st.metric("Pump Rate", f"{round(infusion_rate_ml_hr, 2)} ml/hr")
                st.caption(f"Infuse over {infusion_duration_min} min. {inf_data['dilution_info']}")

            log_details = f"Type: Intermittent mEq/kg Infusion, Dose: {chosen_dose_per_kg} {inf_data['dose_unit']}, Total mEq: {round(total_mEq_needed, 1)}, Dilution Vol: {dilution_volume_ml} ml, Duration: {infusion_duration_min} min, Rate: {round(infusion_rate_ml_hr, 2)} ml/hr"

        elif inf_data['type'] == "Continuous Dextrose Infusion":
            with col_input:
                desired_gir = st.slider("Desired GIR (mg/kg/min)", float(inf_data['min_dose']), float(inf_data['max_dose']), float(inf_data['initial_dose']), step=0.1, key=f"gir_slider_{selected_infusion}")
                selected_dextrose_conc = st.selectbox("Dextrose Concentration (%)", inf_data['conc_available_percent'], key=f"dex_conc_{selected_infusion}")
            with col_output:
                dextrose_conc_mg_per_ml = selected_dextrose_conc * 10
                infusion_rate_ml_hr = (desired_gir * p_weight * 60) / dextrose_conc_mg_per_ml

                st.metric("Pump Rate", f"{round(infusion_rate_ml_hr, 2)} ml/hr")
                st.caption(f"Calculated for {selected_dextrose_conc}% Dextrose. {inf_data['dilution_info']}")
            log_details = f"Type: Continuous Dextrose Infusion, GIR: {desired_gir} mg/kg/min, Conc: {selected_dextrose_conc}%, Rate: {round(infusion_rate_ml_hr, 2)} ml/hr"


        # Reworked general information display to be more robust
        st.divider()
        st.subheader("Infusion Details:")
        st.write(f"**Type:** {inf_data['type']}")

        if inf_data['type'] not in ["Weight Logic", "Intermittent Dose Infusion", "Intermittent mEq/kg Infusion", "Continuous Dextrose Infusion"]:
            # For Continuous, Insulin Unit Infusion, Kcl mEq/kg Correction, Bolus Transfusion
            if 'min_dose' in inf_data: st.write(f"**Min Dose:** {inf_data['min_dose']} {inf_data['dose_unit']}")
            if 'max_dose' in inf_data: st.write(f"**Max Dose:** {inf_data['max_dose']} {inf_data['dose_unit']}")
            if 'initial_dose' in inf_data: st.write(f"**Initial Dose:** {inf_data['initial_dose']} {inf_data.get('dose_unit', '')}")
            if 'conc_per_ml' in inf_data: st.write(f"**Concentration:** {inf_data['conc_per_ml']} {inf_data['conc_display_unit']}")
        elif inf_data['type'] in ["Intermittent Dose Infusion", "Intermittent mEq/kg Infusion"]:
            st.write("Dose determined by age-based rules (see above for specific rule applied).")
            if 'conc_mg_ml' in inf_data: st.write(f"**Concentration:** {inf_data['conc_mg_ml']} mg/ml")
            if 'conc_mEq_ml' in inf_data: st.write(f"**Concentration:** {inf_data['conc_mEq_ml']} mEq/ml")
            if 'suggested_dilution_volume_ml' in inf_data: st.write(f"**Suggested Dilution:** {inf_data['suggested_dilution_volume_ml']} ml")
        elif inf_data['type'] == "Continuous Dextrose Infusion":
            st.write("Glucose Infusion Rate (GIR) calculation.")
            if 'conc_available_percent' in inf_data: st.write(f"**Available Dextrose %:** {', '.join(map(str, inf_data['conc_available_percent']))}")
        elif inf_data['type'] == "Weight Logic":
             st.write("Dose determined by weight-based logic (see above).")
             if 'standard_conc' in inf_data: st.write(f"**Standard Concentration:** {inf_data['standard_conc']} mg/ml")


        if st.button(f"Save {selected_infusion} Infusion", key=f"log_infusion_{selected_infusion}"):
            current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            new_entry = {
                'Time': current_time,
                'Patient': p_name if p_name else 'N/A',
                'Age(Mo)': p_age_months,
                'Weight(kg)': p_weight,
                'Dept': p_dept,
                'Action': f"{selected_infusion} Infusion",
                'Result': log_details
            }
            # Insert into SQLite
            with sqlite3.connect(DB_FILE) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO patient_log (Timestamp, Patient, Age_Mo, Weight_kg, Dept, Action, Result)
                    VALUES (?, ?, ?, ?, ?, ?, ?)""",
                    (current_time, new_entry['Patient'], new_entry['Age(Mo)'], new_entry['Weight(kg)'], new_entry['Dept'], new_entry['Action'], new_log_entry['Result']))
                conn.commit()

            # Update session state log
            st.session_state.log = pd.concat([st.session_state.log, pd.DataFrame([new_entry])], ignore_index=True)
            st.balloons()
            st.toast("Infusion saved successfully!")
    else:
        st.error("No matching infusion drug found.")

st.divider()
st.subheader("Daily Patient Log")
st.dataframe(st.session_state.log, use_container_width=True)

# Clear Daily Log button moved below the log display
st.button("Clear Daily Log", on_click=clear_log)

st.markdown("""
---
**Important Notes:**
*   This application is for educational and quick reference purposes only.
*   Always verify doses and diagnosis with a specialist physician.
*   Dosages and recommendations may vary based on local protocols and individual patient conditions.
"""
)
''')
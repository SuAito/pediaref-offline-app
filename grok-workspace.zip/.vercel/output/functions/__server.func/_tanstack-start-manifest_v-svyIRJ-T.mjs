//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-svyIRJ-T.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-BYTu55jH.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BYTu55jH.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DJ0YiPvK.js"]
	}
} });
//#endregion
export { tsrStartManifest };

import { i as __toESM } from "../_runtime.mjs";
import { q as require_react, x as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { _ as WHO_GIRLS, a as ageToMonths, c as continuousRateMlHr, d as holidaySegar, f as pickInfusionRule, g as WHO_BOYS, h as INFUSIONS, i as usePatient, l as formatAge, m as DRUGS, n as Disclaimer, o as assessGrowth, p as stripMd, r as DEPTS, s as calculateDose, u as formatNum } from "./router-CV7t4sC3.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { a as CartesianGrid, c as Tooltip, i as Line, n as YAxis, o as ReferenceDot, r as XAxis, s as ResponsiveContainer, t as LineChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CgoYR9mK.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "mb-1.5 block text-xs font-medium uppercase tracking-label text-subtle",
			children: label
		}), children]
	});
}
var control = "h-11 w-full rounded-md bg-raised px-3 text-sm text-fg shadow-border placeholder:text-subtle focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent";
function TextInput(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		...props,
		className: cn(control, props.className)
	});
}
function NumberInput(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type: "number",
		inputMode: "decimal",
		...props,
		className: cn(control, "tabular-nums", props.className)
	});
}
function SelectInput(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		...props,
		className: cn(control, props.className)
	});
}
function Segmented({ value, onChange, options }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex flex-wrap gap-1.5",
		children: options.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => onChange(opt.id),
			className: cn("h-11 min-w-11 rounded-full px-3.5 text-sm transition-[background-color,color] duration-150", value === opt.id ? "bg-fg text-bg" : "bg-raised text-muted shadow-border hover:text-fg"),
			children: opt.label
		}, opt.id))
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium select-none disabled:pointer-events-none disabled:opacity-40 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent transition-[scale,background-color,color,box-shadow,opacity] duration-150 ease-out active:not-disabled:scale-[0.96]", {
	variants: {
		variant: {
			primary: "bg-accent text-accent-fg hover:bg-accent/90 shadow-border",
			secondary: "bg-raised text-fg shadow-border hover:shadow-border-hover",
			ghost: "bg-transparent text-muted hover:text-fg hover:bg-raised",
			danger: "bg-danger text-accent-fg hover:bg-danger/90",
			outline: "bg-transparent text-fg shadow-border hover:shadow-border-hover hover:bg-raised"
		},
		size: {
			sm: "h-9 px-3 text-sm rounded-sm",
			md: "h-11 px-4 text-sm rounded-md",
			lg: "h-12 px-5 text-base rounded-md",
			icon: "size-11 rounded-md"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
var Button = (0, import_react.forwardRef)(({ className, variant, size, type = "button", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
	ref,
	type,
	className: cn(buttonVariants({
		variant,
		size
	}), className),
	...props
}));
Button.displayName = "Button";
function printDocument(title, body) {
	const html = `<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>${escapeHtml(title)}</title>
  <style>
    body { font-family: "IBM Plex Sans", Georgia, sans-serif; color: #1c1b19; max-width: 720px; margin: 40px auto; padding: 0 24px; }
    h1 { font-family: Georgia, serif; font-size: 28px; font-weight: 500; margin: 0 0 8px; }
    .meta { color: #6b6560; font-size: 13px; margin-bottom: 24px; }
    .row { display: flex; justify-content: space-between; gap: 16px; padding: 10px 0; border-bottom: 1px solid #e6e1d6; }
    .k { color: #6b6560; font-size: 12px; text-transform: uppercase; letter-spacing: .12em; }
    .v { font-size: 16px; }
    .note { margin-top: 24px; font-size: 12px; color: #6b6560; }
  </style>
</head>
<body>
  ${body}
  <p class="note">Educational reference only. Confirm against local protocol before any administration.</p>
  <script>window.onload = () => { window.print(); };<\/script>
</body>
</html>`;
	const blob = new Blob([html], { type: "text/html" });
	const url = URL.createObjectURL(blob);
	if (!window.open(url, "_blank")) {
		const a = document.createElement("a");
		a.href = url;
		a.download = `${title.replace(/\s+/g, "-").toLowerCase()}.html`;
		a.click();
	}
	setTimeout(() => URL.revokeObjectURL(url), 6e4);
}
function escapeHtml(s) {
	return s.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("\"", "&quot;");
}
var CATEGORIES = [...new Set(DRUGS.map((d) => d.category))];
function DosePanel() {
	const [query, setQuery] = (0, import_react.useState)("");
	const [category, setCategory] = (0, import_react.useState)("All");
	const [drugId, setDrugId] = (0, import_react.useState)(DRUGS[0]?.id ?? "");
	const [saved, setSaved] = (0, import_react.useState)(false);
	const ageUnit = usePatient((s) => s.ageUnit);
	const ageValue = usePatient((s) => s.ageValue);
	const weightKg = usePatient((s) => s.weightKg);
	const name = usePatient((s) => s.name);
	const addLog = usePatient((s) => s.addLog);
	const ageMonths = ageToMonths(ageUnit, ageValue);
	const list = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		return DRUGS.filter((d) => {
			if (category !== "All" && d.category !== category) return false;
			if (q && !d.name.toLowerCase().includes(q)) return false;
			return true;
		});
	}, [query, category]);
	const drug = list.find((d) => d.id === drugId) ?? list[0];
	const result = drug ? calculateDose(drug, ageMonths, weightKg) : null;
	function logDose() {
		if (!drug || !result) return;
		addLog(`${drug.name} dose`, `${formatNum(result.totalMg, 1)} mg` + (result.volumeMl != null ? ` · ${formatNum(result.volumeMl, 2)} ml` : ""));
		setSaved(true);
		window.setTimeout(() => setSaved(false), 1600);
	}
	function printRx() {
		if (!drug || !result) return;
		printDocument(`Dose check — ${name}`, `<h1>Dose check</h1>
       <p class="meta">${escapeHtml(name)} · ${weightKg} kg · ${formatNum(ageMonths, 1)} months</p>
       <div class="row"><div class="k">Drug</div><div class="v">${escapeHtml(drug.name)}</div></div>
       <div class="row"><div class="k">Rule</div><div class="v">${escapeHtml(result.label)}</div></div>
       <div class="row"><div class="k">mg/kg</div><div class="v">${formatNum(result.mgPerKg, 2)}</div></div>
       <div class="row"><div class="k">Total</div><div class="v">${formatNum(result.totalMg, 1)} mg${result.capped ? " (capped)" : ""}</div></div>
       <div class="row"><div class="k">Volume</div><div class="v">${result.volumeMl == null ? "—" : `${formatNum(result.volumeMl, 2)} ml`}</div></div>
       ${drug.notes ? `<p class="note">${escapeHtml(stripMd(drug.notes))}</p>` : ""}`);
		logDose();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-mark text-accent",
				children: "Medications"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl tracking-tight",
				children: "Age-smart dosing"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 max-w-2xl text-sm text-muted",
				children: "Weight × mg/kg, then cap at the listed maximum. Volume uses the stock concentration from the original reference."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 md:grid-cols-[1fr_1.1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-surface p-4 shadow-border sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Search",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: query,
							onChange: (e) => setQuery(e.target.value),
							placeholder: "Amoxicillin, ceftriaxone…"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex gap-2 overflow-x-auto pb-1",
						children: ["All", ...CATEGORIES].map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setCategory(c),
							className: cn("h-11 shrink-0 rounded-full px-3.5 text-sm transition-[background-color,color] duration-150", category === c ? "bg-fg text-bg" : "bg-raised text-muted hover:text-fg"),
							children: c
						}, c))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "mt-3 block",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sr-only",
							children: "Drug"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: drug?.id ?? "",
							onChange: (e) => setDrugId(e.target.value),
							className: "mt-1 h-11 w-full rounded-md bg-raised px-3 text-sm shadow-border focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
							children: list.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: d.id,
								children: d.name
							}, d.id))
						})]
					}),
					list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "No matching drug."
					}) : null
				]
			}), drug && result ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-surface p-4 shadow-border sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-label text-subtle",
						children: "Dose summary"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "mt-1 font-display text-2xl tracking-tight",
						children: drug.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: cn("mt-3 rounded-md px-3 py-2 text-sm", result.notRecommended ? "bg-danger/10 text-fg" : "bg-raised text-muted"),
						children: result.notRecommended ? `Not recommended in this age band — ${result.label}` : `Safety check: ${result.label} · ${formatNum(result.mgPerKg, 2)} mg/kg`
					}),
					result.capped ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 rounded-md bg-danger/10 px-3 py-2 text-sm",
						children: [
							"Calculated ",
							formatNum(result.uncappedMg, 1),
							" mg exceeds max ",
							drug.maxMg,
							" mg. Capped."
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
						className: "mt-4 grid grid-cols-3 gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								k: "mg/kg",
								v: formatNum(result.mgPerKg, 2)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								k: "Total",
								v: `${formatNum(result.totalMg, 1)} mg`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								k: "Volume",
								v: result.volumeMl == null ? "—" : `${formatNum(result.volumeMl, 2)} ml`
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 font-mono text-xs text-subtle",
						children: [
							"Stock ",
							drug.conc,
							" / ",
							drug.vol,
							" ml · max ",
							drug.maxMg,
							" mg"
						]
					}),
					drug.notes ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm leading-relaxed text-muted",
						children: stripMd(drug.notes)
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 grid gap-2 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							onClick: logDose,
							disabled: result.notRecommended,
							children: saved ? "Saved" : "Save to log"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: printRx,
							disabled: result.notRecommended,
							children: "Print dose check"
						})]
					})
				]
			}) : null]
		})]
	});
}
function Stat({ k, v }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-md bg-raised px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "text-xs uppercase tracking-label text-subtle",
			children: k
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "font-mono text-sm tabular-nums",
			children: v
		})]
	});
}
function parseNum$1(raw, fallback) {
	const n = Number(raw);
	return Number.isFinite(n) ? n : fallback;
}
function FluidsPanel() {
	const [query, setQuery] = (0, import_react.useState)("");
	const [infId, setInfId] = (0, import_react.useState)(INFUSIONS[0]?.id ?? "");
	const [dose, setDose] = (0, import_react.useState)(null);
	const [hours, setHours] = (0, import_react.useState)(4);
	const [minutes, setMinutes] = (0, import_react.useState)(60);
	const [dilution, setDilution] = (0, import_react.useState)(null);
	const [dex, setDex] = (0, import_react.useState)(10);
	const [saved, setSaved] = (0, import_react.useState)(null);
	const ageUnit = usePatient((s) => s.ageUnit);
	const ageValue = usePatient((s) => s.ageValue);
	const weightKg = usePatient((s) => s.weightKg);
	const addLog = usePatient((s) => s.addLog);
	const ageMonths = ageToMonths(ageUnit, ageValue);
	const fluids = holidaySegar(weightKg);
	const list = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		return INFUSIONS.filter((i) => !q || i.name.toLowerCase().includes(q));
	}, [query]);
	const inf = list.find((i) => i.id === infId) ?? list[0];
	const rule = inf ? pickInfusionRule(inf, ageMonths) : null;
	const workingDose = dose ?? inf?.initialDose ?? rule?.perKg ?? 0;
	const workingDilution = dilution ?? inf?.suggestedDilutionMl ?? 50;
	let output = "";
	let detail = "";
	if (inf) {
		if (inf.kind === "Continuous" || inf.kind === "Insulin Unit Infusion") {
			const rate = continuousRateMlHr(inf, workingDose, weightKg);
			output = `${formatNum(rate, 2)} ml/hr`;
			detail = `${formatNum(workingDose, 3)} ${inf.doseUnit} · conc ${inf.concPerMl} ${inf.concDisplayUnit ?? ""}`;
		} else if (inf.kind === "Kcl mEq/kg Correction") {
			const totalMeq = workingDose * weightKg;
			const totalMl = totalMeq / (inf.concPerMl || 1);
			const rate = totalMl / hours;
			output = `${formatNum(rate, 2)} ml/hr`;
			detail = `Total ${formatNum(totalMeq, 1)} mEq · ${formatNum(totalMl, 2)} ml over ${hours} h`;
		} else if (inf.kind === "Bolus Transfusion") {
			const vol = workingDose * weightKg;
			output = `${formatNum(vol, 1)} ml`;
			detail = `${formatNum(workingDose, 1)} ml/kg`;
			if (inf.maxTotalMl && vol > inf.maxTotalMl) detail += ` — exceeds typical single-unit max ${inf.maxTotalMl} ml`;
		} else if (inf.kind === "Weight Logic") {
			const mgKg = weightKg < 20 ? 3 : 2.4;
			const mg = mgKg * weightKg;
			const ml = mg / (inf.standardConc || 10);
			output = `${formatNum(ml, 2)} ml`;
			detail = `${mgKg} mg/kg (WHO) · ${formatNum(mg, 1)} mg · ${inf.dilution ?? ""}`;
		} else if (inf.kind === "Continuous Dextrose Infusion") {
			const concMgMl = dex * 10;
			const rate = workingDose * weightKg * 60 / concMgMl;
			output = `${formatNum(rate, 2)} ml/hr`;
			detail = `GIR ${formatNum(workingDose, 1)} mg/kg/min in D${dex}`;
		} else if (inf.kind === "Intermittent Dose Infusion") {
			const totalMg = (rule?.perKg ?? 0) * weightKg;
			const rate = minutes > 0 ? workingDilution / minutes * 60 : 0;
			output = `${formatNum(rate, 2)} ml/hr`;
			detail = `${rule?.label ?? ""} · ${formatNum(totalMg, 1)} mg in ${workingDilution} ml over ${minutes} min`;
		} else if (inf.kind === "Intermittent mEq/kg Infusion") {
			const total = (rule?.perKg ?? 0) * weightKg;
			const drugMl = total / (inf.concMeqMl || 1);
			const bag = Math.max(workingDilution, drugMl);
			const rate = minutes > 0 ? bag / minutes * 60 : 0;
			output = `${formatNum(rate, 2)} ml/hr`;
			detail = `${rule?.label ?? ""} · ${formatNum(total, 1)} mEq · bag ${formatNum(bag, 1)} ml`;
		}
	}
	function flash(kind) {
		setSaved(kind);
		window.setTimeout(() => setSaved(null), 1600);
	}
	function save() {
		if (!inf) return;
		addLog(`${inf.name} infusion`, `${output} · ${detail}`);
		flash("inf");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-mark text-accent",
				children: "Critical care"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl tracking-tight",
				children: "Fluids and infusions"
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-surface p-5 shadow-border",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-xl tracking-tight",
						children: "Holliday–Segar maintenance"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "4/2/1 rule: first 10 kg × 4, next 10 × 2, remainder × 1 ml/kg/hr."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg bg-raised px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-label text-subtle",
								children: "Rate"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-2xl tabular-nums",
								children: [formatNum(fluids.mlPerHr, 1), " ml/hr"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg bg-raised px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-label text-subtle",
								children: "Daily"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-2xl tabular-nums",
								children: [formatNum(fluids.mlPerDay, 0), " ml"]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-4",
						variant: "secondary",
						onClick: () => {
							addLog("IVF maintenance", `${formatNum(fluids.mlPerHr, 1)} ml/hr (${formatNum(fluids.mlPerDay, 0)} ml/day)`);
							flash("ivf");
						},
						children: saved === "ivf" ? "Saved" : "Save to log"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl bg-surface p-5 shadow-border",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-xl tracking-tight",
						children: "Syringe pump"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Search infusions",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
								value: query,
								onChange: (e) => setQuery(e.target.value),
								placeholder: "Dopamine, artesunate…"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Infusion",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: inf?.id ?? "",
								onChange: (e) => {
									setInfId(e.target.value);
									setDose(null);
									setDilution(null);
								},
								className: "h-11 w-full rounded-md bg-raised px-3 text-sm shadow-border focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent",
								children: list.map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: i.id,
									children: i.name
								}, i.id))
							})
						})]
					}),
					inf ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs uppercase tracking-label text-subtle",
						children: inf.kind
					}) : null,
					inf && inf.minDose != null && inf.maxDose != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
							label: `Dose (${inf.doseUnit ?? ""})`,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "range",
								min: inf.minDose,
								max: inf.maxDose,
								step: (inf.maxDose - inf.minDose) / 20,
								value: workingDose,
								onChange: (e) => setDose(Number(e.target.value)),
								className: "w-full accent-accent"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-mono text-sm tabular-nums",
								children: formatNum(workingDose, 3)
							})]
						})
					}) : null,
					inf?.kind === "Kcl mEq/kg Correction" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Duration (hours)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberInput, {
								min: 1,
								max: 24,
								value: hours,
								onChange: (e) => setHours(parseNum$1(e.target.value, 4))
							})
						})
					}) : null,
					inf?.kind === "Continuous Dextrose Infusion" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Dextrose %",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
								value: dex,
								onChange: (e) => setDex(Number(e.target.value)),
								className: "h-11 w-full rounded-md bg-raised px-3 text-sm shadow-border",
								children: (inf.dextrosePercents ?? [
									5,
									10,
									12.5,
									25
								]).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
									value: p,
									children: ["D", p]
								}, p))
							})
						})
					}) : null,
					inf && (inf.kind === "Intermittent Dose Infusion" || inf.kind === "Intermittent mEq/kg Infusion") ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Duration (min)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberInput, {
								min: 15,
								max: 180,
								value: minutes,
								onChange: (e) => setMinutes(parseNum$1(e.target.value, 60))
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Dilution volume (ml)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberInput, {
								min: 0,
								max: 500,
								value: workingDilution,
								onChange: (e) => setDilution(parseNum$1(e.target.value, 50))
							})
						})]
					}) : null,
					list.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-muted",
						children: "No matching infusion."
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 rounded-lg bg-raised px-4 py-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs uppercase tracking-label text-subtle",
								children: "Pump output"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 font-display text-3xl tabular-nums tracking-tight",
								children: output || "—"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: stripMd(detail)
							}),
							inf?.dilution && inf.kind !== "Weight Logic" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs text-subtle",
								children: stripMd(inf.dilution)
							}) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						className: "mt-4",
						onClick: save,
						disabled: !inf,
						children: saved === "inf" ? "Saved" : "Save infusion to log"
					})
				]
			})
		]
	});
}
var SERIES = [
	{
		key: "p3",
		label: "P3",
		color: "#b54a42"
	},
	{
		key: "p15",
		label: "P15",
		color: "#9a7040"
	},
	{
		key: "p50",
		label: "P50",
		color: "#2c5f6e"
	},
	{
		key: "p85",
		label: "P85",
		color: "#9a7040"
	},
	{
		key: "p97",
		label: "P97",
		color: "#b54a42"
	}
];
function GrowthPanel() {
	const sex = usePatient((s) => s.sex);
	const name = usePatient((s) => s.name);
	const ageUnit = usePatient((s) => s.ageUnit);
	const ageValue = usePatient((s) => s.ageValue);
	const weightKg = usePatient((s) => s.weightKg);
	const addLog = usePatient((s) => s.addLog);
	const ageMonths = ageToMonths(ageUnit, ageValue);
	const table = sex === "Boy" ? WHO_BOYS : WHO_GIRLS;
	const assessment = assessGrowth(sex, ageMonths, weightKg);
	const inChart = ageMonths <= 60;
	function printReport() {
		printDocument(`Growth report — ${name}`, `<h1>Growth report</h1>
       <p class="meta">${escapeHtml(name)} · ${sex} · ${formatNum(ageMonths, 1)} months · ${weightKg} kg</p>
       <div class="row"><div class="k">Band</div><div class="v">${escapeHtml(assessment.band)}</div></div>
       <div class="row"><div class="k">Notes</div><div class="v">${escapeHtml(assessment.label)}</div></div>`);
		addLog("Growth report", assessment.label);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-mark text-accent",
					children: "WHO 0–5 years"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-3xl tracking-tight",
					children: "Weight-for-age"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "secondary",
					onClick: printReport,
					children: "Print report"
				})]
			}),
			!inChart ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-lg bg-raised px-4 py-3 text-sm text-muted",
				children: "WHO weight-for-age curves in this reference stop at 60 months. Dosing still uses the entered age."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-surface p-3 shadow-border sm:p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-2 flex flex-wrap gap-3 text-xs text-muted",
					children: [SERIES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "inline-block size-2 rounded-full",
							style: { background: s.color }
						}), s.label]
					}, s.key)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "inline-flex items-center gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "inline-block size-2 rounded-full bg-accent" }), "Patient"]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "h-72 sm:h-80",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
							data: table,
							margin: {
								top: 8,
								right: 12,
								left: 0,
								bottom: 8
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, { stroke: "rgba(28,27,25,0.08)" }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "age",
									tick: {
										fill: "#6b6560",
										fontSize: 11
									},
									label: {
										value: "Age (months)",
										position: "insideBottom",
										offset: -2,
										fill: "#6b6560",
										fontSize: 11
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									tick: {
										fill: "#6b6560",
										fontSize: 11
									},
									label: {
										value: "kg",
										angle: -90,
										position: "insideLeft",
										fill: "#6b6560",
										fontSize: 11
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
									background: "#fffcf7",
									border: "1px solid rgba(28,27,25,0.12)",
									borderRadius: 8,
									fontSize: 12
								} }),
								SERIES.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									type: "monotone",
									dataKey: s.key,
									stroke: s.color,
									dot: false,
									strokeWidth: s.key === "p50" ? 2.2 : 1.2,
									isAnimationActive: false
								}, s.key)),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReferenceDot, {
									x: Math.min(60, Math.max(0, ageMonths)),
									y: weightKg,
									r: 6,
									fill: "#2c5f6e",
									stroke: "#fffcf7",
									strokeWidth: 2
								})
							]
						})
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: cn("rounded-xl p-4 shadow-border", assessment.inRange ? "bg-surface" : "bg-danger/10"),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs uppercase tracking-label text-subtle",
						children: "Assessment"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm leading-relaxed",
						children: assessment.label
					}),
					assessment.curve ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 font-mono text-xs tabular-nums text-muted",
						children: [
							"P3 ",
							formatNum(assessment.curve.p3),
							" · P50 ",
							formatNum(assessment.curve.p50),
							" · P97",
							" ",
							formatNum(assessment.curve.p97),
							" kg"
						]
					}) : null
				]
			})
		]
	});
}
function LogPanel() {
	const log = usePatient((s) => s.log);
	const clearLog = usePatient((s) => s.clearLog);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-wrap items-end justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-mark text-accent",
				children: "Session"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-3xl tracking-tight",
				children: "Daily log"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Stored on this device only. Not a medical record."
			})
		] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "ghost",
			onClick: () => {
				if (log.length && window.confirm("Clear the log on this device?")) clearLog();
			},
			children: "Clear log"
		})]
	}), log.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-6 text-sm text-muted",
		children: "No entries yet. Save a dose or fluid calculation."
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-5 overflow-x-auto rounded-xl bg-surface shadow-border",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full text-left text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-b border-border text-xs uppercase tracking-wider text-subtle",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-4 py-3 font-medium",
						children: "Time"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-4 py-3 font-medium",
						children: "Patient"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-4 py-3 font-medium",
						children: "Age"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-4 py-3 font-medium",
						children: "Wt"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-4 py-3 font-medium",
						children: "Action"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "px-4 py-3 font-medium",
						children: "Result"
					})
				]
			}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: log.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-b border-border last:border-0",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-3 font-mono text-xs tabular-nums text-muted",
						children: new Date(row.time).toLocaleString()
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-3",
						children: row.patient
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
						className: "px-4 py-3 font-mono text-xs tabular-nums",
						children: [formatNum(row.ageMonths, 1), " mo"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
						className: "px-4 py-3 font-mono text-xs tabular-nums",
						children: [row.weightKg, " kg"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-3",
						children: row.action
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "px-4 py-3 text-muted",
						children: row.result
					})
				]
			}, row.id)) })]
		})
	})] });
}
function parseNum(raw, fallback) {
	const n = Number(raw);
	return Number.isFinite(n) ? n : fallback;
}
function PatientPanel() {
	const name = usePatient((s) => s.name);
	const sex = usePatient((s) => s.sex);
	const dept = usePatient((s) => s.dept);
	const ageUnit = usePatient((s) => s.ageUnit);
	const ageValue = usePatient((s) => s.ageValue);
	const weightKg = usePatient((s) => s.weightKg);
	const setName = usePatient((s) => s.setName);
	const setSex = usePatient((s) => s.setSex);
	const setDept = usePatient((s) => s.setDept);
	const setAgeUnit = usePatient((s) => s.setAgeUnit);
	const setAgeValue = usePatient((s) => s.setAgeValue);
	const setWeightKg = usePatient((s) => s.setWeightKg);
	const months = ageToMonths(ageUnit, ageValue);
	const ageMax = ageUnit === "days" ? 365 : ageUnit === "years" ? 18 : 216;
	const ageStep = ageUnit === "years" ? .1 : ageUnit === "months" ? .5 : 1;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
		className: "rounded-xl bg-surface p-5 shadow-border sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-mark text-accent",
				children: "Active case"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-1 font-display text-2xl tracking-tight",
				children: "Patient console"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "Age and weight drive every dose, fluid rate, and growth plot."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Name",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextInput, {
							value: name,
							onChange: (e) => setName(e.target.value),
							placeholder: "Patient name",
							autoComplete: "off"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Sex",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
							value: sex,
							onChange: setSex,
							options: [{
								id: "Boy",
								label: "Boy"
							}, {
								id: "Girl",
								label: "Girl"
							}]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Department",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectInput, {
							value: dept,
							onChange: (e) => setDept(e.target.value),
							children: DEPTS.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: d,
								children: d
							}, d))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Age unit",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Segmented, {
							value: ageUnit,
							onChange: setAgeUnit,
							options: [
								{
									id: "days",
									label: "Days"
								},
								{
									id: "months",
									label: "Months"
								},
								{
									id: "years",
									label: "Years"
								}
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: `Age (${ageUnit})`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberInput, {
							min: 0,
							max: ageMax,
							step: ageStep,
							value: ageValue,
							onChange: (e) => setAgeValue(parseNum(e.target.value, 0))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Weight (kg)",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumberInput, {
							min: .5,
							max: 80,
							step: .1,
							value: weightKg,
							onChange: (e) => setWeightKg(parseNum(e.target.value, .5))
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-6 grid grid-cols-2 gap-3 rounded-lg bg-raised p-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "text-xs uppercase tracking-label text-subtle",
					children: "Age"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
					className: "font-mono text-sm tabular-nums",
					children: formatAge(ageUnit, ageValue)
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
					className: "text-xs uppercase tracking-label text-subtle",
					children: "Months"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
					className: "font-mono text-sm tabular-nums",
					children: months.toFixed(1)
				})] })]
			})
		]
	});
}
function PatientCards() {
	const name = usePatient((s) => s.name);
	const sex = usePatient((s) => s.sex);
	const ageUnit = usePatient((s) => s.ageUnit);
	const ageValue = usePatient((s) => s.ageValue);
	const weightKg = usePatient((s) => s.weightKg);
	const dept = usePatient((s) => s.dept);
	const cards = [
		{
			k: "Name",
			v: name || "—"
		},
		{
			k: "Sex",
			v: sex
		},
		{
			k: "Age",
			v: formatAge(ageUnit, ageValue)
		},
		{
			k: "Weight",
			v: `${weightKg} kg`
		},
		{
			k: "Dept",
			v: dept
		}
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5",
		children: cards.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl bg-surface p-4 shadow-border",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs uppercase tracking-label text-subtle",
				children: c.k
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 font-display text-xl tracking-tight",
				children: c.v
			})]
		}, c.k))
	});
}
var TABS = [
	{
		id: "patient",
		label: "Patient"
	},
	{
		id: "growth",
		label: "Growth"
	},
	{
		id: "doses",
		label: "Doses"
	},
	{
		id: "fluids",
		label: "Fluids"
	},
	{
		id: "log",
		label: "Log"
	}
];
function Home() {
	const [tab, setTab] = (0, import_react.useState)("doses");
	const [showCase, setShowCase] = (0, import_react.useState)(false);
	const logCount = usePatient((s) => s.log.length);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "max-w-3xl",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs uppercase tracking-mark text-accent",
					children: "Pediatric reference"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-4xl leading-tight tracking-tight sm:text-5xl",
					children: "Weight in. Dose out."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-xl text-muted",
					children: "Age-smart mg/kg, WHO weight-for-age, Holliday–Segar fluids, and pump rates — a bedside calculator rebuilt for the ward, not a prescription."
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 grid gap-6 lg:grid-cols-[minmax(0,20rem)_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:sticky lg:top-20 lg:self-start",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "mb-3 flex h-11 w-full items-center justify-between rounded-md bg-surface px-4 text-sm shadow-border lg:hidden",
					onClick: () => setShowCase((v) => !v),
					"aria-expanded": showCase,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Patient console" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-muted",
						children: showCase ? "Hide" : "Edit"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: cn(showCase ? "block" : "hidden", "lg:block"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PatientPanel, {})
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-1.5 overflow-x-auto pb-2",
				children: TABS.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setTab(t.id),
					className: cn("h-11 shrink-0 rounded-full px-4 text-sm transition-[background-color,color] duration-150", tab === t.id ? "bg-fg text-bg" : "bg-surface text-muted shadow-border hover:text-fg"),
					children: [t.label, t.id === "log" && logCount > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "ml-1.5 font-mono text-xs tabular-nums",
						children: logCount
					}) : null]
				}, t.id))
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5",
				children: [
					tab === "patient" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl tracking-tight",
							children: "Case snapshot"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PatientCards, {})]
					}) : null,
					tab === "growth" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GrowthPanel, {}) : null,
					tab === "doses" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DosePanel, {}) : null,
					tab === "fluids" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FluidsPanel, {}) : null,
					tab === "log" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LogPanel, {}) : null
				]
			})] })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Disclaimer, {})
	] });
}
//#endregion
export { Home as component };

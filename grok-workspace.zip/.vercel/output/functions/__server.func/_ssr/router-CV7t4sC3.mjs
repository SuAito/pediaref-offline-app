import { i as __toESM } from "../_runtime.mjs";
import { _ as createFileRoute, b as useRouter, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, q as require_react, v as createRootRoute, x as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-CV7t4sC3.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-dvh flex-col items-center justify-center gap-3 bg-bg px-6 text-center text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-2xl tracking-tight",
			children: "Something went wrong"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "max-w-md text-sm break-words text-muted",
			children: errorMessage(error)
		})]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var DRUGS = [
	{
		"id": "amoxicillin-susp",
		"name": "Amoxicillin (Susp)",
		"category": "Antibiotics",
		"conc": 250,
		"vol": 5,
		"maxMg": 1e3,
		"rules": [
			{
				"maxAgeMonths": 6,
				"mgPerKg": 20,
				"label": "Infants < 6 Months"
			},
			{
				"maxAgeMonths": 24,
				"mgPerKg": 40,
				"label": "Infants 6-24 Months"
			},
			{
				"maxAgeMonths": 216,
				"mgPerKg": 25,
				"label": "Children > 2 Years"
			}
		]
	},
	{
		"id": "ampiclox-ampicillin-cloxacillin",
		"name": "Ampiclox (Ampicillin+Cloxacillin)",
		"category": "Antibiotics",
		"conc": 250,
		"vol": 5,
		"maxMg": 2e3,
		"mgPerKg": 50
	},
	{
		"id": "cefotaxime",
		"name": "Cefotaxime",
		"category": "Antibiotics",
		"conc": 1e3,
		"vol": 10,
		"maxMg": 2e3,
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": 50,
			"label": "Neonate Dose (<1 month)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 75,
			"label": "Standard Dose (Children)"
		}]
	},
	{
		"id": "amikacin",
		"name": "Amikacin",
		"category": "Antibiotics",
		"conc": 250,
		"vol": 2,
		"maxMg": 1500,
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": 15,
			"label": "Neonate Dose (<1 month)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 17.5,
			"label": "Children Dose"
		}]
	},
	{
		"id": "gentamicin-iv-im",
		"name": "Gentamicin (IV/IM)",
		"category": "Antibiotics",
		"conc": 40,
		"vol": 2,
		"maxMg": 400,
		"rules": [
			{
				"maxAgeMonths": 1,
				"mgPerKg": 4.5,
				"label": "Neonate Dose (<1 month)"
			},
			{
				"maxAgeMonths": 12,
				"mgPerKg": 6.25,
				"label": "Infant Dose (1-12 months)"
			},
			{
				"maxAgeMonths": 216,
				"mgPerKg": 6.25,
				"label": "Child Dose (>12 months)"
			}
		]
	},
	{
		"id": "penicillin-g-benzylpenicillin",
		"name": "Penicillin G (Benzylpenicillin)",
		"category": "Antibiotics",
		"conc": 1e6,
		"vol": 10,
		"maxMg": 4e6,
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": 37500,
			"label": "Neonate Dose (<1 month)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 75e3,
			"label": "Children Dose"
		}]
	},
	{
		"id": "metronidazole-flagyl",
		"name": "Metronidazole (Flagyl)",
		"category": "Antibiotics",
		"conc": 200,
		"vol": 5,
		"maxMg": 500,
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": 7.5,
			"label": "Neonate Dose (<1 month)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 7.5,
			"label": "Children Dose"
		}]
	},
	{
		"id": "acyclovir",
		"name": "Acyclovir",
		"category": "Antibiotics",
		"conc": 500,
		"vol": 10,
		"maxMg": 1e3,
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": 20,
			"label": "Neonate Dose (<1 month)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 15,
			"label": "Children Dose"
		}]
	},
	{
		"id": "clindamycin",
		"name": "Clindamycin",
		"category": "Antibiotics",
		"conc": 150,
		"vol": 5,
		"maxMg": 900,
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": 10,
			"label": "Neonate Dose (<1 month)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 35,
			"label": "Children Dose"
		}]
	},
	{
		"id": "erythromycin",
		"name": "Erythromycin",
		"category": "Antibiotics",
		"conc": 200,
		"vol": 5,
		"maxMg": 500,
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": 10,
			"label": "Neonate Dose (<1 month)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 12.5,
			"label": "Child Dose (>1 month)"
		}],
		"notes": "30-50 mg/kg/day ÷4; Neonates: 10 mg/kg q12h (motility); Children: 12.5 mg/kg q6h"
	},
	{
		"id": "clarithromycin",
		"name": "Clarithromycin",
		"category": "Antibiotics",
		"conc": 125,
		"vol": 5,
		"maxMg": 500,
		"rules": [{
			"maxAgeMonths": 6,
			"mgPerKg": 0,
			"label": "Infants < 6 Months (Not Recommended)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 7.5,
			"label": "Children > 6 Months (15 mg/kg/day ÷2)"
		}],
		"notes": "15 mg/kg/day ÷2; Neonates: not recommended; Children >6 mo: for atypical pneumonia"
	},
	{
		"id": "ciprofloxacin",
		"name": "Ciprofloxacin",
		"category": "Antibiotics",
		"conc": 200,
		"vol": 5,
		"maxMg": 750,
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": 0,
			"label": "Neonate Dose (Avoid, cartilage risk)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 15,
			"label": "Children Dose (>1 month, not first-line)"
		}],
		"notes": "30 mg/kg/day ÷2; Not first-line in children <18 yr except specific cases (e.g., Pseudomonas); Neonates: avoid due to cartilage risk"
	},
	{
		"id": "co-trimoxazole-septrin",
		"name": "Co-trimoxazole (Septrin)",
		"category": "Antibiotics",
		"conc": 240,
		"vol": 5,
		"maxMg": 960,
		"rules": [{
			"maxAgeMonths": 2,
			"mgPerKg": 0,
			"label": "Contraindicated < 2 Months"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 8,
			"label": "Standard Pediatric Dose"
		}]
	},
	{
		"id": "ceftriaxone",
		"name": "Ceftriaxone",
		"category": "Antibiotics",
		"conc": 250,
		"vol": 5,
		"maxMg": 4e3,
		"rules": [
			{
				"maxAgeMonths": 1,
				"mgPerKg": 50,
				"label": "Neonate Dose (<1 month)"
			},
			{
				"maxAgeMonths": 12,
				"mgPerKg": 80,
				"label": "Infant Dose (1-12 months)"
			},
			{
				"maxAgeMonths": 216,
				"mgPerKg": 85,
				"label": "Child Dose (>12 months)"
			}
		],
		"notes": "Typically 50-100 mg/kg/day. Max 4g/day. For severe infections, meningitis. Given IM/IV."
	},
	{
		"id": "adrenaline-nebulizer",
		"name": "Adrenaline (Nebulizer)",
		"category": "Emergency",
		"conc": 1,
		"vol": 1,
		"maxMg": 5,
		"rules": [{
			"maxAgeMonths": 216,
			"mgPerKg": .01,
			"label": "Standard Pediatric Dose (max 5mg)"
		}],
		"notes": "0.5mg/kg (max 5mg) of 1:1000 adrenaline (1mg/ml) diluted to 5ml NS. Refer to MSF Pediatric protocols."
	},
	{
		"id": "azithromycin-susp",
		"name": "Azithromycin (Susp)",
		"category": "Antibiotics",
		"conc": 200,
		"vol": 5,
		"maxMg": 500,
		"rules": [{
			"maxAgeMonths": 6,
			"mgPerKg": 0,
			"label": "Infants < 6 Months (Consult Specialist)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 10,
			"label": "Standard Pediatric Dose"
		}],
		"notes": "Often 10 mg/kg once daily for 3 days, or 10 mg/kg on day 1 then 5 mg/kg for 4 days. Max 500mg."
	},
	{
		"id": "levetiracetam",
		"name": "Levetiracetam",
		"category": "Antiepileptics",
		"conc": 100,
		"vol": 1,
		"maxMg": 1500,
		"rules": [{
			"maxAgeMonths": 216,
			"mgPerKg": 20,
			"label": "Standard Pediatric Maintenance Dose"
		}],
		"notes": "**Status Epilepticus (SE) - Third-line (20-60 min):** If first and second-line therapies fail. Loading dose: 20-60 mg/kg IV (often 40 mg/kg) over 15-30 min. Maintenance: 10-30 mg/kg/dose BID (max 3000 mg/day). Ensure adequate IV access and monitor for side effects."
	},
	{
		"id": "diazepam-iv-for-seizures",
		"name": "Diazepam (IV for seizures)",
		"category": "Antiepileptics",
		"conc": 10,
		"vol": 2,
		"maxMg": 10,
		"mgPerKg": .2,
		"notes": "**Status Epilepticus (SE) - First-line (0-5 min):** Administer 0.2-0.5 mg/kg IV slow (max 5mg <5yr, 10mg >=5yr). Repeat once after 5-10 min if SE persists. Max 2 doses. If SE continues after 10 min (total 15 min), proceed to Second-line therapy (Phenobarbital or Phenytoin). Neonates: 0.1-0.3 mg/kg/dose IV (lower due to prolonged half-life); Infants/Children: 0.2-0.5 mg/kg/dose; Max single dose <5 yr: 5 mg, ≥5 yr: 10 mg."
	},
	{
		"id": "phenobarbital-loading",
		"name": "Phenobarbital (Loading)",
		"category": "Antiepileptics",
		"conc": 120,
		"vol": 2,
		"maxMg": 1e3,
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": 15,
			"label": "Neonate Dose (<1 month)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 20,
			"label": "Infant/Child Dose"
		}],
		"notes": "**Status Epilepticus (SE) - Second-line (5-20 min):** If first-line benzodiazepines fail after 2 doses. Loading dose: 15-20 mg/kg IV over 10-20 min. May repeat 5-10 mg/kg once if SE persists (up to max total 40 mg/kg). If SE continues after 20 min (total 35 min), consider Third-line therapy (Levetiracetam, continuous Midazolam/Propofol)."
	},
	{
		"id": "phenobarbital-maintenance",
		"name": "Phenobarbital (Maintenance)",
		"category": "Antiepileptics",
		"conc": 120,
		"vol": 2,
		"maxMg": 300,
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": 3,
			"label": "Neonate Dose (<1 month)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 5,
			"label": "Infant/Child Dose"
		}]
	},
	{
		"id": "phenytoin-loading",
		"name": "Phenytoin (Loading)",
		"category": "Antiepileptics",
		"conc": 50,
		"vol": 5,
		"maxMg": 1e3,
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": 15,
			"label": "Neonate Dose (<1 month)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 20,
			"label": "Infant/Child Dose"
		}],
		"notes": "**Status Epilepticus (SE) - Second-line (5-20 min):** If first-line benzodiazepines fail after 2 doses. Loading dose: 15-20 mg/kg IV over 10-20 min (max infusion rate 1 mg/kg/min). Monitor ECG/BP closely due to cardiac side effects. Max total loading dose 30 mg/kg. If SE continues after 20 min (total 35 min), consider Third-line therapy (Levetiracetam, continuous Midazolam/Propofol)."
	},
	{
		"id": "phenytoin-maintenance",
		"name": "Phenytoin (Maintenance)",
		"category": "Antiepileptics",
		"conc": 50,
		"vol": 5,
		"maxMg": 300,
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": 4,
			"label": "Neonate Dose (<1 month)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 8,
			"label": "Infant/Child Dose"
		}]
	},
	{
		"id": "midazolam-iv-bolus",
		"name": "Midazolam (IV bolus)",
		"category": "Antiepileptics",
		"conc": 1,
		"vol": 5,
		"maxMg": 10,
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": .05,
			"label": "Neonate Dose (<1 month)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": .1,
			"label": "Infant/Child Dose"
		}],
		"notes": "**Status Epilepticus (SE) - First-line (0-5 min):** Administer 0.1-0.2 mg/kg IV/IM/buccal (max 5mg <5yr, 10mg >=5yr). Repeat once after 5-10 min if SE persists. Max 2 doses. If SE continues after 10 min (total 15 min), proceed to Second-line therapy (Phenobarbital or Phenytoin). For Refractory SE (Third-line, 20-60 min), a continuous Midazolam infusion (0.05-0.4 mg/kg/hr) may be needed. Neonates: 0.05 mg/kg; Infants/Children: 0.1-0.2 mg/kg."
	},
	{
		"id": "dexamethasone",
		"name": "Dexamethasone",
		"category": "Corticosteroids",
		"conc": 8,
		"vol": 2,
		"maxMg": 16,
		"mgPerKg": .5,
		"notes": "Generally same across ages; Neonates may need adjustment for cerebral edema"
	},
	{
		"id": "prednisolone-syrup",
		"name": "Prednisolone (Syrup)",
		"category": "Corticosteroids",
		"conc": 5,
		"vol": 5,
		"maxMg": 60,
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": .5,
			"label": "Neonate Dose"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 1,
			"label": "Child Dose"
		}],
		"notes": "Loading: 1-2 mg/kg/day (methylpred equiv); Maintenance: 0.5-1 mg/kg/day; Neonates: lower doses; Children: adjust for inflammation/asthma"
	},
	{
		"id": "quinine",
		"name": "Quinine",
		"category": "Antimalarials",
		"conc": 300,
		"vol": 2,
		"maxMg": 600,
		"mgPerKg": 10,
		"notes": "Loading 20 mg/kg then 10 mg/kg q8h; Neonates/Infants: monitor hypoglycemia closely"
	},
	{
		"id": "dextrose-10-loading-for-hypoglycemia",
		"name": "Dextrose 10% (Loading for Hypoglycemia)",
		"category": "Emergency",
		"conc": 100,
		"vol": 5,
		"maxMg": 250,
		"mgPerKg": 500,
		"notes": "Neonates: 2-5 mL/kg bolus; Children: similar; Follow with maintenance"
	},
	{
		"id": "calcium-gluconate-10",
		"name": "Calcium Gluconate 10%",
		"category": "Emergency",
		"conc": 100,
		"vol": 1,
		"maxMg": 2e3,
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": 100,
			"label": "Neonate Dose (<1 month)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 50,
			"label": "Child Dose (>1 month)"
		}],
		"notes": "Neonates: 100-200 mg/kg/dose slow IV; Children: 50-100 mg/kg/dose; Monitor ECG"
	},
	{
		"id": "sodium-bicarbonate-nahco3",
		"name": "Sodium Bicarbonate (NaHCO3)",
		"category": "Emergency",
		"conc": 84,
		"vol": 1,
		"maxMg": 1e3,
		"mgPerKg": 84,
		"notes": "Neonates: cautious use, 1-2 mEq/kg slow; Children: same; Only if severe acidosis"
	},
	{
		"id": "furosemide-lasix",
		"name": "Furosemide (Lasix)",
		"category": "Emergency",
		"conc": 10,
		"vol": 2,
		"maxMg": 40,
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": 1,
			"label": "Neonate Dose (<1 month)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 1,
			"label": "Child Dose (>1 month)"
		}],
		"notes": "Neonates: 1 mg/kg/dose (may need higher); Children: 1-2 mg/kg/dose q6-12h"
	},
	{
		"id": "vitamin-k-phytonadione",
		"name": "Vitamin K (Phytonadione)",
		"category": "Blood & nutrition",
		"conc": 10,
		"vol": 1,
		"maxMg": 10,
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": .5,
			"label": "Neonate Prophylaxis"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 5,
			"label": "Therapeutic Dose"
		}],
		"notes": "Neonates: 0.5-1 mg IM/IV once for prophylaxis. Therapeutic: 5-10 mg IM/IV"
	},
	{
		"id": "iron-oral-ferrous-sulfate",
		"name": "Iron (Oral) (Ferrous Sulfate)",
		"category": "Blood & nutrition",
		"conc": 30,
		"vol": 1,
		"maxMg": 100,
		"rules": [{
			"maxAgeMonths": 6,
			"mgPerKg": 1,
			"label": "Prophylaxis < 6mo (elemental iron)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 3,
			"label": "Treatment (elemental iron)"
		}],
		"notes": "Prophylaxis: 1-2 mg/kg/day elemental iron; Treatment: 3-6 mg/kg/day elemental iron. Adjust for formulation."
	},
	{
		"id": "folic-acid",
		"name": "Folic Acid",
		"category": "Blood & nutrition",
		"conc": 1,
		"vol": 1,
		"maxMg": 5,
		"rules": [{
			"maxAgeMonths": 12,
			"mgPerKg": .05,
			"label": "Infant Prophylaxis"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": .5,
			"label": "Child Therapeutic"
		}],
		"notes": "Prophylaxis: 0.05-0.1 mg/day; Therapeutic: 0.5-1 mg/day"
	},
	{
		"id": "paracetamol-syrup",
		"name": "Paracetamol (Syrup)",
		"category": "Analgesics",
		"conc": 120,
		"vol": 5,
		"maxMg": 1e3,
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": 10,
			"label": "Neonate Dose"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 15,
			"label": "Standard Pediatric Dose"
		}]
	},
	{
		"id": "paracetamol-infusion",
		"name": "Paracetamol (Infusion)",
		"category": "Analgesics",
		"conc": 1e3,
		"vol": 100,
		"maxMg": 1e3,
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": 7.5,
			"label": "Neonate Dose"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 10,
			"label": "Standard Pediatric Dose"
		}]
	},
	{
		"id": "ibuprofen-advil-fenistil",
		"name": "Ibuprofen (Advil/Fenistil)",
		"category": "Analgesics",
		"conc": 100,
		"vol": 5,
		"maxMg": 400,
		"rules": [{
			"maxAgeMonths": 6,
			"mgPerKg": 0,
			"label": "Not Recommended < 6 Months"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 10,
			"label": "Standard Pediatric Dose"
		}]
	},
	{
		"id": "diclofenac-voltaren-supp",
		"name": "Diclofenac (Voltaren Supp)",
		"category": "Analgesics",
		"conc": 12.5,
		"vol": 1,
		"maxMg": 50,
		"rules": [{
			"maxAgeMonths": 12,
			"mgPerKg": 0,
			"label": "Avoid in Infants < 1 Year"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 1,
			"label": "Standard Dose (1-3 mg/kg/day)"
		}]
	},
	{
		"id": "combivent-nebulizer",
		"name": "Combivent (Nebulizer)",
		"category": "Respiratory",
		"conc": 2.5,
		"vol": 2.5,
		"maxMg": 5,
		"rules": [{
			"maxAgeMonths": 12,
			"mgPerKg": .1,
			"label": "Infant Nebulization"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": .15,
			"label": "Children Nebulization"
		}]
	},
	{
		"id": "chlorpheniramine-allerfin",
		"name": "Chlorpheniramine (Allerfin)",
		"category": "Respiratory",
		"conc": 2,
		"vol": 5,
		"maxMg": 4,
		"rules": [{
			"maxAgeMonths": 24,
			"mgPerKg": 0,
			"label": "Avoid < 2 Years (Sedation Risk)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": .1,
			"label": "Standard Pediatric Dose"
		}]
	},
	{
		"id": "domperidone-motilium",
		"name": "Domperidone (Motilium)",
		"category": "Gastrointestinal",
		"conc": 5,
		"vol": 5,
		"maxMg": 10,
		"rules": [{
			"maxAgeMonths": 216,
			"mgPerKg": .25,
			"label": "Standard Dose (TDS)"
		}]
	},
	{
		"id": "ondansetron-zofran",
		"name": "Ondansetron (Zofran)",
		"category": "Gastrointestinal",
		"conc": 2,
		"vol": 1,
		"maxMg": 8,
		"rules": [{
			"maxAgeMonths": 6,
			"mgPerKg": 0,
			"label": "Not Recommended < 6 Months"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": .15,
			"label": "Standard Dose"
		}]
	},
	{
		"id": "hyoscine-buscopan-syrup",
		"name": "Hyoscine (Buscopan Syrup)",
		"category": "Gastrointestinal",
		"conc": 5,
		"vol": 5,
		"maxMg": 10,
		"rules": [{
			"maxAgeMonths": 72,
			"mgPerKg": .5,
			"label": "Children 1-6 Years"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": .7,
			"label": "Children > 6 Years"
		}]
	},
	{
		"id": "cefixime-susp",
		"name": "Cefixime (Susp)",
		"category": "Antibiotics",
		"conc": 200,
		"vol": 5,
		"maxMg": 400,
		"rules": [{
			"maxAgeMonths": 6,
			"mgPerKg": 0,
			"label": "Infants < 6 Months (Not Recommended)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 8,
			"label": "Children >= 6 Months (8 mg/kg/day)"
		}],
		"notes": "Typically given orally as a suspension. Dosage is 8mg/kg/day, usually given once or divided BID."
	},
	{
		"id": "albumin-25",
		"name": "Albumin 25%",
		"category": "Blood & nutrition",
		"conc": 250,
		"vol": 1,
		"maxMg": 1e5,
		"mgPerKg": 250,
		"notes": "Dose: 0.5-1 g/kg (2-4 ml/kg of 25% albumin). Infuse over 30-60 mins, faster in emergencies. Mg/kg is used as a placeholder here, actual calculation should be mL/kg."
	},
	{
		"id": "digoxin-oral-solution",
		"name": "Digoxin (Oral Solution)",
		"category": "Cardiovascular",
		"conc": .05,
		"vol": 1,
		"maxMg": .25,
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": .005,
			"label": "Neonate Maintenance Dose (5 mcg/kg/day)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": .008,
			"label": "Infant/Child Maintenance Dose (8 mcg/kg/day)"
		}],
		"notes": "Requires careful monitoring (ECG, electrolytes, levels). Dosage depends on loading dose and renal function. Doses are per day."
	},
	{
		"id": "rabeprazole",
		"name": "Rabeprazole",
		"category": "Gastrointestinal",
		"conc": 10,
		"vol": 1,
		"maxMg": 20,
		"rules": [{
			"maxAgeMonths": 144,
			"mgPerKg": .6,
			"label": "Children 1-11 Years (10mg total daily)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": .5,
			"label": "Children 12+ Years (20mg total daily)"
		}],
		"notes": "Administer 30 mins before food. For GERD/peptic ulcers. The mg/kg values are an approximation for the total daily dose (10mg/day for 1-11y, 20mg/day for 12+y)."
	},
	{
		"id": "amlodipine-oral-solution",
		"name": "Amlodipine (Oral Solution)",
		"category": "Cardiovascular",
		"conc": 1,
		"vol": 1,
		"maxMg": 10,
		"rules": [{
			"maxAgeMonths": 72,
			"mgPerKg": .05,
			"label": "Children 1-5 Years (Initial Dose)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": .1,
			"label": "Children > 6 Years (Initial Dose)"
		}],
		"notes": "Start low and titrate. Used for hypertension. Can be prepared from tablets."
	},
	{
		"id": "zinc-syrup-elemental",
		"name": "Zinc Syrup (Elemental)",
		"category": "Blood & nutrition",
		"conc": 2,
		"vol": 1,
		"maxMg": 10,
		"rules": [
			{
				"maxAgeMonths": 6,
				"mgPerKg": .5,
				"label": "Infants 0-6 Months (2.5mg total daily)"
			},
			{
				"maxAgeMonths": 12,
				"mgPerKg": .6,
				"label": "Infants 6-12 Months (5mg total daily)"
			},
			{
				"maxAgeMonths": 60,
				"mgPerKg": .65,
				"label": "Children 1-5 Years (10mg total daily)"
			}
		],
		"notes": "For diarrhea management (WHO protocol) or zinc deficiency. Administer away from dairy/iron. Doses are total elemental zinc per day."
	},
	{
		"id": "vitamin-d3-oral-drops",
		"name": "Vitamin D3 (Oral Drops)",
		"category": "Blood & nutrition",
		"conc": .01,
		"vol": 1,
		"maxMg": .05,
		"rules": [{
			"maxAgeMonths": 12,
			"mgPerKg": .001,
			"label": "Infants 0-12 Months (400 IU/day)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": .001,
			"label": "Children >1 Year (600 IU/day)"
		}],
		"notes": "Prophylaxis dose. 1 mcg = 40 IU. The mg/kg values are an approximation for the fixed total daily IU dose. Actual dosing is in IU."
	},
	{
		"id": "calcium-supplemental-syrup-elemental",
		"name": "Calcium Supplemental Syrup (Elemental)",
		"category": "Blood & nutrition",
		"conc": 20,
		"vol": 1,
		"maxMg": 1e3,
		"mgPerKg": 25,
		"notes": "For calcium deficiency. Elemental calcium varies by salt. Give in divided doses."
	}
];
[...new Set(DRUGS.map((d) => d.category))];
var INFUSIONS = [
	{
		"id": "dopamine",
		"name": "Dopamine",
		"kind": "Continuous",
		"doseUnit": "mcg/kg/min",
		"minDose": 2,
		"maxDose": 20,
		"initialDose": 5,
		"concPerMl": 4e3,
		"concDisplayUnit": "mcg/ml",
		"dilution": "Standard: 200mg in 50ml NS"
	},
	{
		"id": "adrenaline-epinephrine",
		"name": "Adrenaline (Epinephrine)",
		"kind": "Continuous",
		"doseUnit": "mcg/kg/min",
		"minDose": .05,
		"maxDose": 1,
		"initialDose": .1,
		"concPerMl": 20,
		"concDisplayUnit": "mcg/ml",
		"dilution": "Standard: 1mg in 50ml NS"
	},
	{
		"id": "fentanyl",
		"name": "Fentanyl",
		"kind": "Continuous",
		"doseUnit": "mcg/kg/hr",
		"minDose": 1,
		"maxDose": 5,
		"initialDose": 2,
		"concPerMl": 10,
		"concDisplayUnit": "mcg/ml",
		"dilution": "Standard: 500mcg in 50ml NS"
	},
	{
		"id": "midazolam",
		"name": "Midazolam",
		"kind": "Continuous",
		"doseUnit": "mg/kg/hr",
		"minDose": .05,
		"maxDose": .4,
		"initialDose": .1,
		"concPerMl": 1,
		"concDisplayUnit": "mg/ml",
		"dilution": "Standard: 50mg in 50ml NS"
	},
	{
		"id": "insulin",
		"name": "Insulin",
		"kind": "Insulin Unit Infusion",
		"doseUnit": "units/kg/hr",
		"minDose": .01,
		"maxDose": .1,
		"initialDose": .05,
		"concPerMl": 1,
		"concDisplayUnit": "units/ml",
		"dilution": "Standard: 50 units Regular Insulin in 50ml NS"
	},
	{
		"id": "kcl-correction",
		"name": "KCL Correction",
		"kind": "Kcl mEq/kg Correction",
		"doseUnit": "mEq/kg",
		"minDose": .1,
		"maxDose": .5,
		"initialDose": .2,
		"concPerMl": 2,
		"concDisplayUnit": "mEq/ml",
		"dilution": "Standard KCL solution (e.g., 10mEq/5ml)"
	},
	{
		"id": "magnesium-sulfate",
		"name": "Magnesium Sulfate",
		"kind": "Continuous",
		"doseUnit": "mg/kg/hr",
		"minDose": 10,
		"maxDose": 50,
		"initialDose": 20,
		"concPerMl": 100,
		"concDisplayUnit": "mg/ml",
		"dilution": "Standard: 5g MgSO4 in 50ml NS"
	},
	{
		"id": "cefotaxime",
		"name": "Cefotaxime",
		"kind": "Intermittent Dose Infusion",
		"doseUnit": "mg/kg",
		"concMgMl": 100,
		"suggestedDilutionMl": 50,
		"dilution": "Dilute in NS/D5W. Infuse over 30-60 min.",
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": 50,
			"label": "Neonate Dose (<1 month)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 75,
			"label": "Standard Dose (Children)"
		}]
	},
	{
		"id": "paracetamol-iv",
		"name": "Paracetamol (IV)",
		"kind": "Intermittent Dose Infusion",
		"doseUnit": "mg/kg",
		"concMgMl": 10,
		"suggestedDilutionMl": 50,
		"dilution": "Infuse over 15 minutes. Consider dilution to 1-2 mg/ml for smaller volumes. Max 1000mg/dose.",
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": 10,
			"label": "Neonate Dose (10 mg/kg)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 10,
			"label": "Infant/Child Dose (10-15 mg/kg)"
		}]
	},
	{
		"id": "meropenem",
		"name": "Meropenem",
		"kind": "Intermittent Dose Infusion",
		"doseUnit": "mg/kg",
		"concMgMl": 50,
		"suggestedDilutionMl": 50,
		"dilution": "Dilute in NS. Infuse over 15-30 min.",
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": 20,
			"label": "Neonate Dose (<1 month)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 20,
			"label": "Children Dose"
		}]
	},
	{
		"id": "vancomycin",
		"name": "Vancomycin",
		"kind": "Intermittent Dose Infusion",
		"doseUnit": "mg/kg",
		"concMgMl": 50,
		"suggestedDilutionMl": 100,
		"dilution": "Dilute in NS/D5W (max 5mg/ml). Infuse over 60 min (longer for higher doses) to avoid Red Man Syndrome.",
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": 12.5,
			"label": "Neonate Dose (<1 month)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 15,
			"label": "Children Dose"
		}]
	},
	{
		"id": "dextrose-continuous",
		"name": "Dextrose % (Continuous)",
		"kind": "Continuous Dextrose Infusion",
		"doseUnit": "mg/kg/min (GIR)",
		"minDose": 4,
		"maxDose": 10,
		"initialDose": 6,
		"dextrosePercents": [
			5,
			10,
			12.5,
			25
		],
		"dilution": "Glucose Infusion Rate (GIR) calculation. Select available dextrose concentration."
	},
	{
		"id": "calcium-gluconate-10",
		"name": "Calcium Gluconate 10%",
		"kind": "Intermittent Dose Infusion",
		"doseUnit": "mg/kg",
		"concMgMl": 100,
		"suggestedDilutionMl": 50,
		"dilution": "Slow IV Infusion over 30-60 min. Max infusion rate 50mg/kg/hr.",
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": 100,
			"label": "Neonate Dose (<1 month)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 50,
			"label": "Child Dose (>1 month)"
		}]
	},
	{
		"id": "sodium-bicarbonate-nahco3",
		"name": "Sodium Bicarbonate (NaHCO3)",
		"kind": "Intermittent mEq/kg Infusion",
		"doseUnit": "mEq/kg",
		"concMeqMl": 1,
		"suggestedDilutionMl": 50,
		"dilution": "Infuse slowly over 30-60 min. Use with caution in neonates; dilute 1:1 with D5W. Max 1 mEq/kg/min.",
		"meqRules": [{
			"maxAgeMonths": 216,
			"meqPerKg": 1,
			"label": "Standard Dose (1 mEq/kg)"
		}]
	},
	{
		"id": "furosemide-lasix",
		"name": "Furosemide (Lasix)",
		"kind": "Continuous",
		"doseUnit": "mg/kg/hr",
		"minDose": .05,
		"maxDose": .4,
		"initialDose": .1,
		"concPerMl": 1,
		"concDisplayUnit": "mg/ml",
		"dilution": "Standard: 20mg in 20ml NS. Titrate to effect."
	},
	{
		"id": "hydrocortisone",
		"name": "Hydrocortisone",
		"kind": "Continuous",
		"doseUnit": "mg/kg/hr",
		"minDose": .1,
		"maxDose": .4,
		"initialDose": .2,
		"concPerMl": 1,
		"concDisplayUnit": "mg/ml",
		"dilution": "Standard: 100mg in 100ml NS/D5W. For stress doses in adrenal insufficiency or shock."
	},
	{
		"id": "ceftriaxone",
		"name": "Ceftriaxone",
		"kind": "Intermittent Dose Infusion",
		"doseUnit": "mg/kg",
		"concMgMl": 100,
		"suggestedDilutionMl": 50,
		"dilution": "Reconstitute to 100mg/ml, then dilute further in NS/D5W. Infuse over 30-60 min. Max 4g/day.",
		"rules": [
			{
				"maxAgeMonths": 1,
				"mgPerKg": 50,
				"label": "Neonate Dose (<1 month)"
			},
			{
				"maxAgeMonths": 12,
				"mgPerKg": 80,
				"label": "Infant Dose (1-12 months)"
			},
			{
				"maxAgeMonths": 216,
				"mgPerKg": 85,
				"label": "Child Dose (>12 months)"
			}
		]
	},
	{
		"id": "levetiracetam",
		"name": "Levetiracetam",
		"kind": "Intermittent Dose Infusion",
		"doseUnit": "mg/kg",
		"concMgMl": 100,
		"suggestedDilutionMl": 50,
		"dilution": "**Status Epilepticus (SE) - Third-line (20-60 min):** If first and second-line therapies fail. Dilute to 10-20 mg/ml in NS or D5W. Infuse over 15-30 min. For maintenance, 10-30 mg/kg/dose BID IV/PO. Monitor for adverse effects.",
		"rules": [{
			"maxAgeMonths": 216,
			"mgPerKg": 40,
			"label": "Status Epilepticus Loading Dose"
		}]
	},
	{
		"id": "diazepam-se-iv-bolus",
		"name": "Diazepam (SE IV Bolus)",
		"kind": "Intermittent Dose Infusion",
		"doseUnit": "mg/kg",
		"concMgMl": 2.5,
		"suggestedDilutionMl": 0,
		"dilution": "**Status Epilepticus (SE) - First-line (0-5 min):** Administer slow IV (undiluted or diluted in NS/D5W). Max 5mg (<5yr) or 10mg (>=5yr) per dose. Repeat once after 5-10 min if SE persists. Max 2 doses. If SE continues after 10 min (total 15 min), proceed to Second-line.",
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": .15,
			"label": "Neonate Dose (<1 month)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": .35,
			"label": "Infant/Child Dose"
		}]
	},
	{
		"id": "midazolam-se-iv-bolus",
		"name": "Midazolam (SE IV Bolus)",
		"kind": "Intermittent Dose Infusion",
		"doseUnit": "mg/kg",
		"concMgMl": 1,
		"suggestedDilutionMl": 0,
		"dilution": "**Status Epilepticus (SE) - First-line (0-5 min):** Administer IV/IM/buccal (can be diluted in NS/D5W). Max 5mg (<5yr) or 10mg (>=5yr) per dose. Repeat once after 5-10 min if SE persists. Max 2 doses. If SE continues after 10 min (total 15 min), proceed to Second-line.",
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": .05,
			"label": "Neonate Dose (<1 month)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": .15,
			"label": "Infant/Child Dose"
		}]
	},
	{
		"id": "phenobarbital-se-iv-loading",
		"name": "Phenobarbital (SE IV Loading)",
		"kind": "Intermittent Dose Infusion",
		"doseUnit": "mg/kg",
		"concMgMl": 60,
		"suggestedDilutionMl": 50,
		"dilution": "**Status Epilepticus (SE) - Second-line (5-20 min):** If first-line benzodiazepines fail. Loading dose: 15-20 mg/kg IV over 10-20 min. May repeat 5-10 mg/kg once if SE persists (up to max total 40 mg/kg). Dilute in NS. If SE continues after 20 min (total 35 min), consider Third-line.",
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": 15,
			"label": "Neonate Dose (<1 month)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 20,
			"label": "Infant/Child Dose"
		}]
	},
	{
		"id": "phenytoin-se-iv-loading",
		"name": "Phenytoin (SE IV Loading)",
		"kind": "Intermittent Dose Infusion",
		"doseUnit": "mg/kg",
		"concMgMl": 50,
		"suggestedDilutionMl": 50,
		"dilution": "**Status Epilepticus (SE) - Second-line (5-20 min):** If first-line benzodiazepines fail. Loading dose: 15-20 mg/kg IV over 10-20 min (max infusion rate 1 mg/kg/min). Dilute in NS only, do NOT use D5W. Monitor ECG/BP. If SE continues after 20 min (total 35 min), consider Third-line.",
		"rules": [{
			"maxAgeMonths": 1,
			"mgPerKg": 15,
			"label": "Neonate Dose (<1 month)"
		}, {
			"maxAgeMonths": 216,
			"mgPerKg": 20,
			"label": "Infant/Child Dose"
		}]
	},
	{
		"id": "packed-rbcs-prbcs-transfusion",
		"name": "Packed RBCs (PRBCs transfusion)",
		"kind": "Bolus Transfusion",
		"doseUnit": "mL/kg",
		"minDose": 10,
		"maxDose": 15,
		"initialDose": 10,
		"maxTotalMl": 300,
		"dilution": "To raise Hb ~2-3 g/dL; Slow infusion"
	},
	{
		"id": "platelets-transfusion",
		"name": "Platelets transfusion",
		"kind": "Bolus Transfusion",
		"doseUnit": "mL/kg",
		"minDose": 10,
		"maxDose": 15,
		"initialDose": 10,
		"maxTotalMl": 300,
		"dilution": "10-15 mL/kg; Neonates: smaller volumes; Raise platelets ~30-50k"
	},
	{
		"id": "fresh-frozen-plasma-ffp",
		"name": "Fresh Frozen Plasma (FFP)",
		"kind": "Bolus Transfusion",
		"doseUnit": "mL/kg",
		"minDose": 10,
		"maxDose": 15,
		"initialDose": 10,
		"maxTotalMl": 300,
		"dilution": "10-15 mL/kg for coagulopathy; Neonates: 10-20 mL/kg"
	},
	{
		"id": "whole-blood-fresh-blood-transfusion",
		"name": "Whole Blood / Fresh Blood transfusion",
		"kind": "Bolus Transfusion",
		"doseUnit": "mL/kg",
		"minDose": 20,
		"maxDose": 25,
		"initialDose": 20,
		"maxTotalMl": 500,
		"dilution": "20 mL/kg in acute blood loss; Neonates: cautious volume"
	},
	{
		"id": "artesunate-anti-malarial",
		"name": "Artesunate (Anti-Malarial)",
		"kind": "Weight Logic",
		"standardConc": 10,
		"dilution": "60mg vial + 6ml Sodium Chloride 0.9%"
	}
];
var WHO_BOYS = [
	{
		age: 0,
		p3: 2.3,
		p15: 2.7,
		p50: 3.3,
		p85: 4,
		p97: 4.8
	},
	{
		age: 1,
		p3: 3.2,
		p15: 3.7,
		p50: 4.5,
		p85: 5.5,
		p97: 6.5
	},
	{
		age: 2,
		p3: 4,
		p15: 4.6,
		p50: 5.6,
		p85: 6.8,
		p97: 7.8
	},
	{
		age: 3,
		p3: 4.6,
		p15: 5.3,
		p50: 6.4,
		p85: 7.7,
		p97: 8.8
	},
	{
		age: 4,
		p3: 5,
		p15: 5.8,
		p50: 6.9,
		p85: 8.3,
		p97: 9.5
	},
	{
		age: 5,
		p3: 5.4,
		p15: 6.2,
		p50: 7.4,
		p85: 8.9,
		p97: 10.1
	},
	{
		age: 6,
		p3: 5.7,
		p15: 6.5,
		p50: 7.8,
		p85: 9.3,
		p97: 10.5
	},
	{
		age: 7,
		p3: 5.9,
		p15: 6.7,
		p50: 8,
		p85: 9.6,
		p97: 10.8
	},
	{
		age: 8,
		p3: 6,
		p15: 6.9,
		p50: 8.2,
		p85: 9.8,
		p97: 11
	},
	{
		age: 9,
		p3: 6.2,
		p15: 7.1,
		p50: 8.4,
		p85: 10,
		p97: 11.2
	},
	{
		age: 10,
		p3: 6.4,
		p15: 7.2,
		p50: 8.6,
		p85: 10.2,
		p97: 11.4
	},
	{
		age: 11,
		p3: 6.5,
		p15: 7.4,
		p50: 8.7,
		p85: 10.4,
		p97: 11.6
	},
	{
		age: 12,
		p3: 6.6,
		p15: 7.5,
		p50: 8.9,
		p85: 10.5,
		p97: 11.7
	},
	{
		age: 18,
		p3: 7.4,
		p15: 8.3,
		p50: 9.9,
		p85: 11.8,
		p97: 13
	},
	{
		age: 24,
		p3: 8,
		p15: 9,
		p50: 10.6,
		p85: 12.7,
		p97: 14.1
	},
	{
		age: 30,
		p3: 8.6,
		p15: 9.6,
		p50: 11.3,
		p85: 13.5,
		p97: 15
	},
	{
		age: 36,
		p3: 9,
		p15: 10.1,
		p50: 11.9,
		p85: 14.2,
		p97: 15.8
	},
	{
		age: 48,
		p3: 9.8,
		p15: 11,
		p50: 12.9,
		p85: 15.4,
		p97: 17.1
	},
	{
		age: 60,
		p3: 10.4,
		p15: 11.7,
		p50: 13.7,
		p85: 16.4,
		p97: 18.2
	}
];
var WHO_GIRLS = [
	{
		age: 0,
		p3: 2.2,
		p15: 2.5,
		p50: 3.2,
		p85: 3.8,
		p97: 4.5
	},
	{
		age: 1,
		p3: 3,
		p15: 3.5,
		p50: 4.2,
		p85: 5.2,
		p97: 6
	},
	{
		age: 2,
		p3: 3.7,
		p15: 4.3,
		p50: 5.2,
		p85: 6.3,
		p97: 7.3
	},
	{
		age: 3,
		p3: 4.2,
		p15: 4.9,
		p50: 5.8,
		p85: 7,
		p97: 8
	},
	{
		age: 4,
		p3: 4.5,
		p15: 5.3,
		p50: 6.3,
		p85: 7.5,
		p97: 8.6
	},
	{
		age: 5,
		p3: 4.8,
		p15: 5.6,
		p50: 7.7,
		p85: 8,
		p97: 9
	},
	{
		age: 6,
		p3: 5,
		p15: 5.8,
		p50: 6.9,
		p85: 8.2,
		p97: 9.3
	},
	{
		age: 7,
		p3: 5.1,
		p15: 6,
		p50: 7.1,
		p85: 8.4,
		p97: 9.5
	},
	{
		age: 8,
		p3: 5.3,
		p15: 6.1,
		p50: 7.3,
		p85: 8.6,
		p97: 9.7
	},
	{
		age: 9,
		p3: 5.4,
		p15: 6.3,
		p50: 7.5,
		p85: 8.8,
		p97: 9.9
	},
	{
		age: 10,
		p3: 5.5,
		p15: 6.4,
		p50: 7.6,
		p85: 9,
		p97: 10.1
	},
	{
		age: 11,
		p3: 5.6,
		p15: 6.5,
		p50: 7.8,
		p85: 9.2,
		p97: 10.3
	},
	{
		age: 12,
		p3: 5.7,
		p15: 6.7,
		p50: 7.9,
		p85: 9.3,
		p97: 10.4
	},
	{
		age: 18,
		p3: 6.4,
		p15: 7.4,
		p50: 8.8,
		p85: 10.4,
		p97: 11.5
	},
	{
		age: 24,
		p3: 7,
		p15: 8,
		p50: 9.5,
		p85: 11.2,
		p97: 12.5
	},
	{
		age: 30,
		p3: 7.5,
		p15: 8.5,
		p50: 10.1,
		p85: 11.9,
		p97: 13.3
	},
	{
		age: 36,
		p3: 7.9,
		p15: 9,
		p50: 10.6,
		p85: 12.5,
		p97: 14
	},
	{
		age: 48,
		p3: 9.8,
		p15: 11,
		p50: 12.9,
		p85: 15.4,
		p97: 17.1
	},
	{
		age: 60,
		p3: 10.4,
		p15: 11.7,
		p50: 13.7,
		p85: 16.4,
		p97: 18.2
	}
];
function ageToMonths(unit, value) {
	if (unit === "days") return value / 30.4375;
	if (unit === "years") return value * 12;
	return value;
}
function formatAge(unit, value) {
	if (unit === "days") return `${value} d`;
	if (unit === "years") return `${value} y`;
	return `${value} mo`;
}
function pickRule(drug, ageMonths) {
	if (drug.rules?.length) {
		const rule = drug.rules.find((r) => ageMonths <= r.maxAgeMonths) ?? drug.rules[drug.rules.length - 1];
		if (rule) return {
			mgPerKg: rule.mgPerKg,
			label: rule.label
		};
	}
	return {
		mgPerKg: drug.mgPerKg ?? 0,
		label: "Standard dose"
	};
}
function calculateDose(drug, ageMonths, weightKg) {
	const { mgPerKg, label } = pickRule(drug, ageMonths);
	const notRecommended = mgPerKg <= 0;
	const uncappedMg = weightKg * mgPerKg;
	const capped = uncappedMg > drug.maxMg;
	const totalMg = Math.min(uncappedMg, drug.maxMg);
	return {
		mgPerKg,
		label,
		uncappedMg,
		totalMg,
		capped,
		volumeMl: drug.conc > 0 ? totalMg * drug.vol / drug.conc : null,
		notRecommended
	};
}
function holidaySegar(weightKg) {
	let mlPerHr;
	if (weightKg <= 10) mlPerHr = weightKg * 4;
	else if (weightKg <= 20) mlPerHr = 40 + (weightKg - 10) * 2;
	else mlPerHr = 60 + (weightKg - 20);
	return {
		mlPerHr,
		mlPerDay: mlPerHr * 24
	};
}
function lerp(a, b, t) {
	return a + (b - a) * t;
}
function interpolateCurve(table, age) {
	if (!table.length) return null;
	const first = table[0];
	const last = table[table.length - 1];
	if (!first || !last) return null;
	if (age <= first.age) return first;
	if (age >= last.age) return last;
	for (let i = 0; i < table.length - 1; i += 1) {
		const a = table[i];
		const b = table[i + 1];
		if (!a || !b) continue;
		if (age >= a.age && age <= b.age) {
			const t = (age - a.age) / (b.age - a.age || 1);
			return {
				age,
				p3: lerp(a.p3, b.p3, t),
				p15: lerp(a.p15, b.p15, t),
				p50: lerp(a.p50, b.p50, t),
				p85: lerp(a.p85, b.p85, t),
				p97: lerp(a.p97, b.p97, t)
			};
		}
	}
	return last;
}
function assessGrowth(sex, ageMonths, weightKg) {
	const curve = interpolateCurve(sex === "Boy" ? WHO_BOYS : WHO_GIRLS, ageMonths);
	if (!curve) return {
		band: "p15-p85",
		label: "No reference for this age.",
		curve: null,
		inRange: true
	};
	if (weightKg < curve.p3) return {
		band: "below-p3",
		label: `Weight is below the 3rd percentile (P3 ≈ ${curve.p3.toFixed(1)} kg). Consider nutritional review.`,
		curve,
		inRange: false
	};
	if (weightKg < curve.p15) return {
		band: "p3-p15",
		label: `Weight sits between the 3rd and 15th percentiles (P15 ≈ ${curve.p15.toFixed(1)} kg).`,
		curve,
		inRange: true
	};
	if (weightKg <= curve.p85) return {
		band: "p15-p85",
		label: `Weight is within the typical band (P50 ≈ ${curve.p50.toFixed(1)} kg).`,
		curve,
		inRange: true
	};
	if (weightKg <= curve.p97) return {
		band: "p85-p97",
		label: `Weight sits between the 85th and 97th percentiles (P85 ≈ ${curve.p85.toFixed(1)} kg).`,
		curve,
		inRange: true
	};
	return {
		band: "above-p97",
		label: `Weight is above the 97th percentile (P97 ≈ ${curve.p97.toFixed(1)} kg). Consider nutritional review.`,
		curve,
		inRange: false
	};
}
function pickInfusionRule(inf, ageMonths) {
	if (inf.rules?.length) {
		const rule = inf.rules.find((r) => ageMonths <= r.maxAgeMonths) ?? inf.rules[inf.rules.length - 1];
		if (rule) return {
			perKg: rule.mgPerKg,
			label: rule.label,
			unit: inf.doseUnit ?? "mg/kg"
		};
	}
	if (inf.meqRules?.length) {
		const rule = inf.meqRules.find((r) => ageMonths <= r.maxAgeMonths) ?? inf.meqRules[inf.meqRules.length - 1];
		if (rule) return {
			perKg: rule.meqPerKg,
			label: rule.label,
			unit: "mEq/kg"
		};
	}
	return {
		perKg: inf.initialDose ?? 0,
		label: "Standard dose",
		unit: inf.doseUnit ?? ""
	};
}
function continuousRateMlHr(inf, dose, weightKg) {
	const conc = inf.concPerMl || 1;
	if ((inf.doseUnit ?? "").includes("mcg/kg/min")) return dose * weightKg * 60 / conc;
	return dose * weightKg / conc;
}
function formatNum(n, digits = 1) {
	if (!Number.isFinite(n)) return "—";
	return n.toFixed(digits);
}
function stripMd(text) {
	return text.replace(/\*\*/g, "");
}
var DEPTS = [
	"Internal Medicine",
	"Surgery",
	"Emergency",
	"Chronic Disease",
	"Other"
];
var defaults = {
	name: "New Patient",
	sex: "Boy",
	dept: "Internal Medicine",
	ageUnit: "months",
	ageValue: 12,
	weightKg: 10
};
var usePatient = create()(persist((set, get) => ({
	...defaults,
	log: [],
	setName: (name) => set({ name }),
	setSex: (sex) => set({ sex }),
	setDept: (dept) => set({ dept }),
	setAgeUnit: (ageUnit) => {
		const months = ageToMonths(get().ageUnit, get().ageValue);
		let ageValue = months;
		if (ageUnit === "days") ageValue = Math.round(months * 30.4375);
		if (ageUnit === "years") ageValue = Math.round(months / 12 * 10) / 10;
		if (ageUnit === "months") ageValue = Math.round(months * 10) / 10;
		set({
			ageUnit,
			ageValue
		});
	},
	setAgeValue: (ageValue) => set({ ageValue }),
	setWeightKg: (weightKg) => set({ weightKg }),
	addLog: (action, result) => {
		const s = get();
		set({ log: [{
			id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
			time: (/* @__PURE__ */ new Date()).toISOString(),
			patient: s.name || "N/A",
			ageMonths: ageToMonths(s.ageUnit, s.ageValue),
			weightKg: s.weightKg,
			dept: s.dept,
			action,
			result
		}, ...s.log].slice(0, 200) });
	},
	clearLog: () => set({ log: [] })
}), {
	name: "pediaref-patient",
	skipHydration: true
}));
function AppShell({ children }) {
	(0, import_react.useEffect)(() => {
		usePatient.persist.rehydrate();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "sticky top-0 z-30 border-b border-border bg-bg/90 backdrop-blur-md",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex h-14 max-w-7xl items-center justify-between gap-4 px-4 sm:h-16 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "flex min-w-0 items-center gap-2.5 text-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-8 shrink-0 items-center justify-center rounded-sm bg-accent text-accent-fg shadow-border",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
							viewBox: "0 0 24 24",
							className: "size-4",
							fill: "none",
							"aria-hidden": true,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
								d: "M4 16c2-6 4-9 8-9s6 3 8 9",
								stroke: "currentColor",
								strokeWidth: "1.75"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
								cx: "12",
								cy: "7",
								r: "1.4",
								fill: "currentColor"
							})]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block font-display text-lg leading-tight tracking-tight",
							children: "PediaRef"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden text-xs tracking-wide text-muted sm:block",
							children: "Dosing · growth · fluids"
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeaderCase, {})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto w-full max-w-7xl px-4 py-6 sm:px-6 sm:py-8",
			children
		})]
	});
}
function HeaderCase() {
	const name = usePatient((s) => s.name);
	const sex = usePatient((s) => s.sex);
	const ageUnit = usePatient((s) => s.ageUnit);
	const ageValue = usePatient((s) => s.ageValue);
	const weightKg = usePatient((s) => s.weightKg);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "truncate font-mono text-xs tabular-nums text-muted",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-fg",
				children: name || "Unnamed"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mx-1.5 text-subtle",
				children: "·"
			}),
			sex,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mx-1.5 text-subtle",
				children: "·"
			}),
			formatAge(ageUnit, ageValue),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mx-1.5 text-subtle",
				children: "·"
			}),
			weightKg,
			" kg"
		]
	});
}
function Disclaimer() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-10 max-w-3xl text-xs leading-relaxed text-subtle",
		children: "Educational reference only — not a prescribing chart. Verify every dose, dilution, and indication against your unit protocol and a supervising clinician. Patient entries stay on this device."
	});
}
var styles_default = "/assets/styles-EAAe5AD7.css";
var APP_NAME = "PediaRef";
var Route$1 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Pediatric reference: age-smart dosing, WHO growth curves, Holliday–Segar fluids, and infusion rates."
			},
			{
				name: "theme-color",
				content: "#f4f1ea"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&family=IBM+Plex+Sans:ital,wght@0,400;0,500;0,600;1,400&family=Newsreader:opsz,wght@6..72,500;6..72,600&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter = () => import("./routes-CgoYR9mK.mjs");
var rootRouteChildren = { IndexRoute: createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter, "component") }).update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$1
}) };
var routeTree = Route$1._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { WHO_GIRLS as _, ageToMonths as a, continuousRateMlHr as c, holidaySegar as d, pickInfusionRule as f, WHO_BOYS as g, INFUSIONS as h, usePatient as i, formatAge as l, DRUGS as m, Disclaimer as n, assessGrowth as o, stripMd as p, DEPTS as r, calculateDose as s, router_exports as t, formatNum as u };

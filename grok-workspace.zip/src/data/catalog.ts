export type AgeRule = { maxAgeMonths: number; mgPerKg: number; label: string };
export type Drug = {
  id: string;
  name: string;
  category: string;
  conc: number;
  vol: number;
  maxMg: number;
  mgPerKg?: number;
  rules?: AgeRule[];
  notes?: string;
};

export const DRUGS: Drug[] = [
  {"id": "amoxicillin-susp", "name": "Amoxicillin (Susp)", "category": "Antibiotics", "conc": 250, "vol": 5, "maxMg": 1000, "rules": [{"maxAgeMonths": 6, "mgPerKg": 20, "label": "Infants < 6 Months"}, {"maxAgeMonths": 24, "mgPerKg": 40, "label": "Infants 6-24 Months"}, {"maxAgeMonths": 216, "mgPerKg": 25, "label": "Children > 2 Years"}]},
  {"id": "ampiclox-ampicillin-cloxacillin", "name": "Ampiclox (Ampicillin+Cloxacillin)", "category": "Antibiotics", "conc": 250, "vol": 5, "maxMg": 2000, "mgPerKg": 50},
  {"id": "cefotaxime", "name": "Cefotaxime", "category": "Antibiotics", "conc": 1000, "vol": 10, "maxMg": 2000, "rules": [{"maxAgeMonths": 1, "mgPerKg": 50, "label": "Neonate Dose (<1 month)"}, {"maxAgeMonths": 216, "mgPerKg": 75, "label": "Standard Dose (Children)"}]},
  {"id": "amikacin", "name": "Amikacin", "category": "Antibiotics", "conc": 250, "vol": 2, "maxMg": 1500, "rules": [{"maxAgeMonths": 1, "mgPerKg": 15, "label": "Neonate Dose (<1 month)"}, {"maxAgeMonths": 216, "mgPerKg": 17.5, "label": "Children Dose"}]},
  {"id": "gentamicin-iv-im", "name": "Gentamicin (IV/IM)", "category": "Antibiotics", "conc": 40, "vol": 2, "maxMg": 400, "rules": [{"maxAgeMonths": 1, "mgPerKg": 4.5, "label": "Neonate Dose (<1 month)"}, {"maxAgeMonths": 12, "mgPerKg": 6.25, "label": "Infant Dose (1-12 months)"}, {"maxAgeMonths": 216, "mgPerKg": 6.25, "label": "Child Dose (>12 months)"}]},
  {"id": "penicillin-g-benzylpenicillin", "name": "Penicillin G (Benzylpenicillin)", "category": "Antibiotics", "conc": 1000000, "vol": 10, "maxMg": 4000000, "rules": [{"maxAgeMonths": 1, "mgPerKg": 37500, "label": "Neonate Dose (<1 month)"}, {"maxAgeMonths": 216, "mgPerKg": 75000, "label": "Children Dose"}]},
  {"id": "metronidazole-flagyl", "name": "Metronidazole (Flagyl)", "category": "Antibiotics", "conc": 200, "vol": 5, "maxMg": 500, "rules": [{"maxAgeMonths": 1, "mgPerKg": 7.5, "label": "Neonate Dose (<1 month)"}, {"maxAgeMonths": 216, "mgPerKg": 7.5, "label": "Children Dose"}]},
  {"id": "acyclovir", "name": "Acyclovir", "category": "Antibiotics", "conc": 500, "vol": 10, "maxMg": 1000, "rules": [{"maxAgeMonths": 1, "mgPerKg": 20, "label": "Neonate Dose (<1 month)"}, {"maxAgeMonths": 216, "mgPerKg": 15, "label": "Children Dose"}]},
  {"id": "clindamycin", "name": "Clindamycin", "category": "Antibiotics", "conc": 150, "vol": 5, "maxMg": 900, "rules": [{"maxAgeMonths": 1, "mgPerKg": 10, "label": "Neonate Dose (<1 month)"}, {"maxAgeMonths": 216, "mgPerKg": 35, "label": "Children Dose"}]},
  {"id": "erythromycin", "name": "Erythromycin", "category": "Antibiotics", "conc": 200, "vol": 5, "maxMg": 500, "rules": [{"maxAgeMonths": 1, "mgPerKg": 10, "label": "Neonate Dose (<1 month)"}, {"maxAgeMonths": 216, "mgPerKg": 12.5, "label": "Child Dose (>1 month)"}], "notes": "30-50 mg/kg/day ÷4; Neonates: 10 mg/kg q12h (motility); Children: 12.5 mg/kg q6h"},
  {"id": "clarithromycin", "name": "Clarithromycin", "category": "Antibiotics", "conc": 125, "vol": 5, "maxMg": 500, "rules": [{"maxAgeMonths": 6, "mgPerKg": 0, "label": "Infants < 6 Months (Not Recommended)"}, {"maxAgeMonths": 216, "mgPerKg": 7.5, "label": "Children > 6 Months (15 mg/kg/day ÷2)"}], "notes": "15 mg/kg/day ÷2; Neonates: not recommended; Children >6 mo: for atypical pneumonia"},
  {"id": "ciprofloxacin", "name": "Ciprofloxacin", "category": "Antibiotics", "conc": 200, "vol": 5, "maxMg": 750, "rules": [{"maxAgeMonths": 1, "mgPerKg": 0, "label": "Neonate Dose (Avoid, cartilage risk)"}, {"maxAgeMonths": 216, "mgPerKg": 15, "label": "Children Dose (>1 month, not first-line)"}], "notes": "30 mg/kg/day ÷2; Not first-line in children <18 yr except specific cases (e.g., Pseudomonas); Neonates: avoid due to cartilage risk"},
  {"id": "co-trimoxazole-septrin", "name": "Co-trimoxazole (Septrin)", "category": "Antibiotics", "conc": 240, "vol": 5, "maxMg": 960, "rules": [{"maxAgeMonths": 2, "mgPerKg": 0, "label": "Contraindicated < 2 Months"}, {"maxAgeMonths": 216, "mgPerKg": 8, "label": "Standard Pediatric Dose"}]},
  {"id": "ceftriaxone", "name": "Ceftriaxone", "category": "Antibiotics", "conc": 250, "vol": 5, "maxMg": 4000, "rules": [{"maxAgeMonths": 1, "mgPerKg": 50, "label": "Neonate Dose (<1 month)"}, {"maxAgeMonths": 12, "mgPerKg": 80, "label": "Infant Dose (1-12 months)"}, {"maxAgeMonths": 216, "mgPerKg": 85, "label": "Child Dose (>12 months)"}], "notes": "Typically 50-100 mg/kg/day. Max 4g/day. For severe infections, meningitis. Given IM/IV."},
  {"id": "adrenaline-nebulizer", "name": "Adrenaline (Nebulizer)", "category": "Emergency", "conc": 1, "vol": 1, "maxMg": 5, "rules": [{"maxAgeMonths": 216, "mgPerKg": 0.01, "label": "Standard Pediatric Dose (max 5mg)"}], "notes": "0.5mg/kg (max 5mg) of 1:1000 adrenaline (1mg/ml) diluted to 5ml NS. Refer to MSF Pediatric protocols."},
  {"id": "azithromycin-susp", "name": "Azithromycin (Susp)", "category": "Antibiotics", "conc": 200, "vol": 5, "maxMg": 500, "rules": [{"maxAgeMonths": 6, "mgPerKg": 0, "label": "Infants < 6 Months (Consult Specialist)"}, {"maxAgeMonths": 216, "mgPerKg": 10, "label": "Standard Pediatric Dose"}], "notes": "Often 10 mg/kg once daily for 3 days, or 10 mg/kg on day 1 then 5 mg/kg for 4 days. Max 500mg."},
  {"id": "levetiracetam", "name": "Levetiracetam", "category": "Antiepileptics", "conc": 100, "vol": 1, "maxMg": 1500, "rules": [{"maxAgeMonths": 216, "mgPerKg": 20, "label": "Standard Pediatric Maintenance Dose"}], "notes": "**Status Epilepticus (SE) - Third-line (20-60 min):** If first and second-line therapies fail. Loading dose: 20-60 mg/kg IV (often 40 mg/kg) over 15-30 min. Maintenance: 10-30 mg/kg/dose BID (max 3000 mg/day). Ensure adequate IV access and monitor for side effects."},
  {"id": "diazepam-iv-for-seizures", "name": "Diazepam (IV for seizures)", "category": "Antiepileptics", "conc": 10, "vol": 2, "maxMg": 10, "mgPerKg": 0.2, "notes": "**Status Epilepticus (SE) - First-line (0-5 min):** Administer 0.2-0.5 mg/kg IV slow (max 5mg <5yr, 10mg >=5yr). Repeat once after 5-10 min if SE persists. Max 2 doses. If SE continues after 10 min (total 15 min), proceed to Second-line therapy (Phenobarbital or Phenytoin). Neonates: 0.1-0.3 mg/kg/dose IV (lower due to prolonged half-life); Infants/Children: 0.2-0.5 mg/kg/dose; Max single dose <5 yr: 5 mg, ≥5 yr: 10 mg."},
  {"id": "phenobarbital-loading", "name": "Phenobarbital (Loading)", "category": "Antiepileptics", "conc": 120, "vol": 2, "maxMg": 1000, "rules": [{"maxAgeMonths": 1, "mgPerKg": 15, "label": "Neonate Dose (<1 month)"}, {"maxAgeMonths": 216, "mgPerKg": 20, "label": "Infant/Child Dose"}], "notes": "**Status Epilepticus (SE) - Second-line (5-20 min):** If first-line benzodiazepines fail after 2 doses. Loading dose: 15-20 mg/kg IV over 10-20 min. May repeat 5-10 mg/kg once if SE persists (up to max total 40 mg/kg). If SE continues after 20 min (total 35 min), consider Third-line therapy (Levetiracetam, continuous Midazolam/Propofol)."},
  {"id": "phenobarbital-maintenance", "name": "Phenobarbital (Maintenance)", "category": "Antiepileptics", "conc": 120, "vol": 2, "maxMg": 300, "rules": [{"maxAgeMonths": 1, "mgPerKg": 3, "label": "Neonate Dose (<1 month)"}, {"maxAgeMonths": 216, "mgPerKg": 5, "label": "Infant/Child Dose"}]},
  {"id": "phenytoin-loading", "name": "Phenytoin (Loading)", "category": "Antiepileptics", "conc": 50, "vol": 5, "maxMg": 1000, "rules": [{"maxAgeMonths": 1, "mgPerKg": 15, "label": "Neonate Dose (<1 month)"}, {"maxAgeMonths": 216, "mgPerKg": 20, "label": "Infant/Child Dose"}], "notes": "**Status Epilepticus (SE) - Second-line (5-20 min):** If first-line benzodiazepines fail after 2 doses. Loading dose: 15-20 mg/kg IV over 10-20 min (max infusion rate 1 mg/kg/min). Monitor ECG/BP closely due to cardiac side effects. Max total loading dose 30 mg/kg. If SE continues after 20 min (total 35 min), consider Third-line therapy (Levetiracetam, continuous Midazolam/Propofol)."},
  {"id": "phenytoin-maintenance", "name": "Phenytoin (Maintenance)", "category": "Antiepileptics", "conc": 50, "vol": 5, "maxMg": 300, "rules": [{"maxAgeMonths": 1, "mgPerKg": 4, "label": "Neonate Dose (<1 month)"}, {"maxAgeMonths": 216, "mgPerKg": 8, "label": "Infant/Child Dose"}]},
  {"id": "midazolam-iv-bolus", "name": "Midazolam (IV bolus)", "category": "Antiepileptics", "conc": 1, "vol": 5, "maxMg": 10, "rules": [{"maxAgeMonths": 1, "mgPerKg": 0.05, "label": "Neonate Dose (<1 month)"}, {"maxAgeMonths": 216, "mgPerKg": 0.1, "label": "Infant/Child Dose"}], "notes": "**Status Epilepticus (SE) - First-line (0-5 min):** Administer 0.1-0.2 mg/kg IV/IM/buccal (max 5mg <5yr, 10mg >=5yr). Repeat once after 5-10 min if SE persists. Max 2 doses. If SE continues after 10 min (total 15 min), proceed to Second-line therapy (Phenobarbital or Phenytoin). For Refractory SE (Third-line, 20-60 min), a continuous Midazolam infusion (0.05-0.4 mg/kg/hr) may be needed. Neonates: 0.05 mg/kg; Infants/Children: 0.1-0.2 mg/kg."},
  {"id": "dexamethasone", "name": "Dexamethasone", "category": "Corticosteroids", "conc": 8, "vol": 2, "maxMg": 16, "mgPerKg": 0.5, "notes": "Generally same across ages; Neonates may need adjustment for cerebral edema"},
  {"id": "prednisolone-syrup", "name": "Prednisolone (Syrup)", "category": "Corticosteroids", "conc": 5, "vol": 5, "maxMg": 60, "rules": [{"maxAgeMonths": 1, "mgPerKg": 0.5, "label": "Neonate Dose"}, {"maxAgeMonths": 216, "mgPerKg": 1, "label": "Child Dose"}], "notes": "Loading: 1-2 mg/kg/day (methylpred equiv); Maintenance: 0.5-1 mg/kg/day; Neonates: lower doses; Children: adjust for inflammation/asthma"},
  {"id": "quinine", "name": "Quinine", "category": "Antimalarials", "conc": 300, "vol": 2, "maxMg": 600, "mgPerKg": 10, "notes": "Loading 20 mg/kg then 10 mg/kg q8h; Neonates/Infants: monitor hypoglycemia closely"},
  {"id": "dextrose-10-loading-for-hypoglycemia", "name": "Dextrose 10% (Loading for Hypoglycemia)", "category": "Emergency", "conc": 100, "vol": 5, "maxMg": 250, "mgPerKg": 500, "notes": "Neonates: 2-5 mL/kg bolus; Children: similar; Follow with maintenance"},
  {"id": "calcium-gluconate-10", "name": "Calcium Gluconate 10%", "category": "Emergency", "conc": 100, "vol": 1, "maxMg": 2000, "rules": [{"maxAgeMonths": 1, "mgPerKg": 100, "label": "Neonate Dose (<1 month)"}, {"maxAgeMonths": 216, "mgPerKg": 50, "label": "Child Dose (>1 month)"}], "notes": "Neonates: 100-200 mg/kg/dose slow IV; Children: 50-100 mg/kg/dose; Monitor ECG"},
  {"id": "sodium-bicarbonate-nahco3", "name": "Sodium Bicarbonate (NaHCO3)", "category": "Emergency", "conc": 84, "vol": 1, "maxMg": 1000, "mgPerKg": 84, "notes": "Neonates: cautious use, 1-2 mEq/kg slow; Children: same; Only if severe acidosis"},
  {"id": "furosemide-lasix", "name": "Furosemide (Lasix)", "category": "Emergency", "conc": 10, "vol": 2, "maxMg": 40, "rules": [{"maxAgeMonths": 1, "mgPerKg": 1, "label": "Neonate Dose (<1 month)"}, {"maxAgeMonths": 216, "mgPerKg": 1, "label": "Child Dose (>1 month)"}], "notes": "Neonates: 1 mg/kg/dose (may need higher); Children: 1-2 mg/kg/dose q6-12h"},
  {"id": "vitamin-k-phytonadione", "name": "Vitamin K (Phytonadione)", "category": "Blood & nutrition", "conc": 10, "vol": 1, "maxMg": 10, "rules": [{"maxAgeMonths": 1, "mgPerKg": 0.5, "label": "Neonate Prophylaxis"}, {"maxAgeMonths": 216, "mgPerKg": 5, "label": "Therapeutic Dose"}], "notes": "Neonates: 0.5-1 mg IM/IV once for prophylaxis. Therapeutic: 5-10 mg IM/IV"},
  {"id": "iron-oral-ferrous-sulfate", "name": "Iron (Oral) (Ferrous Sulfate)", "category": "Blood & nutrition", "conc": 30, "vol": 1, "maxMg": 100, "rules": [{"maxAgeMonths": 6, "mgPerKg": 1, "label": "Prophylaxis < 6mo (elemental iron)"}, {"maxAgeMonths": 216, "mgPerKg": 3, "label": "Treatment (elemental iron)"}], "notes": "Prophylaxis: 1-2 mg/kg/day elemental iron; Treatment: 3-6 mg/kg/day elemental iron. Adjust for formulation."},
  {"id": "folic-acid", "name": "Folic Acid", "category": "Blood & nutrition", "conc": 1, "vol": 1, "maxMg": 5, "rules": [{"maxAgeMonths": 12, "mgPerKg": 0.05, "label": "Infant Prophylaxis"}, {"maxAgeMonths": 216, "mgPerKg": 0.5, "label": "Child Therapeutic"}], "notes": "Prophylaxis: 0.05-0.1 mg/day; Therapeutic: 0.5-1 mg/day"},
  {"id": "paracetamol-syrup", "name": "Paracetamol (Syrup)", "category": "Analgesics", "conc": 120, "vol": 5, "maxMg": 1000, "rules": [{"maxAgeMonths": 1, "mgPerKg": 10, "label": "Neonate Dose"}, {"maxAgeMonths": 216, "mgPerKg": 15, "label": "Standard Pediatric Dose"}]},
  {"id": "paracetamol-infusion", "name": "Paracetamol (Infusion)", "category": "Analgesics", "conc": 1000, "vol": 100, "maxMg": 1000, "rules": [{"maxAgeMonths": 1, "mgPerKg": 7.5, "label": "Neonate Dose"}, {"maxAgeMonths": 216, "mgPerKg": 10, "label": "Standard Pediatric Dose"}]},
  {"id": "ibuprofen-advil-fenistil", "name": "Ibuprofen (Advil/Fenistil)", "category": "Analgesics", "conc": 100, "vol": 5, "maxMg": 400, "rules": [{"maxAgeMonths": 6, "mgPerKg": 0, "label": "Not Recommended < 6 Months"}, {"maxAgeMonths": 216, "mgPerKg": 10, "label": "Standard Pediatric Dose"}]},
  {"id": "diclofenac-voltaren-supp", "name": "Diclofenac (Voltaren Supp)", "category": "Analgesics", "conc": 12.5, "vol": 1, "maxMg": 50, "rules": [{"maxAgeMonths": 12, "mgPerKg": 0, "label": "Avoid in Infants < 1 Year"}, {"maxAgeMonths": 216, "mgPerKg": 1, "label": "Standard Dose (1-3 mg/kg/day)"}]},
  {"id": "combivent-nebulizer", "name": "Combivent (Nebulizer)", "category": "Respiratory", "conc": 2.5, "vol": 2.5, "maxMg": 5, "rules": [{"maxAgeMonths": 12, "mgPerKg": 0.1, "label": "Infant Nebulization"}, {"maxAgeMonths": 216, "mgPerKg": 0.15, "label": "Children Nebulization"}]},
  {"id": "chlorpheniramine-allerfin", "name": "Chlorpheniramine (Allerfin)", "category": "Respiratory", "conc": 2, "vol": 5, "maxMg": 4, "rules": [{"maxAgeMonths": 24, "mgPerKg": 0, "label": "Avoid < 2 Years (Sedation Risk)"}, {"maxAgeMonths": 216, "mgPerKg": 0.1, "label": "Standard Pediatric Dose"}]},
  {"id": "domperidone-motilium", "name": "Domperidone (Motilium)", "category": "Gastrointestinal", "conc": 5, "vol": 5, "maxMg": 10, "rules": [{"maxAgeMonths": 216, "mgPerKg": 0.25, "label": "Standard Dose (TDS)"}]},
  {"id": "ondansetron-zofran", "name": "Ondansetron (Zofran)", "category": "Gastrointestinal", "conc": 2, "vol": 1, "maxMg": 8, "rules": [{"maxAgeMonths": 6, "mgPerKg": 0, "label": "Not Recommended < 6 Months"}, {"maxAgeMonths": 216, "mgPerKg": 0.15, "label": "Standard Dose"}]},
  {"id": "hyoscine-buscopan-syrup", "name": "Hyoscine (Buscopan Syrup)", "category": "Gastrointestinal", "conc": 5, "vol": 5, "maxMg": 10, "rules": [{"maxAgeMonths": 72, "mgPerKg": 0.5, "label": "Children 1-6 Years"}, {"maxAgeMonths": 216, "mgPerKg": 0.7, "label": "Children > 6 Years"}]},
  {"id": "cefixime-susp", "name": "Cefixime (Susp)", "category": "Antibiotics", "conc": 200, "vol": 5, "maxMg": 400, "rules": [{"maxAgeMonths": 6, "mgPerKg": 0, "label": "Infants < 6 Months (Not Recommended)"}, {"maxAgeMonths": 216, "mgPerKg": 8, "label": "Children >= 6 Months (8 mg/kg/day)"}], "notes": "Typically given orally as a suspension. Dosage is 8mg/kg/day, usually given once or divided BID."},
  {"id": "albumin-25", "name": "Albumin 25%", "category": "Blood & nutrition", "conc": 250, "vol": 1, "maxMg": 100000, "mgPerKg": 250, "notes": "Dose: 0.5-1 g/kg (2-4 ml/kg of 25% albumin). Infuse over 30-60 mins, faster in emergencies. Mg/kg is used as a placeholder here, actual calculation should be mL/kg."},
  {"id": "digoxin-oral-solution", "name": "Digoxin (Oral Solution)", "category": "Cardiovascular", "conc": 0.05, "vol": 1, "maxMg": 0.25, "rules": [{"maxAgeMonths": 1, "mgPerKg": 0.005, "label": "Neonate Maintenance Dose (5 mcg/kg/day)"}, {"maxAgeMonths": 216, "mgPerKg": 0.008, "label": "Infant/Child Maintenance Dose (8 mcg/kg/day)"}], "notes": "Requires careful monitoring (ECG, electrolytes, levels). Dosage depends on loading dose and renal function. Doses are per day."},
  {"id": "rabeprazole", "name": "Rabeprazole", "category": "Gastrointestinal", "conc": 10, "vol": 1, "maxMg": 20, "rules": [{"maxAgeMonths": 144, "mgPerKg": 0.6, "label": "Children 1-11 Years (10mg total daily)"}, {"maxAgeMonths": 216, "mgPerKg": 0.5, "label": "Children 12+ Years (20mg total daily)"}], "notes": "Administer 30 mins before food. For GERD/peptic ulcers. The mg/kg values are an approximation for the total daily dose (10mg/day for 1-11y, 20mg/day for 12+y)."},
  {"id": "amlodipine-oral-solution", "name": "Amlodipine (Oral Solution)", "category": "Cardiovascular", "conc": 1, "vol": 1, "maxMg": 10, "rules": [{"maxAgeMonths": 72, "mgPerKg": 0.05, "label": "Children 1-5 Years (Initial Dose)"}, {"maxAgeMonths": 216, "mgPerKg": 0.1, "label": "Children > 6 Years (Initial Dose)"}], "notes": "Start low and titrate. Used for hypertension. Can be prepared from tablets."},
  {"id": "zinc-syrup-elemental", "name": "Zinc Syrup (Elemental)", "category": "Blood & nutrition", "conc": 2, "vol": 1, "maxMg": 10, "rules": [{"maxAgeMonths": 6, "mgPerKg": 0.5, "label": "Infants 0-6 Months (2.5mg total daily)"}, {"maxAgeMonths": 12, "mgPerKg": 0.6, "label": "Infants 6-12 Months (5mg total daily)"}, {"maxAgeMonths": 60, "mgPerKg": 0.65, "label": "Children 1-5 Years (10mg total daily)"}], "notes": "For diarrhea management (WHO protocol) or zinc deficiency. Administer away from dairy/iron. Doses are total elemental zinc per day."},
  {"id": "vitamin-d3-oral-drops", "name": "Vitamin D3 (Oral Drops)", "category": "Blood & nutrition", "conc": 0.01, "vol": 1, "maxMg": 0.05, "rules": [{"maxAgeMonths": 12, "mgPerKg": 0.001, "label": "Infants 0-12 Months (400 IU/day)"}, {"maxAgeMonths": 216, "mgPerKg": 0.001, "label": "Children >1 Year (600 IU/day)"}], "notes": "Prophylaxis dose. 1 mcg = 40 IU. The mg/kg values are an approximation for the fixed total daily IU dose. Actual dosing is in IU."},
  {"id": "calcium-supplemental-syrup-elemental", "name": "Calcium Supplemental Syrup (Elemental)", "category": "Blood & nutrition", "conc": 20, "vol": 1, "maxMg": 1000, "mgPerKg": 25, "notes": "For calcium deficiency. Elemental calcium varies by salt. Give in divided doses."},
];

export const DRUG_CATEGORIES = [...new Set(DRUGS.map((d) => d.category))];

export type Infusion = {
  id: string;
  name: string;
  kind: string;
  doseUnit?: string;
  minDose?: number;
  maxDose?: number;
  initialDose?: number;
  concPerMl?: number;
  concDisplayUnit?: string;
  concMgMl?: number;
  concMeqMl?: number;
  suggestedDilutionMl?: number;
  maxTotalMl?: number;
  dextrosePercents?: number[];
  standardConc?: number;
  dilution?: string;
  rules?: AgeRule[];
  meqRules?: { maxAgeMonths: number; meqPerKg: number; label: string }[];
};
export const INFUSIONS: Infusion[] = [
  {"id": "dopamine", "name": "Dopamine", "kind": "Continuous", "doseUnit": "mcg/kg/min", "minDose": 2, "maxDose": 20, "initialDose": 5, "concPerMl": 4000, "concDisplayUnit": "mcg/ml", "dilution": "Standard: 200mg in 50ml NS"},
  {"id": "adrenaline-epinephrine", "name": "Adrenaline (Epinephrine)", "kind": "Continuous", "doseUnit": "mcg/kg/min", "minDose": 0.05, "maxDose": 1.0, "initialDose": 0.1, "concPerMl": 20, "concDisplayUnit": "mcg/ml", "dilution": "Standard: 1mg in 50ml NS"},
  {"id": "fentanyl", "name": "Fentanyl", "kind": "Continuous", "doseUnit": "mcg/kg/hr", "minDose": 1, "maxDose": 5, "initialDose": 2, "concPerMl": 10, "concDisplayUnit": "mcg/ml", "dilution": "Standard: 500mcg in 50ml NS"},
  {"id": "midazolam", "name": "Midazolam", "kind": "Continuous", "doseUnit": "mg/kg/hr", "minDose": 0.05, "maxDose": 0.4, "initialDose": 0.1, "concPerMl": 1, "concDisplayUnit": "mg/ml", "dilution": "Standard: 50mg in 50ml NS"},
  {"id": "insulin", "name": "Insulin", "kind": "Insulin Unit Infusion", "doseUnit": "units/kg/hr", "minDose": 0.01, "maxDose": 0.1, "initialDose": 0.05, "concPerMl": 1, "concDisplayUnit": "units/ml", "dilution": "Standard: 50 units Regular Insulin in 50ml NS"},
  {"id": "kcl-correction", "name": "KCL Correction", "kind": "Kcl mEq/kg Correction", "doseUnit": "mEq/kg", "minDose": 0.1, "maxDose": 0.5, "initialDose": 0.2, "concPerMl": 2, "concDisplayUnit": "mEq/ml", "dilution": "Standard KCL solution (e.g., 10mEq/5ml)"},
  {"id": "magnesium-sulfate", "name": "Magnesium Sulfate", "kind": "Continuous", "doseUnit": "mg/kg/hr", "minDose": 10, "maxDose": 50, "initialDose": 20, "concPerMl": 100, "concDisplayUnit": "mg/ml", "dilution": "Standard: 5g MgSO4 in 50ml NS"},
  {"id": "cefotaxime", "name": "Cefotaxime", "kind": "Intermittent Dose Infusion", "doseUnit": "mg/kg", "concMgMl": 100, "suggestedDilutionMl": 50, "dilution": "Dilute in NS/D5W. Infuse over 30-60 min.", "rules": [{"maxAgeMonths": 1, "mgPerKg": 50, "label": "Neonate Dose (<1 month)"}, {"maxAgeMonths": 216, "mgPerKg": 75, "label": "Standard Dose (Children)"}]},
  {"id": "paracetamol-iv", "name": "Paracetamol (IV)", "kind": "Intermittent Dose Infusion", "doseUnit": "mg/kg", "concMgMl": 10, "suggestedDilutionMl": 50, "dilution": "Infuse over 15 minutes. Consider dilution to 1-2 mg/ml for smaller volumes. Max 1000mg/dose.", "rules": [{"maxAgeMonths": 1, "mgPerKg": 10, "label": "Neonate Dose (10 mg/kg)"}, {"maxAgeMonths": 216, "mgPerKg": 10, "label": "Infant/Child Dose (10-15 mg/kg)"}]},
  {"id": "meropenem", "name": "Meropenem", "kind": "Intermittent Dose Infusion", "doseUnit": "mg/kg", "concMgMl": 50, "suggestedDilutionMl": 50, "dilution": "Dilute in NS. Infuse over 15-30 min.", "rules": [{"maxAgeMonths": 1, "mgPerKg": 20, "label": "Neonate Dose (<1 month)"}, {"maxAgeMonths": 216, "mgPerKg": 20, "label": "Children Dose"}]},
  {"id": "vancomycin", "name": "Vancomycin", "kind": "Intermittent Dose Infusion", "doseUnit": "mg/kg", "concMgMl": 50, "suggestedDilutionMl": 100, "dilution": "Dilute in NS/D5W (max 5mg/ml). Infuse over 60 min (longer for higher doses) to avoid Red Man Syndrome.", "rules": [{"maxAgeMonths": 1, "mgPerKg": 12.5, "label": "Neonate Dose (<1 month)"}, {"maxAgeMonths": 216, "mgPerKg": 15, "label": "Children Dose"}]},
  {"id": "dextrose-continuous", "name": "Dextrose % (Continuous)", "kind": "Continuous Dextrose Infusion", "doseUnit": "mg/kg/min (GIR)", "minDose": 4, "maxDose": 10, "initialDose": 6, "dextrosePercents": [5, 10, 12.5, 25], "dilution": "Glucose Infusion Rate (GIR) calculation. Select available dextrose concentration."},
  {"id": "calcium-gluconate-10", "name": "Calcium Gluconate 10%", "kind": "Intermittent Dose Infusion", "doseUnit": "mg/kg", "concMgMl": 100, "suggestedDilutionMl": 50, "dilution": "Slow IV Infusion over 30-60 min. Max infusion rate 50mg/kg/hr.", "rules": [{"maxAgeMonths": 1, "mgPerKg": 100, "label": "Neonate Dose (<1 month)"}, {"maxAgeMonths": 216, "mgPerKg": 50, "label": "Child Dose (>1 month)"}]},
  {"id": "sodium-bicarbonate-nahco3", "name": "Sodium Bicarbonate (NaHCO3)", "kind": "Intermittent mEq/kg Infusion", "doseUnit": "mEq/kg", "concMeqMl": 1, "suggestedDilutionMl": 50, "dilution": "Infuse slowly over 30-60 min. Use with caution in neonates; dilute 1:1 with D5W. Max 1 mEq/kg/min.", "meqRules": [{"maxAgeMonths": 216, "meqPerKg": 1, "label": "Standard Dose (1 mEq/kg)"}]},
  {"id": "furosemide-lasix", "name": "Furosemide (Lasix)", "kind": "Continuous", "doseUnit": "mg/kg/hr", "minDose": 0.05, "maxDose": 0.4, "initialDose": 0.1, "concPerMl": 1, "concDisplayUnit": "mg/ml", "dilution": "Standard: 20mg in 20ml NS. Titrate to effect."},
  {"id": "hydrocortisone", "name": "Hydrocortisone", "kind": "Continuous", "doseUnit": "mg/kg/hr", "minDose": 0.1, "maxDose": 0.4, "initialDose": 0.2, "concPerMl": 1, "concDisplayUnit": "mg/ml", "dilution": "Standard: 100mg in 100ml NS/D5W. For stress doses in adrenal insufficiency or shock."},
  {"id": "ceftriaxone", "name": "Ceftriaxone", "kind": "Intermittent Dose Infusion", "doseUnit": "mg/kg", "concMgMl": 100, "suggestedDilutionMl": 50, "dilution": "Reconstitute to 100mg/ml, then dilute further in NS/D5W. Infuse over 30-60 min. Max 4g/day.", "rules": [{"maxAgeMonths": 1, "mgPerKg": 50, "label": "Neonate Dose (<1 month)"}, {"maxAgeMonths": 12, "mgPerKg": 80, "label": "Infant Dose (1-12 months)"}, {"maxAgeMonths": 216, "mgPerKg": 85, "label": "Child Dose (>12 months)"}]},
  {"id": "levetiracetam", "name": "Levetiracetam", "kind": "Intermittent Dose Infusion", "doseUnit": "mg/kg", "concMgMl": 100, "suggestedDilutionMl": 50, "dilution": "**Status Epilepticus (SE) - Third-line (20-60 min):** If first and second-line therapies fail. Dilute to 10-20 mg/ml in NS or D5W. Infuse over 15-30 min. For maintenance, 10-30 mg/kg/dose BID IV/PO. Monitor for adverse effects.", "rules": [{"maxAgeMonths": 216, "mgPerKg": 40, "label": "Status Epilepticus Loading Dose"}]},
  {"id": "diazepam-se-iv-bolus", "name": "Diazepam (SE IV Bolus)", "kind": "Intermittent Dose Infusion", "doseUnit": "mg/kg", "concMgMl": 2.5, "suggestedDilutionMl": 0, "dilution": "**Status Epilepticus (SE) - First-line (0-5 min):** Administer slow IV (undiluted or diluted in NS/D5W). Max 5mg (<5yr) or 10mg (>=5yr) per dose. Repeat once after 5-10 min if SE persists. Max 2 doses. If SE continues after 10 min (total 15 min), proceed to Second-line.", "rules": [{"maxAgeMonths": 1, "mgPerKg": 0.15, "label": "Neonate Dose (<1 month)"}, {"maxAgeMonths": 216, "mgPerKg": 0.35, "label": "Infant/Child Dose"}]},
  {"id": "midazolam-se-iv-bolus", "name": "Midazolam (SE IV Bolus)", "kind": "Intermittent Dose Infusion", "doseUnit": "mg/kg", "concMgMl": 1, "suggestedDilutionMl": 0, "dilution": "**Status Epilepticus (SE) - First-line (0-5 min):** Administer IV/IM/buccal (can be diluted in NS/D5W). Max 5mg (<5yr) or 10mg (>=5yr) per dose. Repeat once after 5-10 min if SE persists. Max 2 doses. If SE continues after 10 min (total 15 min), proceed to Second-line.", "rules": [{"maxAgeMonths": 1, "mgPerKg": 0.05, "label": "Neonate Dose (<1 month)"}, {"maxAgeMonths": 216, "mgPerKg": 0.15, "label": "Infant/Child Dose"}]},
  {"id": "phenobarbital-se-iv-loading", "name": "Phenobarbital (SE IV Loading)", "kind": "Intermittent Dose Infusion", "doseUnit": "mg/kg", "concMgMl": 60, "suggestedDilutionMl": 50, "dilution": "**Status Epilepticus (SE) - Second-line (5-20 min):** If first-line benzodiazepines fail. Loading dose: 15-20 mg/kg IV over 10-20 min. May repeat 5-10 mg/kg once if SE persists (up to max total 40 mg/kg). Dilute in NS. If SE continues after 20 min (total 35 min), consider Third-line.", "rules": [{"maxAgeMonths": 1, "mgPerKg": 15, "label": "Neonate Dose (<1 month)"}, {"maxAgeMonths": 216, "mgPerKg": 20, "label": "Infant/Child Dose"}]},
  {"id": "phenytoin-se-iv-loading", "name": "Phenytoin (SE IV Loading)", "kind": "Intermittent Dose Infusion", "doseUnit": "mg/kg", "concMgMl": 50, "suggestedDilutionMl": 50, "dilution": "**Status Epilepticus (SE) - Second-line (5-20 min):** If first-line benzodiazepines fail. Loading dose: 15-20 mg/kg IV over 10-20 min (max infusion rate 1 mg/kg/min). Dilute in NS only, do NOT use D5W. Monitor ECG/BP. If SE continues after 20 min (total 35 min), consider Third-line.", "rules": [{"maxAgeMonths": 1, "mgPerKg": 15, "label": "Neonate Dose (<1 month)"}, {"maxAgeMonths": 216, "mgPerKg": 20, "label": "Infant/Child Dose"}]},
  {"id": "packed-rbcs-prbcs-transfusion", "name": "Packed RBCs (PRBCs transfusion)", "kind": "Bolus Transfusion", "doseUnit": "mL/kg", "minDose": 10, "maxDose": 15, "initialDose": 10, "maxTotalMl": 300, "dilution": "To raise Hb ~2-3 g/dL; Slow infusion"},
  {"id": "platelets-transfusion", "name": "Platelets transfusion", "kind": "Bolus Transfusion", "doseUnit": "mL/kg", "minDose": 10, "maxDose": 15, "initialDose": 10, "maxTotalMl": 300, "dilution": "10-15 mL/kg; Neonates: smaller volumes; Raise platelets ~30-50k"},
  {"id": "fresh-frozen-plasma-ffp", "name": "Fresh Frozen Plasma (FFP)", "kind": "Bolus Transfusion", "doseUnit": "mL/kg", "minDose": 10, "maxDose": 15, "initialDose": 10, "maxTotalMl": 300, "dilution": "10-15 mL/kg for coagulopathy; Neonates: 10-20 mL/kg"},
  {"id": "whole-blood-fresh-blood-transfusion", "name": "Whole Blood / Fresh Blood transfusion", "kind": "Bolus Transfusion", "doseUnit": "mL/kg", "minDose": 20, "maxDose": 25, "initialDose": 20, "maxTotalMl": 500, "dilution": "20 mL/kg in acute blood loss; Neonates: cautious volume"},
  {"id": "artesunate-anti-malarial", "name": "Artesunate (Anti-Malarial)", "kind": "Weight Logic", "standardConc": 10, "dilution": "60mg vial + 6ml Sodium Chloride 0.9%"},
];

export type PercentilePoint = { age: number; p3: number; p15: number; p50: number; p85: number; p97: number };
export const WHO_BOYS: PercentilePoint[] = [
  { age: 0, p3: 2.3, p15: 2.7, p50: 3.3, p85: 4.0, p97: 4.8 },
  { age: 1, p3: 3.2, p15: 3.7, p50: 4.5, p85: 5.5, p97: 6.5 },
  { age: 2, p3: 4.0, p15: 4.6, p50: 5.6, p85: 6.8, p97: 7.8 },
  { age: 3, p3: 4.6, p15: 5.3, p50: 6.4, p85: 7.7, p97: 8.8 },
  { age: 4, p3: 5.0, p15: 5.8, p50: 6.9, p85: 8.3, p97: 9.5 },
  { age: 5, p3: 5.4, p15: 6.2, p50: 7.4, p85: 8.9, p97: 10.1 },
  { age: 6, p3: 5.7, p15: 6.5, p50: 7.8, p85: 9.3, p97: 10.5 },
  { age: 7, p3: 5.9, p15: 6.7, p50: 8.0, p85: 9.6, p97: 10.8 },
  { age: 8, p3: 6.0, p15: 6.9, p50: 8.2, p85: 9.8, p97: 11.0 },
  { age: 9, p3: 6.2, p15: 7.1, p50: 8.4, p85: 10.0, p97: 11.2 },
  { age: 10, p3: 6.4, p15: 7.2, p50: 8.6, p85: 10.2, p97: 11.4 },
  { age: 11, p3: 6.5, p15: 7.4, p50: 8.7, p85: 10.4, p97: 11.6 },
  { age: 12, p3: 6.6, p15: 7.5, p50: 8.9, p85: 10.5, p97: 11.7 },
  { age: 18, p3: 7.4, p15: 8.3, p50: 9.9, p85: 11.8, p97: 13.0 },
  { age: 24, p3: 8.0, p15: 9.0, p50: 10.6, p85: 12.7, p97: 14.1 },
  { age: 30, p3: 8.6, p15: 9.6, p50: 11.3, p85: 13.5, p97: 15.0 },
  { age: 36, p3: 9.0, p15: 10.1, p50: 11.9, p85: 14.2, p97: 15.8 },
  { age: 48, p3: 9.8, p15: 11.0, p50: 12.9, p85: 15.4, p97: 17.1 },
  { age: 60, p3: 10.4, p15: 11.7, p50: 13.7, p85: 16.4, p97: 18.2 },
];
export const WHO_GIRLS: PercentilePoint[] = [
  { age: 0, p3: 2.2, p15: 2.5, p50: 3.2, p85: 3.8, p97: 4.5 },
  { age: 1, p3: 3.0, p15: 3.5, p50: 4.2, p85: 5.2, p97: 6.0 },
  { age: 2, p3: 3.7, p15: 4.3, p50: 5.2, p85: 6.3, p97: 7.3 },
  { age: 3, p3: 4.2, p15: 4.9, p50: 5.8, p85: 7.0, p97: 8.0 },
  { age: 4, p3: 4.5, p15: 5.3, p50: 6.3, p85: 7.5, p97: 8.6 },
  { age: 5, p3: 4.8, p15: 5.6, p50: 7.7, p85: 8.0, p97: 9.0 },
  { age: 6, p3: 5.0, p15: 5.8, p50: 6.9, p85: 8.2, p97: 9.3 },
  { age: 7, p3: 5.1, p15: 6.0, p50: 7.1, p85: 8.4, p97: 9.5 },
  { age: 8, p3: 5.3, p15: 6.1, p50: 7.3, p85: 8.6, p97: 9.7 },
  { age: 9, p3: 5.4, p15: 6.3, p50: 7.5, p85: 8.8, p97: 9.9 },
  { age: 10, p3: 5.5, p15: 6.4, p50: 7.6, p85: 9.0, p97: 10.1 },
  { age: 11, p3: 5.6, p15: 6.5, p50: 7.8, p85: 9.2, p97: 10.3 },
  { age: 12, p3: 5.7, p15: 6.7, p50: 7.9, p85: 9.3, p97: 10.4 },
  { age: 18, p3: 6.4, p15: 7.4, p50: 8.8, p85: 10.4, p97: 11.5 },
  { age: 24, p3: 7.0, p15: 8.0, p50: 9.5, p85: 11.2, p97: 12.5 },
  { age: 30, p3: 7.5, p15: 8.5, p50: 10.1, p85: 11.9, p97: 13.3 },
  { age: 36, p3: 7.9, p15: 9.0, p50: 10.6, p85: 12.5, p97: 14.0 },
  { age: 48, p3: 9.8, p15: 11.0, p50: 12.9, p85: 15.4, p97: 17.1 },
  { age: 60, p3: 10.4, p15: 11.7, p50: 13.7, p85: 16.4, p97: 18.2 },
];

import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { AgeUnit, Sex } from "@/lib/dosing";
import { ageToMonths } from "@/lib/dosing";

export const DEPTS = [
  "Internal Medicine",
  "Surgery",
  "Emergency",
  "Chronic Disease",
  "Other",
] as const;

export type LogEntry = {
  id: string;
  time: string;
  patient: string;
  ageMonths: number;
  weightKg: number;
  dept: string;
  action: string;
  result: string;
};

type PatientState = {
  name: string;
  sex: Sex;
  dept: string;
  ageUnit: AgeUnit;
  ageValue: number;
  weightKg: number;
  log: LogEntry[];
  setName: (v: string) => void;
  setSex: (v: Sex) => void;
  setDept: (v: string) => void;
  setAgeUnit: (v: AgeUnit) => void;
  setAgeValue: (v: number) => void;
  setWeightKg: (v: number) => void;
  addLog: (action: string, result: string) => void;
  clearLog: () => void;
};

const defaults = {
  name: "New Patient",
  sex: "Boy" as Sex,
  dept: "Internal Medicine",
  ageUnit: "months" as AgeUnit,
  ageValue: 12,
  weightKg: 10,
};

export const usePatient = create<PatientState>()(
  persist(
    (set, get) => ({
      ...defaults,
      log: [],
      setName: (name) => set({ name }),
      setSex: (sex) => set({ sex }),
      setDept: (dept) => set({ dept }),
      setAgeUnit: (ageUnit) => {
        const months = ageToMonths(get().ageUnit, get().ageValue);
        let ageValue = months;
        if (ageUnit === "days") ageValue = Math.round(months * 30.4375);
        if (ageUnit === "years") ageValue = Math.round((months / 12) * 10) / 10;
        if (ageUnit === "months") ageValue = Math.round(months * 10) / 10;
        set({ ageUnit, ageValue });
      },
      setAgeValue: (ageValue) => set({ ageValue }),
      setWeightKg: (weightKg) => set({ weightKg }),
      addLog: (action, result) => {
        const s = get();
        const entry: LogEntry = {
          id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
          time: new Date().toISOString(),
          patient: s.name || "N/A",
          ageMonths: ageToMonths(s.ageUnit, s.ageValue),
          weightKg: s.weightKg,
          dept: s.dept,
          action,
          result,
        };
        set({ log: [entry, ...s.log].slice(0, 200) });
      },
      clearLog: () => set({ log: [] }),
    }),
    { name: "pediaref-patient", skipHydration: true },
  ),
);

export function printDocument(title: string, body: string) {
  const html = `<!doctype html>
<html>
<head>
  <meta charset="utf-8" />
  <title>${escapeHtml(title)}</title>
  <style>
    body { font-family: "IBM Plex Sans", Georgia, sans-serif; color: #1c1b19; max-width: 720px; margin: 40px auto; padding: 0 24px; }
    h1 { font-family: Georgia, serif; font-size: 28px; font-weight: 500; margin: 0 0 8px; }
    .meta { color: #6b6560; font-size: 13px; margin-bottom: 24px; }
    .row { display: flex; justify-content: space-between; gap: 16px; padding: 10px 0; border-bottom: 1px solid #e6e1d6; }
    .k { color: #6b6560; font-size: 12px; text-transform: uppercase; letter-spacing: .12em; }
    .v { font-size: 16px; }
    .note { margin-top: 24px; font-size: 12px; color: #6b6560; }
  </style>
</head>
<body>
  ${body}
  <p class="note">Educational reference only. Confirm against local protocol before any administration.</p>
  <script>window.onload = () => { window.print(); };</script>
</body>
</html>`;
  const blob = new Blob([html], { type: "text/html" });
  const url = URL.createObjectURL(blob);
  const w = window.open(url, "_blank");
  if (!w) {
    const a = document.createElement("a");
    a.href = url;
    a.download = `${title.replace(/\s+/g, "-").toLowerCase()}.html`;
    a.click();
  }
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
}

function escapeHtml(s: string) {
  return s
    .replaceAll("&", "&" + "amp;")
    .replaceAll("<", "&" + "lt;")
    .replaceAll(">", "&" + "gt;")
    .replaceAll('"', "&" + "quot;");
}

export { escapeHtml };

import type { Drug, Infusion, PercentilePoint } from "@/data/catalog";
import { WHO_BOYS, WHO_GIRLS } from "@/data/catalog";

export type AgeUnit = "days" | "months" | "years";
export type Sex = "Boy" | "Girl";

export function ageToMonths(unit: AgeUnit, value: number): number {
  if (unit === "days") return value / 30.4375;
  if (unit === "years") return value * 12;
  return value;
}

export function formatAge(unit: AgeUnit, value: number): string {
  if (unit === "days") return `${value} d`;
  if (unit === "years") return `${value} y`;
  return `${value} mo`;
}

export function pickRule(drug: Drug, ageMonths: number): { mgPerKg: number; label: string } {
  if (drug.rules?.length) {
    const rule = drug.rules.find((r) => ageMonths <= r.maxAgeMonths) ?? drug.rules[drug.rules.length - 1];
    if (rule) return { mgPerKg: rule.mgPerKg, label: rule.label };
  }
  return { mgPerKg: drug.mgPerKg ?? 0, label: "Standard dose" };
}

export type DoseResult = {
  mgPerKg: number;
  label: string;
  uncappedMg: number;
  totalMg: number;
  capped: boolean;
  volumeMl: number | null;
  notRecommended: boolean;
};

export function calculateDose(drug: Drug, ageMonths: number, weightKg: number): DoseResult {
  const { mgPerKg, label } = pickRule(drug, ageMonths);
  const notRecommended = mgPerKg <= 0;
  const uncappedMg = weightKg * mgPerKg;
  const capped = uncappedMg > drug.maxMg;
  const totalMg = Math.min(uncappedMg, drug.maxMg);
  const volumeMl =
    drug.conc > 0 ? (totalMg * drug.vol) / drug.conc : null;
  return { mgPerKg, label, uncappedMg, totalMg, capped, volumeMl, notRecommended };
}

export function holidaySegar(weightKg: number): { mlPerHr: number; mlPerDay: number } {
  let mlPerHr: number;
  if (weightKg <= 10) mlPerHr = weightKg * 4;
  else if (weightKg <= 20) mlPerHr = 40 + (weightKg - 10) * 2;
  else mlPerHr = 60 + (weightKg - 20);
  return { mlPerHr, mlPerDay: mlPerHr * 24 };
}

function lerp(a: number, b: number, t: number) {
  return a + (b - a) * t;
}

export function interpolateCurve(
  table: PercentilePoint[],
  age: number,
): PercentilePoint | null {
  if (!table.length) return null;
  const first = table[0];
  const last = table[table.length - 1];
  if (!first || !last) return null;
  if (age <= first.age) return first;
  if (age >= last.age) return last;
  for (let i = 0; i < table.length - 1; i += 1) {
    const a = table[i];
    const b = table[i + 1];
    if (!a || !b) continue;
    if (age >= a.age && age <= b.age) {
      const t = (age - a.age) / (b.age - a.age || 1);
      return {
        age,
        p3: lerp(a.p3, b.p3, t),
        p15: lerp(a.p15, b.p15, t),
        p50: lerp(a.p50, b.p50, t),
        p85: lerp(a.p85, b.p85, t),
        p97: lerp(a.p97, b.p97, t),
      };
    }
  }
  return last;
}

export type GrowthBand = "below-p3" | "p3-p15" | "p15-p85" | "p85-p97" | "above-p97";

export function assessGrowth(
  sex: Sex,
  ageMonths: number,
  weightKg: number,
): {
  band: GrowthBand;
  label: string;
  curve: PercentilePoint | null;
  inRange: boolean;
} {
  const table = sex === "Boy" ? WHO_BOYS : WHO_GIRLS;
  const curve = interpolateCurve(table, ageMonths);
  if (!curve) {
    return { band: "p15-p85", label: "No reference for this age.", curve: null, inRange: true };
  }
  if (weightKg < curve.p3) {
    return {
      band: "below-p3",
      label: `Weight is below the 3rd percentile (P3 ≈ ${curve.p3.toFixed(1)} kg). Consider nutritional review.`,
      curve,
      inRange: false,
    };
  }
  if (weightKg < curve.p15) {
    return {
      band: "p3-p15",
      label: `Weight sits between the 3rd and 15th percentiles (P15 ≈ ${curve.p15.toFixed(1)} kg).`,
      curve,
      inRange: true,
    };
  }
  if (weightKg <= curve.p85) {
    return {
      band: "p15-p85",
      label: `Weight is within the typical band (P50 ≈ ${curve.p50.toFixed(1)} kg).`,
      curve,
      inRange: true,
    };
  }
  if (weightKg <= curve.p97) {
    return {
      band: "p85-p97",
      label: `Weight sits between the 85th and 97th percentiles (P85 ≈ ${curve.p85.toFixed(1)} kg).`,
      curve,
      inRange: true,
    };
  }
  return {
    band: "above-p97",
    label: `Weight is above the 97th percentile (P97 ≈ ${curve.p97.toFixed(1)} kg). Consider nutritional review.`,
    curve,
    inRange: false,
  };
}

export function pickInfusionRule(inf: Infusion, ageMonths: number) {
  if (inf.rules?.length) {
    const rule = inf.rules.find((r) => ageMonths <= r.maxAgeMonths) ?? inf.rules[inf.rules.length - 1];
    if (rule) return { perKg: rule.mgPerKg, label: rule.label, unit: inf.doseUnit ?? "mg/kg" };
  }
  if (inf.meqRules?.length) {
    const rule = inf.meqRules.find((r) => ageMonths <= r.maxAgeMonths) ?? inf.meqRules[inf.meqRules.length - 1];
    if (rule) return { perKg: rule.meqPerKg, label: rule.label, unit: "mEq/kg" };
  }
  return { perKg: inf.initialDose ?? 0, label: "Standard dose", unit: inf.doseUnit ?? "" };
}

export function continuousRateMlHr(inf: Infusion, dose: number, weightKg: number): number {
  const conc = inf.concPerMl || 1;
  const unit = inf.doseUnit ?? "";
  if (unit.includes("mcg/kg/min")) return (dose * weightKg * 60) / conc;
  return (dose * weightKg) / conc;
}

export function formatNum(n: number, digits = 1): string {
  if (!Number.isFinite(n)) return "—";
  return n.toFixed(digits);
}

export function stripMd(text: string): string {
  return text.replace(/\*\*/g, "");
}

import {
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  CartesianGrid,
  ReferenceDot,
} from "recharts";
import { Button } from "@/components/ui/button";
import { WHO_BOYS, WHO_GIRLS } from "@/data/catalog";
import { ageToMonths, assessGrowth, formatNum } from "@/lib/dosing";
import { usePatient } from "@/lib/patient-store";
import { escapeHtml, printDocument } from "@/lib/print";
import { cn } from "@/lib/utils";

const SERIES = [
  { key: "p3", label: "P3", color: "#b54a42" },
  { key: "p15", label: "P15", color: "#9a7040" },
  { key: "p50", label: "P50", color: "#2c5f6e" },
  { key: "p85", label: "P85", color: "#9a7040" },
  { key: "p97", label: "P97", color: "#b54a42" },
] as const;

export function GrowthPanel() {
  const sex = usePatient((s) => s.sex);
  const name = usePatient((s) => s.name);
  const ageUnit = usePatient((s) => s.ageUnit);
  const ageValue = usePatient((s) => s.ageValue);
  const weightKg = usePatient((s) => s.weightKg);
  const addLog = usePatient((s) => s.addLog);

  const ageMonths = ageToMonths(ageUnit, ageValue);
  const table = sex === "Boy" ? WHO_BOYS : WHO_GIRLS;
  const assessment = assessGrowth(sex, ageMonths, weightKg);
  const inChart = ageMonths <= 60;

  function printReport() {
    printDocument(
      `Growth report — ${name}`,
      `<h1>Growth report</h1>
       <p class="meta">${escapeHtml(name)} · ${sex} · ${formatNum(ageMonths, 1)} months · ${weightKg} kg</p>
       <div class="row"><div class="k">Band</div><div class="v">${escapeHtml(assessment.band)}</div></div>
       <div class="row"><div class="k">Notes</div><div class="v">${escapeHtml(assessment.label)}</div></div>`,
    );
    addLog("Growth report", assessment.label);
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-xs uppercase tracking-mark text-accent">WHO 0–5 years</p>
          <h2 className="font-display text-3xl tracking-tight">Weight-for-age</h2>
        </div>
        <Button variant="secondary" onClick={printReport}>
          Print report
        </Button>
      </div>

      {!inChart ? (
        <p className="rounded-lg bg-raised px-4 py-3 text-sm text-muted">
          WHO weight-for-age curves in this reference stop at 60 months. Dosing still uses the
          entered age.
        </p>
      ) : (
        <div className="rounded-xl bg-surface p-3 shadow-border sm:p-4">
          <div className="mb-2 flex flex-wrap gap-3 text-xs text-muted">
            {SERIES.map((s) => (
              <span key={s.key} className="inline-flex items-center gap-1.5">
                <span
                  className="inline-block size-2 rounded-full"
                  style={{ background: s.color }}
                />
                {s.label}
              </span>
            ))}
            <span className="inline-flex items-center gap-1.5">
              <span className="inline-block size-2 rounded-full bg-accent" />
              Patient
            </span>
          </div>
          <div className="h-72 sm:h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={table} margin={{ top: 8, right: 12, left: 0, bottom: 8 }}>
                <CartesianGrid stroke="rgba(28,27,25,0.08)" />
                <XAxis
                  dataKey="age"
                  tick={{ fill: "#6b6560", fontSize: 11 }}
                  label={{
                    value: "Age (months)",
                    position: "insideBottom",
                    offset: -2,
                    fill: "#6b6560",
                    fontSize: 11,
                  }}
                />
                <YAxis
                  tick={{ fill: "#6b6560", fontSize: 11 }}
                  label={{
                    value: "kg",
                    angle: -90,
                    position: "insideLeft",
                    fill: "#6b6560",
                    fontSize: 11,
                  }}
                />
                <Tooltip
                  contentStyle={{
                    background: "#fffcf7",
                    border: "1px solid rgba(28,27,25,0.12)",
                    borderRadius: 8,
                    fontSize: 12,
                  }}
                />
                {SERIES.map((s) => (
                  <Line
                    key={s.key}
                    type="monotone"
                    dataKey={s.key}
                    stroke={s.color}
                    dot={false}
                    strokeWidth={s.key === "p50" ? 2.2 : 1.2}
                    isAnimationActive={false}
                  />
                ))}
                <ReferenceDot
                  x={Math.min(60, Math.max(0, ageMonths))}
                  y={weightKg}
                  r={6}
                  fill="#2c5f6e"
                  stroke="#fffcf7"
                  strokeWidth={2}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      <div
        className={cn(
          "rounded-xl p-4 shadow-border",
          assessment.inRange ? "bg-surface" : "bg-danger/10",
        )}
      >
        <p className="text-xs uppercase tracking-label text-subtle">Assessment</p>
        <p className="mt-1 text-sm leading-relaxed">{assessment.label}</p>
        {assessment.curve ? (
          <p className="mt-2 font-mono text-xs tabular-nums text-muted">
            P3 {formatNum(assessment.curve.p3)} · P50 {formatNum(assessment.curve.p50)} · P97{" "}
            {formatNum(assessment.curve.p97)} kg
          </p>
        ) : null}
      </div>
    </div>
  );
}

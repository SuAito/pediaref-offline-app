import { Field, NumberInput, Segmented, SelectInput, TextInput } from "@/components/field";
import { ageToMonths, formatAge, type AgeUnit, type Sex } from "@/lib/dosing";
import { DEPTS, usePatient } from "@/lib/patient-store";

function parseNum(raw: string, fallback: number) {
  const n = Number(raw);
  return Number.isFinite(n) ? n : fallback;
}

export function PatientPanel() {
  const name = usePatient((s) => s.name);
  const sex = usePatient((s) => s.sex);
  const dept = usePatient((s) => s.dept);
  const ageUnit = usePatient((s) => s.ageUnit);
  const ageValue = usePatient((s) => s.ageValue);
  const weightKg = usePatient((s) => s.weightKg);
  const setName = usePatient((s) => s.setName);
  const setSex = usePatient((s) => s.setSex);
  const setDept = usePatient((s) => s.setDept);
  const setAgeUnit = usePatient((s) => s.setAgeUnit);
  const setAgeValue = usePatient((s) => s.setAgeValue);
  const setWeightKg = usePatient((s) => s.setWeightKg);

  const months = ageToMonths(ageUnit, ageValue);
  const ageMax = ageUnit === "days" ? 365 : ageUnit === "years" ? 18 : 216;
  const ageStep = ageUnit === "years" ? 0.1 : ageUnit === "months" ? 0.5 : 1;
  const ageMin = 0;

  return (
    <aside className="rounded-xl bg-surface p-5 shadow-border sm:p-6">
      <p className="text-xs uppercase tracking-mark text-accent">Active case</p>
      <h2 className="mt-1 font-display text-2xl tracking-tight">Patient console</h2>
      <p className="mt-1 text-sm text-muted">
        Age and weight drive every dose, fluid rate, and growth plot.
      </p>

      <div className="mt-5 space-y-4">
        <Field label="Name">
          <TextInput
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Patient name"
            autoComplete="off"
          />
        </Field>
        <Field label="Sex">
          <Segmented<Sex>
            value={sex}
            onChange={setSex}
            options={[
              { id: "Boy", label: "Boy" },
              { id: "Girl", label: "Girl" },
            ]}
          />
        </Field>
        <Field label="Department">
          <SelectInput value={dept} onChange={(e) => setDept(e.target.value)}>
            {DEPTS.map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </SelectInput>
        </Field>
        <Field label="Age unit">
          <Segmented<AgeUnit>
            value={ageUnit}
            onChange={setAgeUnit}
            options={[
              { id: "days", label: "Days" },
              { id: "months", label: "Months" },
              { id: "years", label: "Years" },
            ]}
          />
        </Field>
        <Field label={`Age (${ageUnit})`}>
          <NumberInput
            min={ageMin}
            max={ageMax}
            step={ageStep}
            value={ageValue}
            onChange={(e) => setAgeValue(parseNum(e.target.value, 0))}
          />
        </Field>
        <Field label="Weight (kg)">
          <NumberInput
            min={0.5}
            max={80}
            step={0.1}
            value={weightKg}
            onChange={(e) => setWeightKg(parseNum(e.target.value, 0.5))}
          />
        </Field>
      </div>

      <dl className="mt-6 grid grid-cols-2 gap-3 rounded-lg bg-raised p-3">
        <div>
          <dt className="text-xs uppercase tracking-label text-subtle">Age</dt>
          <dd className="font-mono text-sm tabular-nums">{formatAge(ageUnit, ageValue)}</dd>
        </div>
        <div>
          <dt className="text-xs uppercase tracking-label text-subtle">Months</dt>
          <dd className="font-mono text-sm tabular-nums">{months.toFixed(1)}</dd>
        </div>
      </dl>
    </aside>
  );
}

export function PatientCards() {
  const name = usePatient((s) => s.name);
  const sex = usePatient((s) => s.sex);
  const ageUnit = usePatient((s) => s.ageUnit);
  const ageValue = usePatient((s) => s.ageValue);
  const weightKg = usePatient((s) => s.weightKg);
  const dept = usePatient((s) => s.dept);

  const cards = [
    { k: "Name", v: name || "—" },
    { k: "Sex", v: sex },
    { k: "Age", v: formatAge(ageUnit, ageValue) },
    { k: "Weight", v: `${weightKg} kg` },
    { k: "Dept", v: dept },
  ];

  return (
    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5">
      {cards.map((c) => (
        <div key={c.k} className="rounded-xl bg-surface p-4 shadow-border">
          <p className="text-xs uppercase tracking-label text-subtle">{c.k}</p>
          <p className="mt-1 font-display text-xl tracking-tight">{c.v}</p>
        </div>
      ))}
    </div>
  );
}

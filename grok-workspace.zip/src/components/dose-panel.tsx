import { useMemo, useState } from "react";
import { Field, TextInput } from "@/components/field";
import { Button } from "@/components/ui/button";
import { DRUGS } from "@/data/catalog";
import {
  ageToMonths,
  calculateDose,
  formatNum,
  stripMd,
} from "@/lib/dosing";
import { usePatient } from "@/lib/patient-store";
import { escapeHtml, printDocument } from "@/lib/print";
import { cn } from "@/lib/utils";

const CATEGORIES = [...new Set(DRUGS.map((d) => d.category))];

export function DosePanel() {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<string>("All");
  const [drugId, setDrugId] = useState(DRUGS[0]?.id ?? "");
  const [saved, setSaved] = useState(false);
  const ageUnit = usePatient((s) => s.ageUnit);
  const ageValue = usePatient((s) => s.ageValue);
  const weightKg = usePatient((s) => s.weightKg);
  const name = usePatient((s) => s.name);
  const addLog = usePatient((s) => s.addLog);
  const ageMonths = ageToMonths(ageUnit, ageValue);

  const list = useMemo(() => {
    const q = query.trim().toLowerCase();
    return DRUGS.filter((d) => {
      if (category !== "All" && d.category !== category) return false;
      if (q && !d.name.toLowerCase().includes(q)) return false;
      return true;
    });
  }, [query, category]);

  const drug = list.find((d) => d.id === drugId) ?? list[0];
  const result = drug ? calculateDose(drug, ageMonths, weightKg) : null;

  function logDose() {
    if (!drug || !result) return;
    addLog(
      `${drug.name} dose`,
      `${formatNum(result.totalMg, 1)} mg` +
        (result.volumeMl != null ? ` · ${formatNum(result.volumeMl, 2)} ml` : ""),
    );
    setSaved(true);
    window.setTimeout(() => setSaved(false), 1600);
  }

  function printRx() {
    if (!drug || !result) return;
    printDocument(
      `Dose check — ${name}`,
      `<h1>Dose check</h1>
       <p class="meta">${escapeHtml(name)} · ${weightKg} kg · ${formatNum(ageMonths, 1)} months</p>
       <div class="row"><div class="k">Drug</div><div class="v">${escapeHtml(drug.name)}</div></div>
       <div class="row"><div class="k">Rule</div><div class="v">${escapeHtml(result.label)}</div></div>
       <div class="row"><div class="k">mg/kg</div><div class="v">${formatNum(result.mgPerKg, 2)}</div></div>
       <div class="row"><div class="k">Total</div><div class="v">${formatNum(result.totalMg, 1)} mg${result.capped ? " (capped)" : ""}</div></div>
       <div class="row"><div class="k">Volume</div><div class="v">${result.volumeMl == null ? "—" : `${formatNum(result.volumeMl, 2)} ml`}</div></div>
       ${drug.notes ? `<p class="note">${escapeHtml(stripMd(drug.notes))}</p>` : ""}`,
    );
    logDose();
  }

  return (
    <div className="space-y-4">
      <div>
        <p className="text-xs uppercase tracking-mark text-accent">Medications</p>
        <h2 className="font-display text-3xl tracking-tight">Age-smart dosing</h2>
        <p className="mt-1 max-w-2xl text-sm text-muted">
          Weight × mg/kg, then cap at the listed maximum. Volume uses the stock
          concentration from the original reference.
        </p>
      </div>

      <div className="grid min-w-0 gap-3 md:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)]">
        <div className="min-w-0 rounded-xl bg-surface p-4 shadow-border sm:p-5">
          <Field label="Search">
            <TextInput
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Amoxicillin, ceftriaxone…"
            />
          </Field>
          <div className="mt-3 -mx-1 flex gap-2 overflow-x-auto px-1 pb-1">
            {["All", ...CATEGORIES].map((c) => (
              <button
                key={c}
                type="button"
                onClick={() => setCategory(c)}
                className={cn(
                  "h-11 shrink-0 rounded-full px-3.5 text-sm transition-[background-color,color] duration-150",
                  category === c ? "bg-fg text-bg" : "bg-raised text-muted hover:text-fg",
                )}
              >
                {c}
              </button>
            ))}
          </div>
          <label className="mt-3 block">
            <span className="sr-only">Drug</span>
            <select
              value={drug?.id ?? ""}
              onChange={(e) => setDrugId(e.target.value)}
              className="mt-1 h-11 w-full rounded-md bg-raised px-3 text-sm shadow-border focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
            >
              {list.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </select>
          </label>
          {list.length === 0 ? (
            <p className="mt-3 text-sm text-muted">No matching drug.</p>
          ) : null}
        </div>

        {drug && result ? (
          <div className="min-w-0 rounded-xl bg-surface p-4 shadow-border sm:p-5">
            <p className="text-xs uppercase tracking-label text-subtle">Dose summary</p>
            <h3 className="mt-1 font-display text-2xl tracking-tight">{drug.name}</h3>
            <p
              className={cn(
                "mt-3 rounded-md px-3 py-2 text-sm",
                result.notRecommended ? "bg-danger/10 text-fg" : "bg-raised text-muted",
              )}
            >
              {result.notRecommended
                ? `Not recommended in this age band — ${result.label}`
                : `Safety check: ${result.label} · ${formatNum(result.mgPerKg, 2)} mg/kg`}
            </p>
            {result.capped ? (
              <p className="mt-2 rounded-md bg-danger/10 px-3 py-2 text-sm">
                Calculated {formatNum(result.uncappedMg, 1)} mg exceeds max {drug.maxMg} mg.
                Capped.
              </p>
            ) : null}
            <dl className="mt-4 grid grid-cols-3 gap-3">
              <Stat k="mg/kg" v={formatNum(result.mgPerKg, 2)} />
              <Stat k="Total" v={`${formatNum(result.totalMg, 1)} mg`} />
              <Stat
                k="Volume"
                v={result.volumeMl == null ? "—" : `${formatNum(result.volumeMl, 2)} ml`}
              />
            </dl>
            <p className="mt-3 font-mono text-xs text-subtle">
              Stock {drug.conc} / {drug.vol} ml · max {drug.maxMg} mg
            </p>
            {drug.notes ? (
              <p className="mt-4 text-sm leading-relaxed text-muted">{stripMd(drug.notes)}</p>
            ) : null}
            <div className="mt-5 grid gap-2 sm:grid-cols-2">
              <Button
                variant="secondary"
                onClick={logDose}
                disabled={result.notRecommended}
              >
                {saved ? "Saved" : "Save to log"}
              </Button>
              <Button onClick={printRx} disabled={result.notRecommended}>
                Print dose check
              </Button>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}

function Stat({ k, v }: { k: string; v: string }) {
  return (
    <div className="rounded-md bg-raised px-3 py-2">
      <dt className="text-xs uppercase tracking-label text-subtle">{k}</dt>
      <dd className="font-mono text-sm tabular-nums">{v}</dd>
    </div>
  );
}

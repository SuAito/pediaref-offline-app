import { useMemo, useState } from "react";
import { Field, NumberInput, TextInput } from "@/components/field";
import { Button } from "@/components/ui/button";
import { INFUSIONS } from "@/data/catalog";
import {
  ageToMonths,
  continuousRateMlHr,
  formatNum,
  holidaySegar,
  pickInfusionRule,
  stripMd,
} from "@/lib/dosing";
import { usePatient } from "@/lib/patient-store";

function parseNum(raw: string, fallback: number) {
  const n = Number(raw);
  return Number.isFinite(n) ? n : fallback;
}

export function FluidsPanel() {
  const [query, setQuery] = useState("");
  const [infId, setInfId] = useState(INFUSIONS[0]?.id ?? "");
  const [dose, setDose] = useState<number | null>(null);
  const [hours, setHours] = useState(4);
  const [minutes, setMinutes] = useState(60);
  const [dilution, setDilution] = useState<number | null>(null);
  const [dex, setDex] = useState(10);
  const [saved, setSaved] = useState<"ivf" | "inf" | null>(null);

  const ageUnit = usePatient((s) => s.ageUnit);
  const ageValue = usePatient((s) => s.ageValue);
  const weightKg = usePatient((s) => s.weightKg);
  const addLog = usePatient((s) => s.addLog);
  const ageMonths = ageToMonths(ageUnit, ageValue);
  const fluids = holidaySegar(weightKg);

  const list = useMemo(() => {
    const q = query.trim().toLowerCase();
    return INFUSIONS.filter((i) => !q || i.name.toLowerCase().includes(q));
  }, [query]);

  const inf = list.find((i) => i.id === infId) ?? list[0];

  const rule = inf ? pickInfusionRule(inf, ageMonths) : null;
  const workingDose = dose ?? inf?.initialDose ?? rule?.perKg ?? 0;
  const workingDilution = dilution ?? inf?.suggestedDilutionMl ?? 50;

  let output = "";
  let detail = "";

  if (inf) {
    if (inf.kind === "Continuous" || inf.kind === "Insulin Unit Infusion") {
      const rate = continuousRateMlHr(inf, workingDose, weightKg);
      output = `${formatNum(rate, 2)} ml/hr`;
      detail = `${formatNum(workingDose, 3)} ${inf.doseUnit} · conc ${inf.concPerMl} ${inf.concDisplayUnit ?? ""}`;
    } else if (inf.kind === "Kcl mEq/kg Correction") {
      const totalMeq = workingDose * weightKg;
      const totalMl = totalMeq / (inf.concPerMl || 1);
      const rate = totalMl / hours;
      output = `${formatNum(rate, 2)} ml/hr`;
      detail = `Total ${formatNum(totalMeq, 1)} mEq · ${formatNum(totalMl, 2)} ml over ${hours} h`;
    } else if (inf.kind === "Bolus Transfusion") {
      const vol = workingDose * weightKg;
      output = `${formatNum(vol, 1)} ml`;
      detail = `${formatNum(workingDose, 1)} ml/kg`;
      if (inf.maxTotalMl && vol > inf.maxTotalMl) {
        detail += ` — exceeds typical single-unit max ${inf.maxTotalMl} ml`;
      }
    } else if (inf.kind === "Weight Logic") {
      const mgKg = weightKg < 20 ? 3 : 2.4;
      const mg = mgKg * weightKg;
      const ml = mg / (inf.standardConc || 10);
      output = `${formatNum(ml, 2)} ml`;
      detail = `${mgKg} mg/kg (WHO) · ${formatNum(mg, 1)} mg · ${inf.dilution ?? ""}`;
    } else if (inf.kind === "Continuous Dextrose Infusion") {
      const concMgMl = dex * 10;
      const rate = (workingDose * weightKg * 60) / concMgMl;
      output = `${formatNum(rate, 2)} ml/hr`;
      detail = `GIR ${formatNum(workingDose, 1)} mg/kg/min in D${dex}`;
    } else if (inf.kind === "Intermittent Dose Infusion") {
      const perKg = rule?.perKg ?? 0;
      const totalMg = perKg * weightKg;
      const rate = minutes > 0 ? (workingDilution / minutes) * 60 : 0;
      output = `${formatNum(rate, 2)} ml/hr`;
      detail = `${rule?.label ?? ""} · ${formatNum(totalMg, 1)} mg in ${workingDilution} ml over ${minutes} min`;
    } else if (inf.kind === "Intermittent mEq/kg Infusion") {
      const perKg = rule?.perKg ?? 0;
      const total = perKg * weightKg;
      const drugMl = total / (inf.concMeqMl || 1);
      const bag = Math.max(workingDilution, drugMl);
      const rate = minutes > 0 ? (bag / minutes) * 60 : 0;
      output = `${formatNum(rate, 2)} ml/hr`;
      detail = `${rule?.label ?? ""} · ${formatNum(total, 1)} mEq · bag ${formatNum(bag, 1)} ml`;
    }
  }

  function flash(kind: "ivf" | "inf") {
    setSaved(kind);
    window.setTimeout(() => setSaved(null), 1600);
  }

  function save() {
    if (!inf) return;
    addLog(`${inf.name} infusion`, `${output} · ${detail}`);
    flash("inf");
  }

  return (
    <div className="space-y-5">
      <div>
        <p className="text-xs uppercase tracking-mark text-accent">Critical care</p>
        <h2 className="font-display text-3xl tracking-tight">Fluids and infusions</h2>
      </div>

      <section className="rounded-xl bg-surface p-5 shadow-border">
        <h3 className="font-display text-xl tracking-tight">Holliday–Segar maintenance</h3>
        <p className="mt-1 text-sm text-muted">4/2/1 rule: first 10 kg × 4, next 10 × 2, remainder × 1 ml/kg/hr.</p>
        <div className="mt-4 grid grid-cols-2 gap-3">
          <div className="rounded-lg bg-raised px-4 py-3">
            <p className="text-xs uppercase tracking-label text-subtle">Rate</p>
            <p className="font-mono text-2xl tabular-nums">{formatNum(fluids.mlPerHr, 1)} ml/hr</p>
          </div>
          <div className="rounded-lg bg-raised px-4 py-3">
            <p className="text-xs uppercase tracking-label text-subtle">Daily</p>
            <p className="font-mono text-2xl tabular-nums">{formatNum(fluids.mlPerDay, 0)} ml</p>
          </div>
        </div>
        <Button
          className="mt-4"
          variant="secondary"
          onClick={() => {
            addLog(
              "IVF maintenance",
              `${formatNum(fluids.mlPerHr, 1)} ml/hr (${formatNum(fluids.mlPerDay, 0)} ml/day)`,
            );
            flash("ivf");
          }}
        >
          {saved === "ivf" ? "Saved" : "Save to log"}
        </Button>
      </section>

      <section className="rounded-xl bg-surface p-5 shadow-border">
        <h3 className="font-display text-xl tracking-tight">Syringe pump</h3>
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <Field label="Search infusions">
            <TextInput
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Dopamine, artesunate…"
            />
          </Field>
          <Field label="Infusion">
            <select
              value={inf?.id ?? ""}
              onChange={(e) => {
                setInfId(e.target.value);
                setDose(null);
                setDilution(null);
              }}
              className="h-11 w-full rounded-md bg-raised px-3 text-sm shadow-border focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent"
            >
              {list.map((i) => (
                <option key={i.id} value={i.id}>
                  {i.name}
                </option>
              ))}
            </select>
          </Field>
        </div>

        {inf ? (
          <p className="mt-3 text-xs uppercase tracking-label text-subtle">{inf.kind}</p>
        ) : null}

        {inf && inf.minDose != null && inf.maxDose != null ? (
          <div className="mt-4">
            <Field label={`Dose (${inf.doseUnit ?? ""})`}>
              <input
                type="range"
                min={inf.minDose}
                max={inf.maxDose}
                step={(inf.maxDose - inf.minDose) / 20}
                value={workingDose}
                onChange={(e) => setDose(Number(e.target.value))}
                className="w-full accent-accent"
              />
              <p className="mt-1 font-mono text-sm tabular-nums">{formatNum(workingDose, 3)}</p>
            </Field>
          </div>
        ) : null}

        {inf?.kind === "Kcl mEq/kg Correction" ? (
          <div className="mt-3">
            <Field label="Duration (hours)">
              <NumberInput
                min={1}
                max={24}
                value={hours}
                onChange={(e) => setHours(parseNum(e.target.value, 4))}
              />
            </Field>
          </div>
        ) : null}

        {inf?.kind === "Continuous Dextrose Infusion" ? (
          <div className="mt-3">
            <Field label="Dextrose %">
              <select
                value={dex}
                onChange={(e) => setDex(Number(e.target.value))}
                className="h-11 w-full rounded-md bg-raised px-3 text-sm shadow-border"
              >
                {(inf.dextrosePercents ?? [5, 10, 12.5, 25]).map((p) => (
                  <option key={p} value={p}>
                    D{p}
                  </option>
                ))}
              </select>
            </Field>
          </div>
        ) : null}

        {inf &&
        (inf.kind === "Intermittent Dose Infusion" ||
          inf.kind === "Intermittent mEq/kg Infusion") ? (
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <Field label="Duration (min)">
              <NumberInput
                min={15}
                max={180}
                value={minutes}
                onChange={(e) => setMinutes(parseNum(e.target.value, 60))}
              />
            </Field>
            <Field label="Dilution volume (ml)">
              <NumberInput
                min={0}
                max={500}
                value={workingDilution}
                onChange={(e) => setDilution(parseNum(e.target.value, 50))}
              />
            </Field>
          </div>
        ) : null}

        {list.length === 0 ? (
          <p className="mt-4 text-sm text-muted">No matching infusion.</p>
        ) : (
          <div className="mt-5 rounded-lg bg-raised px-4 py-4">
            <p className="text-xs uppercase tracking-label text-subtle">Pump output</p>
            <p className="mt-1 font-display text-3xl tabular-nums tracking-tight">{output || "—"}</p>
            <p className="mt-2 text-sm text-muted">{stripMd(detail)}</p>
            {inf?.dilution && inf.kind !== "Weight Logic" ? (
              <p className="mt-2 text-xs text-subtle">{stripMd(inf.dilution)}</p>
            ) : null}
          </div>
        )}
        <Button className="mt-4" onClick={save} disabled={!inf}>
          {saved === "inf" ? "Saved" : "Save infusion to log"}
        </Button>
      </section>
    </div>
  );
}

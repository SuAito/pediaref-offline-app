import { Button } from "@/components/ui/button";
import { formatNum } from "@/lib/dosing";
import { usePatient } from "@/lib/patient-store";

export function LogPanel() {
  const log = usePatient((s) => s.log);
  const clearLog = usePatient((s) => s.clearLog);

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-xs uppercase tracking-mark text-accent">Session</p>
          <h2 className="font-display text-3xl tracking-tight">Daily log</h2>
          <p className="mt-1 text-sm text-muted">
            Stored on this device only. Not a medical record.
          </p>
        </div>
        <Button
          variant="ghost"
          onClick={() => {
            if (log.length && window.confirm("Clear the log on this device?")) clearLog();
          }}
        >
          Clear log
        </Button>
      </div>

      {log.length === 0 ? (
        <p className="mt-6 text-sm text-muted">No entries yet. Save a dose or fluid calculation.</p>
      ) : (
        <div className="mt-5 overflow-x-auto rounded-xl bg-surface shadow-border">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-border text-xs uppercase tracking-wider text-subtle">
                <th className="px-4 py-3 font-medium">Time</th>
                <th className="px-4 py-3 font-medium">Patient</th>
                <th className="px-4 py-3 font-medium">Age</th>
                <th className="px-4 py-3 font-medium">Wt</th>
                <th className="px-4 py-3 font-medium">Action</th>
                <th className="px-4 py-3 font-medium">Result</th>
              </tr>
            </thead>
            <tbody>
              {log.map((row) => (
                <tr key={row.id} className="border-b border-border last:border-0">
                  <td className="px-4 py-3 font-mono text-xs tabular-nums text-muted">
                    {new Date(row.time).toLocaleString()}
                  </td>
                  <td className="px-4 py-3">{row.patient}</td>
                  <td className="px-4 py-3 font-mono text-xs tabular-nums">
                    {formatNum(row.ageMonths, 1)} mo
                  </td>
                  <td className="px-4 py-3 font-mono text-xs tabular-nums">{row.weightKg} kg</td>
                  <td className="px-4 py-3">{row.action}</td>
                  <td className="px-4 py-3 text-muted">{row.result}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

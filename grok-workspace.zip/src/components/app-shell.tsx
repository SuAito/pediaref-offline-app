import { useEffect, type ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import { formatAge } from "@/lib/dosing";
import { usePatient } from "@/lib/patient-store";

export function AppShell({ children }: { children: ReactNode }) {
  useEffect(() => {
    void usePatient.persist.rehydrate();
  }, []);

  return (
    <div className="min-h-dvh">
      <header className="sticky top-0 z-30 border-b border-border bg-bg/90 backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-7xl items-center justify-between gap-4 px-4 sm:h-16 sm:px-6">
          <Link to="/" className="flex min-w-0 items-center gap-2.5 text-fg">
            <span className="flex size-8 shrink-0 items-center justify-center rounded-sm bg-accent text-accent-fg shadow-border">
              <svg viewBox="0 0 24 24" className="size-4" fill="none" aria-hidden>
                <path
                  d="M4 16c2-6 4-9 8-9s6 3 8 9"
                  stroke="currentColor"
                  strokeWidth="1.75"
                />
                <circle cx="12" cy="7" r="1.4" fill="currentColor" />
              </svg>
            </span>
            <span className="min-w-0">
              <span className="block font-display text-lg leading-tight tracking-tight">
                PediaRef
              </span>
              <span className="hidden text-xs tracking-wide text-muted sm:block">
                Dosing · growth · fluids
              </span>
            </span>
          </Link>
          <HeaderCase />
        </div>
      </header>
      <div className="mx-auto w-full max-w-7xl px-4 py-6 sm:px-6 sm:py-8">{children}</div>
    </div>
  );
}

function HeaderCase() {
  const name = usePatient((s) => s.name);
  const sex = usePatient((s) => s.sex);
  const ageUnit = usePatient((s) => s.ageUnit);
  const ageValue = usePatient((s) => s.ageValue);
  const weightKg = usePatient((s) => s.weightKg);

  return (
    <p className="max-w-[58%] truncate text-right font-mono text-xs tabular-nums text-muted sm:max-w-none">
      <span className="text-fg">{name || "Unnamed"}</span>
      <span className="mx-1.5 text-subtle">·</span>
      {sex}
      <span className="mx-1.5 text-subtle">·</span>
      {formatAge(ageUnit, ageValue)}
      <span className="mx-1.5 text-subtle">·</span>
      {weightKg} kg
    </p>
  );
}

export function Disclaimer() {
  return (
    <p className="mt-10 max-w-3xl text-xs leading-relaxed text-subtle">
      Educational reference only — not a prescribing chart. Verify every dose,
      dilution, and indication against your unit protocol and a supervising
      clinician. Patient entries stay on this device.
    </p>
  );
}

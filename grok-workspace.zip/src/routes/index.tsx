import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Disclaimer } from "@/components/app-shell";
import { DosePanel } from "@/components/dose-panel";
import { FluidsPanel } from "@/components/fluids-panel";
import { GrowthPanel } from "@/components/growth-panel";
import { LogPanel } from "@/components/log-panel";
import { PatientCards, PatientPanel } from "@/components/patient-panel";
import { usePatient } from "@/lib/patient-store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

const TABS = [
  { id: "patient", label: "Patient" },
  { id: "growth", label: "Growth" },
  { id: "doses", label: "Doses" },
  { id: "fluids", label: "Fluids" },
  { id: "log", label: "Log" },
] as const;

type TabId = (typeof TABS)[number]["id"];

function Home() {
  const [tab, setTab] = useState<TabId>("doses");
  const [showCase, setShowCase] = useState(false);
  const logCount = usePatient((s) => s.log.length);

  return (
    <div>
      <section className="max-w-3xl">
        <p className="text-xs uppercase tracking-mark text-accent">Pediatric reference</p>
        <h1 className="mt-2 font-display text-4xl leading-tight tracking-tight sm:text-5xl">
          Weight in. Dose out.
        </h1>
        <p className="mt-3 max-w-xl text-muted">
          Age-smart mg/kg, WHO weight-for-age, Holliday–Segar fluids, and pump rates — a bedside
          calculator rebuilt for the ward, not a prescription.
        </p>
      </section>

      <div className="mt-8 grid min-w-0 gap-6 lg:grid-cols-[minmax(0,20rem)_minmax(0,1fr)]">
        <div className="min-w-0 lg:sticky lg:top-20 lg:self-start">
          <button
            type="button"
            className="mb-3 flex h-11 w-full items-center justify-between rounded-md bg-surface px-4 text-sm shadow-border lg:hidden"
            onClick={() => setShowCase((v) => !v)}
            aria-expanded={showCase}
          >
            <span>Patient console</span>
            <span className="text-muted">{showCase ? "Hide" : "Edit"}</span>
          </button>
          <div className={cn(showCase ? "block" : "hidden", "lg:block")}>
            <PatientPanel />
          </div>
        </div>

        <div className="min-w-0">
          <div className="flex gap-1.5 overflow-x-auto pb-2">
            {TABS.map((t) => (
              <button
                key={t.id}
                type="button"
                onClick={() => setTab(t.id)}
                className={cn(
                  "h-11 shrink-0 rounded-full px-4 text-sm transition-[background-color,color] duration-150",
                  tab === t.id ? "bg-fg text-bg" : "bg-surface text-muted shadow-border hover:text-fg",
                )}
              >
                {t.label}
                {t.id === "log" && logCount > 0 ? (
                  <span className="ml-1.5 font-mono text-xs tabular-nums">{logCount}</span>
                ) : null}
              </button>
            ))}
          </div>

          <div className="mt-5">
            {tab === "patient" ? (
              <div className="space-y-4">
                <h2 className="font-display text-3xl tracking-tight">Case snapshot</h2>
                <PatientCards />
              </div>
            ) : null}
            {tab === "growth" ? <GrowthPanel /> : null}
            {tab === "doses" ? <DosePanel /> : null}
            {tab === "fluids" ? <FluidsPanel /> : null}
            {tab === "log" ? <LogPanel /> : null}
          </div>
        </div>
      </div>
      <Disclaimer />
    </div>
  );
}
